package ai.magpie.mobile;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;

/** Shared native cards, typography and icons for Android utility pages. */
final class NativeUi {
  static final int BG=0xff151519,CARD=0xff202026,LINE=0xff32323c,INK=0xfff1f0f7,
      MUTED=0xffa4a2b4,ACCENT=0xffc4b5fd,GREEN=0xff9cdbbc,AMBER=0xffedc793;
  final Activity context;
  NativeUi(Activity activity){context=activity;}
  LinearLayout screen(){
    context.getWindow().setStatusBarColor(BG); context.getWindow().setNavigationBarColor(BG);
    context.getWindow().getDecorView().setSystemUiVisibility(0);
    LinearLayout body=column(); body.setPadding(dp(20),dp(12),dp(20),dp(28));
    FrameLayout canvas=new FrameLayout(context);canvas.setBackgroundColor(BG);
    canvas.addView(body,new FrameLayout.LayoutParams(Math.min(context.getResources().getDisplayMetrics().widthPixels,dp(600)),-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL));
    ScrollView scroll=new ScrollView(context);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);scroll.addView(canvas);context.setContentView(scroll);
    return body;
  }
  void header(LinearLayout body,String title,String subtitle,String section,Runnable back){
    LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);
    TextView arrow=label("",18,INK,true);arrow.setCompoundDrawablesWithIntrinsicBounds(icon("back",INK,20),null,null,null);
    arrow.setGravity(Gravity.CENTER);arrow.setPadding(dp(14),0,0,0);arrow.setBackground(surface(CARD,24,LINE));arrow.setContentDescription("返回 Magpie");arrow.setOnClickListener(v->back.run());
    top.addView(arrow,new LinearLayout.LayoutParams(dp(48),dp(48)));
    TextView brand=label("MAGPIE  /  "+section,11,MUTED,true);brand.setLetterSpacing(.12f);
    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.leftMargin=dp(14);top.addView(brand,p);add(body,top);gap(body,24);
    add(body,label(title,30,INK,true));gap(body,6);add(body,label(subtitle,14,MUTED,false));gap(body,22);
  }
  void section(LinearLayout body,String title){TextView text=label(title,12,MUTED,true);text.setPadding(dp(3),0,0,dp(10));add(body,text);}
  void tint(Switch toggle){
    toggle.setShowText(false);
    toggle.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{ACCENT,0xffb0adbd}));
    toggle.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{0xff76669d,0xff484650}));
  }
  int dp(float value) { return Math.round(value*context.getResources().getDisplayMetrics().density); }
  LinearLayout column() { LinearLayout box=new LinearLayout(context); box.setOrientation(LinearLayout.VERTICAL); return box; }
  LinearLayout row() { LinearLayout box=new LinearLayout(context); box.setOrientation(LinearLayout.HORIZONTAL); return box; }
  TextView label(String value,int size,int color,boolean bold) {
    TextView view=new TextView(context); view.setText(value); view.setTextSize(size); view.setTextColor(color);
    view.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));
    view.setIncludeFontPadding(false); view.setLineSpacing(dp(3),1f); return view;
  }
  void add(LinearLayout box,View view) { box.addView(view,new LinearLayout.LayoutParams(-1,-2)); }
  void gap(LinearLayout box,int height) { box.addView(new View(context),new LinearLayout.LayoutParams(1,dp(height))); }

  LinearLayout card() { LinearLayout box=column(); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackground(surface(CARD,22,LINE)); return box; }
  void divider(LinearLayout box) {
    View line=new View(context); line.setBackgroundColor(LINE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(1));
    p.topMargin=dp(14); p.bottomMargin=dp(14); box.addView(line,p);
  }
  void versionLine(LinearLayout box,String key,String value,int color) {
    LinearLayout line=column(); add(line,label(key,12,MUTED,false)); gap(line,6); add(line,label(value,21,color,true)); add(box,line);
  }
  void action(LinearLayout box,String title,String subtitle,String glyph,boolean enabled,Runnable run) {
    LinearLayout line=row(); line.setGravity(Gravity.CENTER_VERTICAL); line.setMinimumHeight(dp(56));
    line.setBackground(surface(Color.TRANSPARENT,12,Color.TRANSPARENT)); line.setPadding(dp(2),dp(4),dp(2),dp(4));
    TextView image=label("",18,ACCENT,false); image.setCompoundDrawablesWithIntrinsicBounds(icon(glyph,ACCENT,20),null,null,null);
    line.addView(image,new LinearLayout.LayoutParams(dp(32),dp(28)));
    LinearLayout words=column(); add(words,label(title,14,INK,true)); gap(words,5); add(words,label(subtitle,12,MUTED,false));
    line.addView(words,new LinearLayout.LayoutParams(0,-2,1));
    TextView arrow=label("",18,MUTED,false); arrow.setCompoundDrawablesWithIntrinsicBounds(icon("chevron",MUTED,18),null,null,null);
    LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(dp(20),dp(24)); a.leftMargin=dp(8); line.addView(arrow,a);
    line.setEnabled(enabled); line.setAlpha(enabled?1f:.45f); line.setOnClickListener(v->run.run()); add(box,line);
  }
  void primary(LinearLayout box,String title,boolean enabled,String glyph,Runnable run) {
    Button button=button(title,enabled,run); button.setTextColor(BG); button.setBackground(surface(ACCENT,15,Color.TRANSPARENT));
    button.setCompoundDrawablesWithIntrinsicBounds(icon(glyph,BG,18),null,null,null); button.setCompoundDrawablePadding(dp(8)); add(box,button);
  }
  void secondary(LinearLayout box,String title,boolean enabled,Runnable run) {
    Button button=button(title,enabled,run); button.setTextColor(ACCENT); button.setBackground(surface(Color.TRANSPARENT,15,LINE)); add(box,button);
  }
  Button button(String title,boolean enabled,Runnable run) {
    Button button=new Button(context); button.setText(title); button.setTextSize(15); button.setAllCaps(false); button.setSingleLine(false);
    button.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); button.setMinHeight(dp(52)); button.setMinimumHeight(dp(52));
    button.setMinWidth(0); button.setMinimumWidth(0); button.setPadding(dp(20),dp(14),dp(20),dp(14)); button.setStateListAnimator(null);
    button.setEnabled(enabled); button.setAlpha(enabled?1f:.45f); button.setOnClickListener(v->run.run()); return button;
  }
  Drawable surface(int color,int radius,int stroke) {
    GradientDrawable shape=new GradientDrawable(); shape.setColor(color); shape.setCornerRadius(dp(radius));
    if(stroke!=Color.TRANSPARENT) shape.setStroke(dp(1),stroke);
    return new RippleDrawable(ColorStateList.valueOf(0x25c4b5fd),shape,null);
  }
  Drawable icon(String name,int color,int size) { return new Icon(name,color,dp(size)); }

  /** Native vector line icons; no image font or Web dependency. */
  static final class Icon extends Drawable {
    private final String name; private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); private final int size;
    Icon(String value,int color,int pixels) { name=value; size=pixels; paint.setColor(color); paint.setStrokeWidth(1.8f); paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND); }
    private void path(Canvas c,float... points) { Path p=new Path(); p.moveTo(points[0],points[1]); for(int i=2;i<points.length;i+=2)p.lineTo(points[i],points[i+1]); c.drawPath(p,paint); }
    @Override public void draw(Canvas canvas) {
      int save=canvas.save(); Rect bounds=getBounds(); canvas.translate(bounds.left,bounds.top); canvas.scale(bounds.width()/24f,bounds.height()/24f);
      switch(name) {
        case "back": path(canvas,14,6,8,12,14,18); break;
        case "chevron": path(canvas,9,6,15,12,9,18); break;
        case "download": path(canvas,12,3,12,15); path(canvas,7,10,12,15,17,10); path(canvas,4,16,4,20,20,20,20,16); break;
        case "refresh": canvas.drawArc(4,4,20,20,35,285,false,paint); path(canvas,20,4,20,10,14,10); break;
        case "clock": canvas.drawCircle(12,12,9,paint); path(canvas,12,7,12,12,15,14); break;
        case "check": canvas.drawCircle(12,12,9,paint); path(canvas,7,12,10.5f,15.5f,17,9); break;
        case "alert": canvas.drawCircle(12,12,9,paint); path(canvas,12,7,12,12); canvas.drawPoint(12,16,paint); break;
        case "repository": canvas.drawRoundRect(4,3,20,21,3,3,paint); path(canvas,8,3,8,21); path(canvas,12,8,16,8); path(canvas,12,12,16,12); break;
        case "build": canvas.drawRoundRect(3,4,21,17,3,3,paint); path(canvas,8,21,16,21); path(canvas,12,17,12,21); path(canvas,7,9,9,11,7,13); path(canvas,12,13,16,13); break;
        case "battery": canvas.drawRoundRect(3,6,20,18,3,3,paint); path(canvas,23,10,23,14); path(canvas,12,8,9,12,14,12,11,16); break;
        case "bell": path(canvas,5,17,7,14,7,9,9,5,15,5,17,9,17,14,19,17,5,17); path(canvas,10,21,14,21); canvas.drawPoint(12,2,paint); break;
        case "shield": path(canvas,12,2,20,5,20,12,18,17,12,22,6,17,4,12,4,5,12,2); path(canvas,8,11,11,14,16,9); break;
        default: path(canvas,14,3,21,3,21,10); path(canvas,21,3,11,13); path(canvas,10,4,4,4,4,20,20,20,20,14);
      }
      canvas.restoreToCount(save);
    }
    @Override public int getIntrinsicWidth() { return size; }
    @Override public int getIntrinsicHeight() { return size; }
    @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
  }
}
