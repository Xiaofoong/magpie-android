package ai.magpie.mobile;
import android.content.*;
import org.json.JSONObject;
/** Test-only fixture. Never compiled into the release APK. */
final class AppUpdates {
  static Info available;
  static String message="",officialVersion="0.1.1846",scenario="waiting";
  static int progress=-1;
  static boolean busy;
  static class Info { String upstream="0.1.1845",notes="优化路由与供应商体验。"; long size=59233366; }
  static JSONObject build(Context c) { JSONObject j=new JSONObject();try {j.put("wrapperVersion","0.1.6");j.put("upstreamVersion","0.1.1845");}catch(Exception e){} return j; }
  static String repository(Context c) {return GatewayService.prefs(c).getString("repo","Xiaofoong/magpie-android");}
  static boolean working() {return busy;}
  static void attach(UpdateActivity a) {
    scenario=a.getIntent().getStringExtra("scenario");if(scenario==null)scenario="waiting";
    available=new Info(); progress=-1;busy=false;message="检查完成";
    if(scenario.equals("latest"))officialVersion="0.1.1845";else officialVersion="0.1.1846";
    if(newer(a))available.upstream="0.1.1846";
    if(scenario.equals("downloading")){busy=true;progress=48;message="正在下载并验证更新…";}
    if(scenario.equals("error"))message="检查未完成：网络暂不可用，请稍后重试";
  }
  static void detach(UpdateActivity a){}
  static boolean newer(Context c){return scenario.equals("available")||scenario.equals("ready")||scenario.equals("downloading");}
  static boolean downloaded(Context c){return scenario.equals("ready");}
  static void check(Context c,boolean manual){}
  static void install(UpdateActivity a){GatewayService.prefs(a).edit().putString("action","install").apply();}
  static void download(Context a){GatewayService.prefs(a).edit().putString("action","download").apply();}
  static void setRepository(Context c,String v){String repo=v.trim().isEmpty()?"":UpdatePolicy.repository(v);GatewayService.prefs(c).edit().putString("repo",repo).apply();}
}
