package ai.magpie.mobile;
import android.app.Activity;
import android.content.*;
/** Test-only gateway state; no native process runs in the UI test APK. */
final class GatewayService {
 static boolean running=true,starting=false;
 static String message="网关运行中 · 127.0.0.1:3425";
 static SharedPreferences prefs(Context c){
  if(c instanceof BackgroundProtectionActivity){String scenario=((Activity)c).getIntent().getStringExtra("scenario");running=!"stopped".equals(scenario)&&!"starting".equals(scenario);starting="starting".equals(scenario);message=starting?"正在自动连接本地网关…":running?"网关运行中 · 127.0.0.1:3425":"网关已停止";}
  return c.getSharedPreferences("ui-preview",Context.MODE_PRIVATE);
 }
 static String logs(Context c){return "[08:30:00] 网关启动成功\n[08:30:01] 本机健康检查通过\n[08:30:02] 等待 Agent 请求";}
}
