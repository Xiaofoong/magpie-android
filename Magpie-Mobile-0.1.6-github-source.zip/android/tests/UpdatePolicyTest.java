package ai.magpie.mobile;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
public final class UpdatePolicyTest {
  interface Check { void run() throws Exception; }
  static void reject(Check test) throws Exception { boolean rejected=false;try{test.run();}catch(IllegalArgumentException e){rejected=true;}if(!rejected)throw new AssertionError("unsafe input accepted"); }
  public static void main(String[] args) throws Exception {
    if(!UpdatePolicy.versionNewer("v0.1.1838","0.1.1825") || !UpdatePolicy.versionNewer("1.0.0","0.99.9999"))throw new AssertionError("new official version not detected");
    if(UpdatePolicy.versionNewer("0.1.1825","0.1.1838") || UpdatePolicy.versionNewer("0.1.1825","v0.1.1825") || UpdatePolicy.versionNewer("unknown","0.1.0"))throw new AssertionError("incorrect version ordering");
    if(!UpdatePolicy.appUpdateLink("magpie-mobile://updates") || !UpdatePolicy.appUpdateLink("magpie-mobile://updates/"))throw new AssertionError("APK update route rejected");
    for(String url:new String[]{"magpie-mobile://updates.evil.test","magpie-mobile://user@updates","magpie-mobile://updates:80","magpie-mobile://updates/other","magpie-mobile://updates?token=bad","https://updates"})
      if(UpdatePolicy.appUpdateLink(url))throw new AssertionError("invalid APK update route accepted");
    if(!UpdatePolicy.repository("https://github.com/Xiaofoong/magpie-android.git").equals("Xiaofoong/magpie-android"))throw new AssertionError();
    reject(()->UpdatePolicy.repository("a/b/../../private"));reject(()->UpdatePolicy.repository("https://evil.test/a/b"));
    UpdatePolicy.releaseAsset("https://github.com/Xiaofoong/magpie-android/releases/download/v1/app.apk","Xiaofoong/magpie-android");
    reject(()->UpdatePolicy.releaseAsset("https://github.com/other/repo/releases/download/v1/app.apk","Xiaofoong/magpie-android"));
    reject(()->UpdatePolicy.releaseAsset("https://github.com/Xiaofoong/magpie-android/releases/download/../../other/app.apk","Xiaofoong/magpie-android"));
    reject(()->UpdatePolicy.releaseAsset("https://github.com/Xiaofoong/magpie-android/releases/download/%2e%2e/app.apk","Xiaofoong/magpie-android"));
    reject(()->UpdatePolicy.secure("http://github.com/a/b"));reject(()->UpdatePolicy.secure("https://github.com.evil.test/a/b"));
    reject(()->UpdatePolicy.secure("https://github.com@evil.test/a/b"));reject(()->UpdatePolicy.secure("https://github.com:444/a/b"));reject(()->UpdatePolicy.secure("https://github.com/a/b#fragment"));
    UpdatePolicy.secure("https://release-assets.githubusercontent.com/a/b?token=temporary");
    reject(()->UpdatePolicy.size(-1));reject(()->UpdatePolicy.size(UpdatePolicy.MAX_APK+1));reject(()->UpdatePolicy.digest("not-a-checksum"));
    byte[] digest=MessageDigest.getInstance("SHA-256").digest("abc".getBytes(StandardCharsets.UTF_8));
    if(!UpdatePolicy.sameHash("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",digest))throw new AssertionError();
    if(UpdatePolicy.sameHash("0000000000000000000000000000000000000000000000000000000000000000",digest))throw new AssertionError();
    System.out.println("PASS update channels, HTTPS/redirect hosts, repository binding, traversal, size limits and SHA-256 checks");
  }
}
