const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { JSDOM, VirtualConsole } = require('jsdom');
const script = fs.readFileSync(path.join(__dirname,'../app/src/main/assets/android-updates.js'),'utf8');
const html = `<button id="update"><span>更新</span></button><div id="about">
<div class="row pref"><div class="who"><div class="name">版本</div><div class="sub">无法写入安装目录</div></div><div class="val"><code>0.1.1825</code><button id="old-download">下载</button></div></div>
<div class="row pref update-auto-row"><div class="who"><div class="name">自动更新</div><div class="sub">核心自动更新</div></div><div class="val"><button>开启</button></div></div>
<div class="row pref update-every-row"></div><div class="row pref update-restart-row"></div></div>
<button id="provider-refresh">刷新供应商</button><a id="provider-login" href="https://example.test/login">登录</a>`;
const pause = () => new Promise(resolve=>setTimeout(resolve,70));
(async () => {
  const virtualConsole = new VirtualConsole();
  const dom = new JSDOM(html,{url:'http://127.0.0.1:3430/',runScripts:'outside-only',pretendToBeVisual:true,virtualConsole});
  const {window:w}=dom;let downloads=0,providers=0,apkNavigation=0;
  w.document.getElementById('old-download').onclick=()=>downloads++;
  w.document.getElementById('provider-refresh').onclick=()=>providers++;
  // Capture navigation attempts without replacing browser Location or the product script.
  dom.virtualConsole.on('jsdomError',e=>{if(e.type==='not implemented' && /navigation/.test(e.message))apkNavigation++;else throw e;});
  w.eval(script);
  assert.equal(w.document.querySelectorAll('#about > .row:first-child button').length,1);
  assert.equal(w.document.querySelector('#about code').textContent,'0.1.1825');
  assert.match(w.document.querySelector('#about .sub').textContent,/APK/);
  assert.ok(w.document.querySelector('.update-every-row').hidden);
  const apk=w.document.querySelector('[data-magpie-apk-update]');apk.click();
  w.document.querySelector('#update span').click();
  assert.equal(apkNavigation,2);assert.equal(downloads,0);
  w.document.getElementById('provider-refresh').click();assert.equal(providers,1);
  const login=new w.MouseEvent('click',{bubbles:true,cancelable:true});w.document.getElementById('provider-login').dispatchEvent(login);assert.equal(login.defaultPrevented,false);
  const val=w.document.querySelector('#about .val');val.insertAdjacentHTML('beforeend','<button id="late-core-download">下载更新</button>');
  w.document.querySelector('#about .sub').textContent='再次收到核心只读目录错误';
  await pause();assert.equal(w.document.getElementById('late-core-download'),null);assert.match(w.document.querySelector('#about .sub').textContent,/APK/);
  w.eval(script);assert.equal(w.document.querySelectorAll('#about > .row:first-child [data-magpie-apk-update]').length,1);
  w.dispatchEvent(new w.Event('pagehide'));dom.window.close();
  const remote=new JSDOM(html,{url:'https://example.test/',runScripts:'outside-only'});remote.window.eval(script);assert.ok(remote.window.document.getElementById('old-download'));remote.window.close();
  console.log('PASS Web update actions route to APK updates; core error redraw is repaired; provider actions and external origins are untouched');
})().catch(e=>{console.error(e);process.exitCode=1;});
