#!/usr/bin/env python3
import argparse,json,pathlib,re
from follow_official import repository,tag,write,app_version,release_name

def merge(probe,core,local):
    for key,value in probe.items():
        if key!='upstreamCommit' and core.get(key)!=value:raise ValueError('core job changed trusted release plan: '+key)
    for key in ['mobileRevision','signerSha256']:
        if probe[key]!=local[key]:raise ValueError('release plan differs from checked-out wrapper')
    if probe.get('sourceWrapperVersion')!=local['wrapperVersion'] or app_version(probe['wrapperVersion'])<app_version(local['wrapperVersion']):
        raise ValueError('invalid incremented Android version')
    if probe['versionName']!=probe['wrapperVersion']+'-core'+probe['upstreamVersion']:raise ValueError('versionName differs from Android app version')
    if probe['releaseTag']!=release_name(probe['upstreamTag'],probe['mobileRevision']):raise ValueError('release identity mismatch')
    repository(probe['updateRepository']);tag(probe['upstreamTag'])
    commit=core.get('upstreamCommit','')
    if not re.fullmatch('[a-f0-9]{40}',commit):raise ValueError('invalid source commit')
    return {**probe,'upstreamCommit':commit}

def main():
    p=argparse.ArgumentParser();p.add_argument('--probe',required=True);p.add_argument('--core',required=True);p.add_argument('--out',default='ci/out/package-plan.json');a=p.parse_args()
    write(a.out,merge(json.loads(pathlib.Path(a.probe).read_text()),json.loads(pathlib.Path(a.core).read_text()),json.loads(pathlib.Path('android/release.json').read_text())))
if __name__=='__main__':main()
