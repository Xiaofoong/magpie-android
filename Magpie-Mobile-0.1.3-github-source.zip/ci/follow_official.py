#!/usr/bin/env python3
"""Plan an Android release from public upstream tags; never installs executable updates in app data."""
import argparse, hashlib, json, os, pathlib, re, shutil, subprocess, time, urllib.error, urllib.request, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
UPSTREAM='yetone/magpie-releases'
def repository(value):
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}/[A-Za-z0-9][A-Za-z0-9_.-]{0,99}',value):raise ValueError('invalid repository')
    return value

def tag(value):
    if not re.fullmatch(r'v[0-9]+(?:\.[0-9A-Za-z]+)+(?:[-+][0-9A-Za-z.-]+)?',value):raise ValueError('invalid upstream release tag')
    return value

def api(path, allow_missing=False):
    request=urllib.request.Request('https://api.github.com/'+path,headers={'User-Agent':'Magpie-Mobile-release','Accept':'application/vnd.github+json'})
    token=os.environ.get('GH_TOKEN')
    if token:request.add_header('Authorization','Bearer '+token)
    try:
        with urllib.request.urlopen(request,timeout=30) as response:return json.load(response)
    except urllib.error.HTTPError as e:
        if e.code==404 and allow_missing:return None
        raise

def release_name(upstream_tag, revision):
    return 'android-'+tag(upstream_tag)+'-r'+str(int(revision))

def plan(repo, latest, local):
    repo=repository(repo)
    if latest.get('draft') or latest.get('prerelease'):raise ValueError('only published stable upstream releases are followed')
    upstream=tag(latest['tag_name']); revision=local['mobileRevision']
    if type(revision) is not int or revision<1:raise ValueError('invalid mobile revision')
    return {**local,'updateRepository':repo,'upstreamVersion':upstream[1:],'upstreamTag':upstream,
            'releaseTag':release_name(upstream,revision),
            'versionCode':max(int(time.time()//60),int(local['versionCode'])+1),
            'versionName':local['wrapperVersion']+'-core'+upstream[1:],
            'notes':str(latest.get('body',''))[:12000]}

def write(path,data):pathlib.Path(path).parent.mkdir(parents=True,exist_ok=True);pathlib.Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def run(args,**kwargs):subprocess.run([str(x) for x in args],check=True,**kwargs)
def download(url,path,sha):
    if not re.fullmatch('[a-f0-9]{64}',sha):raise ValueError('unlocked dependency')
    request=urllib.request.Request(url,headers={'User-Agent':'Magpie-Mobile-release'})
    h=hashlib.sha256();path=pathlib.Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    try:
        with urllib.request.urlopen(request,timeout=120) as source,path.open('wb') as out:
            for block in iter(lambda:source.read(1024*1024),b''):h.update(block);out.write(block)
        if h.hexdigest()!=sha:raise ValueError('dependency SHA-256 mismatch')
    except Exception:path.unlink(missing_ok=True);raise

def probe(args):
    if api('repos/'+repository(args.repository)).get('private'):raise RuntimeError('The Android release channel must be public; never embed an access token in the APK')
    data=plan(args.repository,api('repos/'+UPSTREAM+'/releases/latest'),json.loads((ROOT/'android/release.json').read_text()))
    existing=api('repos/'+args.repository+'/releases/tags/'+data['releaseTag'],allow_missing=True)
    changed=existing is None or bool(existing.get('draft'))
    # Never clobber a published release, even if a scheduled run is retried.
    write(args.plan,data)
    with open(os.environ['GITHUB_OUTPUT'],'a') as out:
        out.write('changed='+str(changed).lower()+'\n')
    print('Upstream',data['upstreamTag'],'Android release',data['releaseTag'],'build needed:',changed)

def source(args):
    data=json.loads(pathlib.Path(args.plan).read_text());ref=tag(data['upstreamTag'])
    dest=pathlib.Path(args.destination).resolve()
    if dest.exists():raise RuntimeError('source destination already exists')
    run(['git','init',str(dest)])
    run(['git','-C',dest,'fetch','--depth=1','https://github.com/yetone/magpie.git','refs/tags/'+ref])
    run(['git','-C',dest,'checkout','--detach','FETCH_HEAD'])
    data['upstreamCommit']=subprocess.check_output(['git','-C',str(dest),'rev-parse','HEAD'],text=True).strip()
    if not re.fullmatch('[a-f0-9]{40}',data['upstreamCommit']):raise ValueError('bad source commit')
    target=dest/'cmd/magpie-mobile-overlay'
    if target.exists():raise RuntimeError('upstream unexpectedly owns mobile overlay path')
    shutil.copytree(ROOT/'backend-overlay/cmd/mobile',target)
    write(args.plan,data)

def dependencies(args):
    data=json.loads(pathlib.Path(args.plan).read_text())
    lock=json.loads((ROOT/'ci/tools-lock.json').read_text())['ecj']
    download(lock['url'],ROOT/'toolchain/ecj.jar',lock['sha256'])
    runtime=json.loads((ROOT/'ci/runtime-lock.json').read_text())
    url=runtime['url']
    archive=ROOT/'toolchain/runtime.zip';download(url,archive,runtime['assetSha256'])
    with zipfile.ZipFile(archive) as z:
        binary=z.read(runtime['archiveEntry'])
        if hashlib.sha256(binary).hexdigest()!=runtime['binarySha256']:raise ValueError('Bun runtime checksum mismatch')
        dest=ROOT/'android/app/src/main/jniLibs/arm64-v8a';dest.mkdir(parents=True,exist_ok=True);(dest/'libbun.so').write_bytes(binary)
    print('Pinned ECJ and Android Bun runtime verified')

def build_core(args):
    data=json.loads(pathlib.Path(args.plan).read_text());source=pathlib.Path(args.source).resolve()
    env=dict(os.environ,CGO_ENABLED='0')
    out=ROOT/'toolchain/magpie-host';out.parent.mkdir(parents=True,exist_ok=True)
    run(['go','build','-tags','nogui','-trimpath','-ldflags','-s -w -X main.version='+data['upstreamVersion'],'-o',out,'./cmd/magpie-mobile-overlay'],cwd=source,env=env)
    run(['python3',ROOT/'android/tests/native_contract.py',out],cwd=ROOT,env=env)
    run(['python3',ROOT/'android/tests/smoke.py',out],cwd=ROOT,env=env)
    env.update(GOOS='android',GOARCH='arm64')
    native=ROOT/'android/app/src/main/jniLibs/arm64-v8a/libmagpie.so';native.parent.mkdir(parents=True,exist_ok=True)
    run(['go','build','-tags','nogui','-trimpath','-ldflags','-s -w -X main.version='+data['upstreamVersion'],'-o',native,'./cmd/magpie-mobile-overlay'],cwd=source,env=env)

def main():
    parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('probe');p.add_argument('--repository',required=True);p.add_argument('--plan',default='ci/out/build-plan.json');p.set_defaults(fn=probe)
    p=sub.add_parser('source');p.add_argument('--plan',default='ci/out/build-plan.json');p.add_argument('--destination',default='official-source');p.set_defaults(fn=source)
    p=sub.add_parser('dependencies');p.add_argument('--plan',default='ci/out/build-plan.json');p.set_defaults(fn=dependencies)
    p=sub.add_parser('build-core');p.add_argument('--plan',default='ci/out/build-plan.json');p.add_argument('--source',default='official-source');p.set_defaults(fn=build_core)
    args=parser.parse_args();args.fn(args)
if __name__=='__main__':main()
