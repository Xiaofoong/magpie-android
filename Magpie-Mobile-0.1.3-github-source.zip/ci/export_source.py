#!/usr/bin/env python3
"""Export explicit source trees only; never publish private signing material."""
import argparse, pathlib, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
TREES=('android/app/src/main/java','android/app/src/main/res','android/app/src/main/assets','android/tests','backend-overlay/cmd/mobile','ci','.github/workflows')
FILES=('README.md','.gitignore','android/build.py','android/release.json','android/README.zh-CN.md','android/README-direct.zh-CN.md','android/app/src/main/AndroidManifest.xml')
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args()
    files={ROOT/f for f in FILES}
    for tree in TREES:files.update(f for f in (ROOT/tree).rglob('*') if f.is_file() and '__pycache__' not in f.parts)
    out=pathlib.Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for file in sorted(files):
            relative=file.relative_to(ROOT)
            if file.is_symlink() or file.suffix.lower() in {'.p12','.jks','.keystore','.apk','.pyc'} or file.name in {'password.txt','.env'}:raise ValueError('refusing non-source file')
            z.write(file,str(relative))
    print('Public source exported:',len(files),'files')
if __name__=='__main__':main()
