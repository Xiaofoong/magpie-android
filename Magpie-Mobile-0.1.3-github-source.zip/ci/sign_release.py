#!/usr/bin/env python3
"""Signing stage: no upstream binary is executed here, and the keystore is temporary."""
import argparse,base64,hashlib,json,os,pathlib,re,shutil,subprocess,tempfile,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def run(args,**kwargs):subprocess.run([str(x) for x in args],check=True,**kwargs)
def descriptor(info,apk):
    repo=info['updateRepository'];tag=info['releaseTag']
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',repo) or not re.fullmatch(r'[0-9A-Za-z.+_-]+',tag):raise ValueError('invalid release destination')
    return {'schema':1,'packageName':'ai.magpie.mobile','versionCode':info['versionCode'],'versionName':info['versionName'],
            'upstreamVersion':info['upstreamVersion'],'upstreamCommit':info['upstreamCommit'],
            'apkUrl':'https://github.com/'+repo+'/releases/download/'+tag+'/'+apk.name,
            'size':apk.stat().st_size,'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),
            'notes':info.get('notes','')[:12000]}
def main():
    p=argparse.ArgumentParser();p.add_argument('--plan',default='ci/out/build-plan.json');p.add_argument('--unsigned',required=True);p.add_argument('--out',default='release');p.add_argument('--build-tools',required=True);args=p.parse_args()
    info=json.loads(pathlib.Path(args.plan).read_text());bt=pathlib.Path(args.build_tools);out=pathlib.Path(args.out);out.mkdir(parents=True,exist_ok=True)
    if not re.fullmatch(r'[0-9A-Za-z.+_-]{1,100}',info['versionName']):raise ValueError('invalid version')
    trusted=json.loads((ROOT/'android/release.json').read_text())
    if info['signerSha256']!=trusted['signerSha256']:raise ValueError('untrusted signing identity in build plan')
    signed=out/('Magpie-Mobile-'+info['versionName']+'-arm64.apk')
    # CI injects these secrets only in the isolated signing job.
    with tempfile.TemporaryDirectory(prefix='magpie-sign-') as private:
        key=pathlib.Path(private)/'key.p12';key.write_bytes(base64.b64decode(os.environ['ANDROID_KEYSTORE_BASE64'],validate=True));key.chmod(0o600)
        env=dict(os.environ,MAGPIE_SIGN_PASS=os.environ['ANDROID_KEYSTORE_PASSWORD'])
        run([bt/'apksigner','sign','--ks',key,'--ks-key-alias','mobile','--ks-pass','env:MAGPIE_SIGN_PASS','--out',signed,args.unsigned],env=env)
    verify=subprocess.check_output([str(bt/'apksigner'),'verify','--print-certs',str(signed)],text=True)
    cert=next(x.split(': ',1)[1] for x in verify.splitlines() if 'certificate SHA-256 digest:' in x)
    if cert.lower()!=info['signerSha256'].lower():signed.unlink();raise RuntimeError('Refusing release with a different APK signer')
    with zipfile.ZipFile(signed) as z:
        packed=json.loads(z.read('assets/mobile-release.json'))
        for field in ['versionCode','versionName','upstreamCommit','updateRepository','signerSha256']:
            if packed[field]!=info[field]:raise ValueError('APK build metadata mismatch: '+field)
    badging=subprocess.check_output([str(bt/'aapt'),'dump','badging',str(signed)],text=True)
    if "name='ai.magpie.mobile'" not in badging or "versionCode='"+str(info['versionCode'])+"'" not in badging:raise ValueError('APK identity mismatch')
    (out/'android-update.json').write_text(json.dumps(descriptor(info,signed),ensure_ascii=False,indent=2)+'\n')
    (out/'SHA256SUMS').write_text(hashlib.sha256(signed.read_bytes()).hexdigest()+'  '+signed.name+'\n')
    (out/'notes.md').write_text('Magpie Android · upstream '+info['upstreamVersion']+'\n\n'+info.get('notes','')+'\n\nAndroid build and gateway contract checks passed. Install over the existing app; do not uninstall.\n')
    (out/'release-tag.txt').write_text(info['releaseTag'])
    print('Signed APK verified; release metadata prepared')
if __name__=='__main__':main()
