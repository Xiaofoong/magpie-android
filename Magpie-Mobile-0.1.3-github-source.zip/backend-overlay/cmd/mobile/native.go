package main

import (
	"crypto/subtle"
	"encoding/base64"
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"os"
	"sync"
	"time"

	"github.com/yetone/magpie/internal/backup"
	"github.com/yetone/magpie/internal/provider"
	"github.com/yetone/magpie/internal/settings"
)

// Native edits merge into the stored object, so a small Android form never
// drops advanced options, keys, or model settings it does not display.
func startNativeAPI() {
	addr := os.Getenv("MAGPIE_NATIVE_ADDR")
	if addr == "" {
		return
	}
	key := os.Getenv("MAGPIE_WEB_KEY")
	if len(key) < 16 {
		log.Fatal("native API needs the private management key")
	}
	var edits sync.Mutex
	mux := http.NewServeMux()
	reply := func(w http.ResponseWriter, v any) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(v)
	}
	mux.HandleFunc("GET /mobile/health", func(w http.ResponseWriter, r *http.Request) {
		reply(w, map[string]any{"native": true, "version": version})
	})
	mux.HandleFunc("POST /mobile/backup/export", func(w http.ResponseWriter, r *http.Request) {
		var in struct {
			Pass string `json:"pass"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096)).Decode(&in); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		if len(in.Pass) < 8 {
			http.Error(w, "use a backup password with at least 8 characters", 400)
			return
		}
		b, err := backup.Collect(true, version)
		var sealed []byte
		if err == nil {
			sealed, err = backup.Seal(b, in.Pass)
		}
		if err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		reply(w, map[string]string{"data": base64.StdEncoding.EncodeToString(sealed)})
	})
	mux.HandleFunc("POST /mobile/settings", func(w http.ResponseWriter, r *http.Request) {
		edits.Lock()
		defer edits.Unlock()
		s, err := settings.LoadChecked()
		if err == nil {
			err = json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&s)
		}
		if err == nil {
			s.NoAutoUpdate = true
			err = settings.Save(s)
		}
		if err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		reply(w, map[string]bool{"ok": true})
	})
	mux.HandleFunc("POST /mobile/provider/models", func(w http.ResponseWriter, r *http.Request) {
		edits.Lock()
		defer edits.Unlock()
		var in struct {
			ID     string   `json:"id"`
			Models []string `json:"models"`
		}
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&in); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		var err error
		if len(in.Models) == 0 {
			var p *provider.Provider
			p, err = provider.Find(in.ID)
			if err == nil {
				p.NoModels = true
				p.Models = nil
				err = provider.Save(*p)
			}
		} else {
			err = provider.SetModels(in.ID, in.Models)
		}
		if err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		reply(w, map[string]bool{"ok": true})
	})
	mux.HandleFunc("POST /mobile/provider/save", func(w http.ResponseWriter, r *http.Request) {
		edits.Lock()
		defer edits.Unlock()
		var body json.RawMessage
		if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<20)).Decode(&body); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		var in struct {
			ID, Preset, Key string
			New             bool
		}
		if err := json.Unmarshal(body, &in); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		var p provider.Provider
		var err error
		if !in.New {
			var found *provider.Provider
			found, err = provider.Find(in.ID)
			if err == nil {
				p = *found
			}
		} else if in.Preset != "" {
			p, err = provider.FromPreset(in.Preset)
		}
		if err == nil {
			err = json.Unmarshal(body, &p)
		}
		// A blank password field means keep the key that was already stored.
		if !in.New && in.Key == "" {
			if old, e := provider.Find(in.ID); e == nil {
				p.Key = old.Key
			} else {
				err = e
			}
		}
		if err == nil {
			if len(p.Models) > 0 {
				p.NoModels = false
			}
			if in.New {
				p.ID = ""
				_, err = provider.Add(p)
			} else if p.ID != in.ID {
				err = errors.New("provider id cannot change in this editor")
			} else {
				err = provider.Save(p)
			}
		}
		if err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		reply(w, map[string]bool{"ok": true})
	})
	guard := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		if subtle.ConstantTimeCompare([]byte(r.Header.Get("Authorization")), []byte("Bearer "+key)) != 1 {
			http.Error(w, "management key required", 401)
			return
		}
		mux.ServeHTTP(w, r)
	})
	go func() {
		srv := &http.Server{Addr: addr, Handler: guard, ReadHeaderTimeout: 10 * time.Second}
		if err := srv.ListenAndServe(); err != nil {
			log.Printf("native API: %v", err)
		}
	}()
}
