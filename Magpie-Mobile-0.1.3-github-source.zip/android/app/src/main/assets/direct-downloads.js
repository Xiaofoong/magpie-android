(() => {
  if (location.origin !== 'http://127.0.0.1:3430' || window.__magpieAndroidDownloads) return;
  window.__magpieAndroidDownloads = true;
  const blobs = new Map();
  const create = URL.createObjectURL.bind(URL), revoke = URL.revokeObjectURL.bind(URL);
  URL.createObjectURL = blob => { const url = create(blob); blobs.set(url, blob); return url; };
  URL.revokeObjectURL = url => { setTimeout(() => { blobs.delete(url); revoke(url); }, 60000); };
  document.addEventListener('click', event => {
    const anchor = event.target.closest?.('a[download]');
    if (!anchor || !anchor.href.startsWith('blob:')) return;
    event.preventDefault();
    const blob = blobs.get(anchor.href);
    if (!blob) return;
    const reader = new FileReader();
    reader.onload = () => MagpieAndroidDownloads.saveBase64(anchor.download || 'magpie-download', blob.type || 'application/octet-stream', String(reader.result).split(',')[1]);
    reader.readAsDataURL(blob);
  }, true);
})();
