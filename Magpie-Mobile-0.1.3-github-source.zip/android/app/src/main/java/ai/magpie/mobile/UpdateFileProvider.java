package ai.magpie.mobile;

import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.*;

/** Grants the system installer read access to one verified APK, never other files. */
public final class UpdateFileProvider extends ContentProvider {
  static final String AUTHORITY = "ai.magpie.mobile.updates";
  @Override public boolean onCreate() { return true; }
  private File resolve(Uri uri) throws FileNotFoundException {
    if (!AUTHORITY.equals(uri.getAuthority()) || uri.getPathSegments().size() != 2
        || !uri.getPathSegments().get(0).equals("apk")
        || !uri.getLastPathSegment().matches("[a-f0-9]{64}\\.apk")) throw new FileNotFoundException();
    File file = new File(new File(getContext().getCacheDir(), "updates"), uri.getLastPathSegment());
    if (!file.isFile()) throw new FileNotFoundException();
    return file;
  }
  @Override public String getType(Uri uri) { return "application/vnd.android.package-archive"; }
  @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
    if (!"r".equals(mode)) throw new FileNotFoundException("Read only");
    return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
  }
  @Override public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
    try {
      File file = resolve(uri);
      String[] columns = projection == null ? new String[] {OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE} : projection;
      MatrixCursor cursor = new MatrixCursor(columns); Object[] row = new Object[columns.length];
      for (int i=0;i<columns.length;i++) {
        if (OpenableColumns.DISPLAY_NAME.equals(columns[i])) row[i] = "Magpie-Mobile-update.apk";
        else if (OpenableColumns.SIZE.equals(columns[i])) row[i] = file.length();
      }
      cursor.addRow(row); return cursor;
    } catch (FileNotFoundException e) { return null; }
  }
  @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
  @Override public int update(Uri uri, ContentValues values, String where, String[] args) { throw new UnsupportedOperationException(); }
  @Override public int delete(Uri uri, String where, String[] args) { throw new UnsupportedOperationException(); }
}
