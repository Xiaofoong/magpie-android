package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.Date;

/** System controls are reachable without adding a startup dashboard to Magpie. */
public final class BackgroundProtectionActivity extends Activity {
  private TextView status;
  static boolean exempt(Context c) {
    PowerManager power = c.getSystemService(PowerManager.class);
    return power != null && power.isIgnoringBatteryOptimizations(c.getPackageName());
  }

  static void request(Activity activity) {
    try {
      activity.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + activity.getPackageName())));
    } catch (RuntimeException e) {
      try { activity.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
      catch (RuntimeException ignored) { Toast.makeText(activity, "请在系统电池设置中允许 Magpie 后台运行", Toast.LENGTH_LONG).show(); }
    }
  }

  static void offerOnce(Activity activity) {
    if (activity.isFinishing() || exempt(activity) || GatewayService.prefs(activity).getBoolean("background_asked", false)) return;
    GatewayService.prefs(activity).edit().putBoolean("background_asked", true).apply();
    new AlertDialog.Builder(activity).setTitle("允许锁屏后继续运行")
      .setMessage("Magpie 需要在后台持续接收请求。请允许它不受电池优化限制；持续运行会增加耗电。手机的后台活动和自启动限制也需要在系统设置中允许。")
      .setPositiveButton("允许后台运行", (d, n) -> request(activity))
      .setNeutralButton("查看后台保护", (d, n) -> activity.startActivity(new Intent(activity, BackgroundProtectionActivity.class)))
      .setNegativeButton("稍后", null).show();
  }

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(26, 26, 30));
    getWindow().setNavigationBarColor(Color.rgb(26, 26, 30));
    LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
    int pad = Math.round(20 * getResources().getDisplayMetrics().density); body.setPadding(pad, pad, pad, pad);
    body.setBackgroundColor(Color.rgb(26, 26, 30));
    TextView title = words("后台保护", 23); body.addView(title);
    status = words("", 15); body.addView(status);
    body.addView(words("允许后台运行、关闭电池优化，并在最近任务中锁定 Magpie。手机厂商的省电限制需要你在系统设置中允许。", 15));
    button(body, "允许不受电池优化限制", () -> request(this));
    button(body, "系统应用设置（后台活动 / 自启动）", () -> open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
    button(body, "允许通知 / 查看前台通知", () -> open(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())));
    Switch reboot = new Switch(this); reboot.setText("重启手机后恢复上次运行的网关"); reboot.setTextColor(Color.rgb(237, 237, 241));
    reboot.setPadding(0, pad, 0, pad); reboot.setChecked(GatewayService.prefs(this).getBoolean("restore_on_boot", true));
    reboot.setOnCheckedChangeListener((v, on) -> GatewayService.prefs(this).edit().putBoolean("restore_on_boot", on).apply()); body.addView(reboot);
    body.addView(words("异常退出和本机服务无响应时会自动重试。手动停止网关后不会自动重启。系统强制停止、厂商清理和网络断开仍可能导致离线。", 14));
    button(body, "检查 App 更新", () -> startActivity(new Intent(this, UpdateActivity.class)));
    button(body, "查看恢复记录与日志", () -> new AlertDialog.Builder(this).setTitle("运行日志").setMessage(GatewayService.logs(this)).setPositiveButton("关闭", null).show());
    button(body, "返回 Magpie", () -> { startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)); finish(); });
    ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(body); setContentView(scroll);
  }

  @Override public void onResume() { super.onResume();
    if (status == null) return;
    long recovered = GatewayService.prefs(this).getLong("last_recovery", 0);
    String when = recovered == 0 ? "暂无" : DateFormat.getDateTimeInstance().format(new Date(recovered));
    status.setText("电池优化豁免：" + (exempt(this) ? "已允许" : "尚未允许")
      + "\n通知：" + (getSystemService(NotificationManager.class).areNotificationsEnabled() ? "已允许" : "未允许")
      + "\n网关：" + GatewayService.message
      + "\n自动重试次数：" + GatewayService.prefs(this).getInt("recovery_count", 0)
      + "\n上次重试：" + when + "\n");
  }

  private TextView words(String value, int size) { TextView text = new TextView(this); text.setText(value); text.setTextSize(size); text.setTextColor(Color.rgb(237,237,241)); text.setPadding(0, 12, 0, 12); return text; }
  private void button(LinearLayout body, String label, Runnable action) {
    Button button = new Button(this); button.setText(label); button.setAllCaps(false); button.setOnClickListener(v -> action.run()); body.addView(button, new LinearLayout.LayoutParams(-1, -2));
  }
  private void open(Intent intent) { try { startActivity(intent); } catch (RuntimeException e) { Toast.makeText(this, "请从系统设置打开 Magpie 的应用设置", Toast.LENGTH_LONG).show(); } }
}
