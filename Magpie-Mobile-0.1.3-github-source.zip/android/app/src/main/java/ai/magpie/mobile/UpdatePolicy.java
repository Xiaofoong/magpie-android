package ai.magpie.mobile;

import java.net.URI;
import java.security.MessageDigest;

/** Pure validation rules, shared by manual and automatic update checks. */
final class UpdatePolicy {
  static final long MAX_APK = 200L * 1024 * 1024;
  static String repository(String input) {
    String value = input.trim();
    if (value.startsWith("https://github.com/")) value = value.substring(19);
    if (value.endsWith("/")) value = value.substring(0, value.length() - 1);
    if (value.endsWith(".git")) value = value.substring(0, value.length() - 4);
    if (!value.matches("[A-Za-z0-9][A-Za-z0-9_.-]{0,99}/[A-Za-z0-9][A-Za-z0-9_.-]{0,99}"))
      throw new IllegalArgumentException("请填写 GitHub 用户名/仓库名");
    return value;
  }
  static URI secure(String value) {
    URI uri = URI.create(value);
    String host = uri.getHost();
    if (!"https".equals(uri.getScheme()) || host == null || uri.getUserInfo() != null
        || uri.getFragment() != null || (uri.getPort() != -1 && uri.getPort() != 443))
      throw new IllegalArgumentException("更新地址必须为 GitHub HTTPS 地址");
    if (!host.equals("api.github.com") && !host.equals("github.com")
        && !host.endsWith(".githubusercontent.com")) throw new IllegalArgumentException("更新地址不是 GitHub");
    return uri;
  }
  static void releaseAsset(String value, String repo) {
    URI uri = secure(value);
    if (!"github.com".equals(uri.getHost()) || uri.getRawQuery() != null
        || !uri.getRawPath().startsWith("/" + repository(repo) + "/releases/download/"))
      throw new IllegalArgumentException("安装包必须来自所设仓库的 Releases");
    for (String segment : uri.getPath().split("/")) if (segment.equals(".") || segment.equals("..") || segment.indexOf(92) >= 0) throw new IllegalArgumentException("更新地址路径不合法");
  }
  static void digest(String value) {
    if (value == null || !value.matches("[a-fA-F0-9]{64}")) throw new IllegalArgumentException("更新缺少 SHA-256 校验值");
  }
  static void size(long value) {
    if (value < 1024 || value > MAX_APK) throw new IllegalArgumentException("更新包大小不合法");
  }
  static boolean sameHash(String expected, byte[] actual) {
    digest(expected);
    StringBuilder text = new StringBuilder();
    for (byte b : actual) text.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
    return MessageDigest.isEqual(expected.toLowerCase(java.util.Locale.ROOT).getBytes(java.nio.charset.StandardCharsets.US_ASCII), text.toString().getBytes(java.nio.charset.StandardCharsets.US_ASCII));
  }
}
