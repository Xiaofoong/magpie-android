package ai.magpie.mobile;

/** Compatibility redirect for old activity links. */
public final class ManageActivity extends android.app.Activity {
  @Override
  public void onCreate(android.os.Bundle state) {
    super.onCreate(state);
    startActivity(new android.content.Intent(this, MainActivity.class));
    finish();
  }
}
