package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.widget.*;
import org.json.JSONObject;

/** Update controls do not add an outer dashboard to the original Web page. */
public final class UpdateActivity extends Activity {
  private LinearLayout body;
  boolean waitingForPermission;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(26,26,30)); getWindow().setNavigationBarColor(Color.rgb(26,26,30));
    body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
    int pad = Math.round(20 * getResources().getDisplayMetrics().density); body.setPadding(pad,pad,pad,pad); body.setBackgroundColor(Color.rgb(26,26,30));
    ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(body); setContentView(scroll);
    AppUpdates.attach(this); render();
  }
  @Override public void onResume() {
    super.onResume(); AppUpdates.attach(this); render();
    if (waitingForPermission) {
      waitingForPermission=false;
      if (getPackageManager().canRequestPackageInstalls()) AppUpdates.install(this);
    }
  }
  @Override public void onDestroy() { AppUpdates.detach(this); super.onDestroy(); }
  void render() {
    if (body==null || isDestroyed()) return;
    body.removeAllViews();
    text("App 更新",24);
    JSONObject build=AppUpdates.build(this);
    text("安卓版："+build.optString("versionName","未知")+"\n内置核心："+build.optString("upstreamVersion","未知"),15);
    String repo=AppUpdates.repository(this);
    text(repo.isEmpty()?"尚未设置发布仓库，自动更新还未启用":"更新仓库："+repo,14);
    text(AppUpdates.message,16);
    if(AppUpdates.working() && AppUpdates.progress>=0) {
      ProgressBar progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100); progress.setProgress(AppUpdates.progress); body.addView(progress);
      text(AppUpdates.progress+"%",13);
    }
    button("检查安卓版更新",!AppUpdates.working(),()->AppUpdates.check(this,true));
    if(AppUpdates.newer(this)) {
      AppUpdates.Info next=AppUpdates.available;
      text("可安装："+next.versionName+"\n上游版本："+next.upstream+"\n大小："+String.format(java.util.Locale.ROOT,"%.1f MB",next.size/1048576.0),15);
      if(!next.notes.isEmpty()) text(next.notes,14);
      if(AppUpdates.downloaded(this)) button("安装已下载更新",!AppUpdates.working(),()->AppUpdates.install(this));
      else button("下载并验证安装包",!AppUpdates.working(),()->AppUpdates.download(this));
    }
    Switch auto=new Switch(this);auto.setText("自动检查安卓版更新（每 6 小时）");auto.setTextColor(Color.rgb(237,237,241));auto.setChecked(GatewayService.prefs(this).getBoolean("update_auto_check",true));
    auto.setOnCheckedChangeListener((v,on)->GatewayService.prefs(this).edit().putBoolean("update_auto_check",on).apply());body.addView(auto);
    button("设置 GitHub 发布仓库",!AppUpdates.working(),()->{
      EditText field=new EditText(this);field.setSingleLine(true);field.setText(repo);field.setHint("用户名/仓库名");
      new AlertDialog.Builder(this).setTitle("公开的更新发布仓库").setMessage("填写发布 Magpie 安卓 APK 的专用仓库。不要填写 GitHub 密码或令牌。")
        .setView(field).setNegativeButton("取消",null).setPositiveButton("保存",(d,n)->{
          try{AppUpdates.setRepository(this,field.getText().toString());render();}
          catch(RuntimeException e){new AlertDialog.Builder(this).setMessage(e.getMessage()).setPositiveButton("关闭",null).show();}
        }).show();
    });
    button("查看官方发布记录",true,()->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://github.com/yetone/magpie-releases/releases"))));
    text("官方发布后，仍需通过安卓构建验证才能成为可安装更新。安装包会校验 SHA-256、包名、版本和当前 App 签名；安装须在系统界面确认。覆盖安装保留应用数据，更新期间网关会短暂中断。",14);
    button("返回 Magpie",true,()->{startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));finish();});
  }
  private void text(String value,int size){TextView text=new TextView(this);text.setText(value);text.setTextSize(size);text.setTextColor(Color.rgb(237,237,241));text.setPadding(0,12,0,12);body.addView(text);}
  private void button(String title,boolean enabled,Runnable action){Button button=new Button(this);button.setText(title);button.setAllCaps(false);button.setEnabled(enabled);button.setOnClickListener(v->action.run());body.addView(button,new LinearLayout.LayoutParams(-1,-2));}
}
