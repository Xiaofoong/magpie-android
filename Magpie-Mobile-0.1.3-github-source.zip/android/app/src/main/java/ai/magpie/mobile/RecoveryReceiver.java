package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.os.*;

/** Restores only a gateway the user left running, within Android's start rules. */
public final class RecoveryReceiver extends BroadcastReceiver {
  static final String RECOVER = "ai.magpie.mobile.RECOVER";
  private static Intent recovery(Context c) { return new Intent(c, RecoveryReceiver.class).setAction(RECOVER); }

  static void cancel(Context c) {
    PendingIntent pending = PendingIntent.getBroadcast(c, 46, recovery(c), PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
    if (pending != null) c.getSystemService(AlarmManager.class).cancel(pending);
    c.getSystemService(NotificationManager.class).cancel(8);
  }

  static void schedule(Context c) {
    if (!GatewayService.prefs(c).getBoolean("wanted", false)) return;
    // Inexact alarms are not an exemption from Android 12's FGS start rules.
    if (Build.VERSION.SDK_INT >= 31 && !BackgroundProtectionActivity.exempt(c)) {
      limited(c); return;
    }
    try {
      PendingIntent pending = PendingIntent.getBroadcast(c, 46, recovery(c), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
      c.getSystemService(AlarmManager.class).setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 30000, pending);
    } catch (RuntimeException e) { limited(c); }
  }

  private static boolean userStopped(Context c) {
    if (Build.VERSION.SDK_INT < 30) return false;
    try {
      long lastStart = GatewayService.prefs(c).getLong("last_user_start", 0);
      for (ApplicationExitInfo exit : c.getSystemService(ActivityManager.class).getHistoricalProcessExitReasons(null, 0, 10)) {
        if (c.getPackageName().equals(exit.getProcessName()))
          return exit.getTimestamp() > lastStart && exit.getReason() == ApplicationExitInfo.REASON_USER_REQUESTED;
      }
    } catch (RuntimeException ignored) {}
    return false;
  }

  @Override public void onReceive(Context context, Intent intent) {
    if (!GatewayService.prefs(context).getBoolean("wanted", false)) return;
    String action = intent.getAction();
    boolean boot = Intent.ACTION_BOOT_COMPLETED.equals(action);
    boolean update = Intent.ACTION_MY_PACKAGE_REPLACED.equals(action);
    if (!boot && !update && !RECOVER.equals(action)) return;
    if (boot && !GatewayService.prefs(context).getBoolean("restore_on_boot", true)) return;
    // A task-manager Stop must not be undone by a previously scheduled alarm.
    // Package updates were also USER_REQUESTED before Android 14.
    if (!update && userStopped(context)) {
      GatewayService.prefs(context).edit().putBoolean("wanted", false).commit(); cancel(context); return;
    }
    if (!boot && !update && Build.VERSION.SDK_INT >= 31 && !BackgroundProtectionActivity.exempt(context)) { limited(context); return; }
    try { context.startForegroundService(new Intent(context, GatewayService.class).setAction(RECOVER)); }
    catch (RuntimeException e) { limited(context); }
  }

  static void limited(Context c) {
    NotificationManager manager = c.getSystemService(NotificationManager.class);
    manager.createNotificationChannel(new NotificationChannel(GatewayService.CHANNEL, "Magpie 网关", NotificationManager.IMPORTANCE_LOW));
    if (!manager.areNotificationsEnabled()) return;
    PendingIntent open = PendingIntent.getActivity(c, 8, new Intent(c, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    manager.notify(8, new Notification.Builder(c, GatewayService.CHANNEL)
      .setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("Magpie 后台恢复受限制")
      .setContentText("点击重新连接；请允许后台运行并关闭电池优化")
      .setContentIntent(open).setAutoCancel(true).build());
  }
}
