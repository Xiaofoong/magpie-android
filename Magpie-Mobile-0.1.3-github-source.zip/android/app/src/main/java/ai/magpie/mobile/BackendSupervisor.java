package ai.magpie.mobile;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/** Owns one backend at a time, without depending on Activity or Android lifecycle. */
final class BackendSupervisor implements Runnable {
  interface Host {
    Process start() throws Exception;
    boolean healthy();
    void starting();
    void ready();
    void retry(String reason, long delayMillis);
  }

  static final class Policy {
    final long startup, poll, healthEvery, minimumRetry, maximumRetry, stable;
    final int failedChecks;
    Policy(long startup, long poll, long healthEvery, int failedChecks,
        long minimumRetry, long maximumRetry, long stable) {
      this.startup = startup; this.poll = poll; this.healthEvery = healthEvery;
      this.failedChecks = failedChecks; this.minimumRetry = minimumRetry;
      this.maximumRetry = maximumRetry; this.stable = stable;
    }
    static Policy production() { return new Policy(45000, 250, 20000, 3, 1000, 60000, 120000); }
  }

  private final Host host;
  private final Policy policy;
  private volatile boolean stopped;
  private volatile Process child;
  private volatile Thread worker;
  private final Object processLock = new Object();

  BackendSupervisor(Host host) { this(host, Policy.production()); }
  BackendSupervisor(Host host, Policy policy) { this.host = host; this.policy = policy; }

  boolean isStopped() { return stopped; }

  void stop() {
    stopped = true;
    Thread thread = worker;
    if (thread != null) thread.interrupt();
    synchronized (processLock) { if (child != null) child.destroy(); }
  }

  @Override public void run() {
    worker = Thread.currentThread();
    long delay = policy.minimumRetry;
    try {
      while (!stopped) {
        Process process = null;
        long readyAt = 0;
        String reason = "网关进程已退出";
        try {
          host.starting();
          if (stopped) break;
          // Starting can block briefly. Never block the Android main thread in stop().
          process = host.start();
          synchronized (processLock) {
            child = process;
            if (stopped) process.destroy();
          }
          long until = now() + policy.startup;
          boolean ready = false;
          while (!stopped && process.isAlive() && now() < until) {
            if (host.healthy()) { ready = true; break; }
            Thread.sleep(policy.poll);
          }
          if (stopped) break;
          if (!ready) throw new IOException(process.isAlive() ? "本机网关启动超时" : "网关启动时退出（" + process.exitValue() + "）");
          readyAt = now();
          host.ready();
          int failed = 0;
          while (!stopped) {
            if (process.waitFor(policy.healthEvery, TimeUnit.MILLISECONDS)) {
              reason = "网关异常退出（" + process.exitValue() + "）";
              break;
            }
            if (stopped) break;
            failed = host.healthy() ? 0 : failed + 1;
            if (failed >= policy.failedChecks) { reason = "本机网关连续健康检查失败"; break; }
          }
        } catch (InterruptedException e) {
          if (stopped) break;
          reason = "网关监测中断";
        } catch (Exception e) {
          reason = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        } finally {
          terminate(process);
          synchronized (processLock) { if (child == process) child = null; }
        }
        if (stopped) break;
        if (readyAt != 0 && now() - readyAt >= policy.stable) delay = policy.minimumRetry;
        host.retry(reason, delay);
        try { Thread.sleep(delay); }
        catch (InterruptedException e) { if (stopped) break; }
        delay = Math.min(policy.maximumRetry, delay > policy.maximumRetry / 2 ? policy.maximumRetry : delay * 2);
      }
    } finally {
      terminate(child);
      child = null;
      worker = null;
    }
  }

  private static long now() { return System.nanoTime() / 1000000L; }

  private static void terminate(Process process) {
    if (process == null) return;
    process.destroy();
    try { if (!process.waitFor(2000, TimeUnit.MILLISECONDS)) process.destroyForcibly(); }
    catch (InterruptedException e) { process.destroyForcibly(); Thread.currentThread().interrupt(); }
  }
}
