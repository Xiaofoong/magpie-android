#!/usr/bin/env python3
"""Build the Android APK; CI can stop at an unsigned, aligned package.
Signing keys are never created implicitly and never included in APK assets.
"""
import json, os, pathlib, re, shutil, subprocess, zipfile
import xml.etree.ElementTree as ET
root = pathlib.Path(__file__).resolve().parent
project = root.parent
sdk = pathlib.Path(os.environ['ANDROID_SDK_ROOT'])
bt = sdk / 'android-15'
if not bt.exists(): bt = sdk / 'build-tools' / '35.0.1'
platform = sdk / 'android-35' / 'android.jar'
if not platform.exists(): platform = sdk / 'platforms' / 'android-35' / 'android.jar'
ecj = pathlib.Path(os.environ['ECJ_JAR'])
info = json.loads(pathlib.Path(os.environ.get('MAGPIE_BUILD_INFO', root/'release.json')).read_text())
code = info['versionCode']; name = info['versionName']
if type(code) is not int or not 1 <= code <= 2100000000: raise ValueError('invalid Android versionCode')
if not re.fullmatch(r'[0-9A-Za-z.+_-]{1,100}', name): raise ValueError('invalid Android versionName')
unsigned = os.environ.get('MAGPIE_UNSIGNED') == '1'
out = root/'build'
if out.exists(): shutil.rmtree(out)
for folder in ('gen','classes','dex'): (out/folder).mkdir(parents=True, exist_ok=True)
def run(args, **kw): subprocess.run([str(a) for a in args], check=True, **kw)
ns = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android',ns)
manifest = ET.parse(root/'app/src/main/AndroidManifest.xml')
manifest.getroot().set('{'+ns+'}versionCode', str(code))
manifest.getroot().set('{'+ns+'}versionName', name)
manifest.write(out/'AndroidManifest.xml', encoding='utf-8', xml_declaration=True)
run([bt/'aapt2','compile','--dir',root/'app/src/main/res','-o',out/'res.zip'])
run([bt/'aapt2','link','-I',platform,'--manifest',out/'AndroidManifest.xml','--java',out/'gen','-o',out/'unsigned.apk',out/'res.zip'])
sources = list((root/'app/src/main/java').rglob('*.java')) + list((out/'gen').rglob('*.java'))
run(['java','-jar',ecj,'-1.8','-proc:none','-bootclasspath',str(platform)+os.pathsep+str(bt/'core-lambda-stubs.jar'),'-d',out/'classes',*sources])
run([bt/'d8','--lib',platform,'--min-api','28','--output',out/'dex',*list((out/'classes').rglob('*.class'))])
with zipfile.ZipFile(out/'unsigned.apk','a',compression=zipfile.ZIP_DEFLATED) as z:
    z.write(out/'dex/classes.dex','classes.dex')
    for asset in (root/'app/src/main/assets').rglob('*'):
        if asset.is_file() and asset.name != 'mobile-release.json': z.write(asset,'assets/'+str(asset.relative_to(root/'app/src/main/assets')))
    z.writestr('assets/mobile-release.json',json.dumps(info,ensure_ascii=False))
    libs = root/'app/src/main/jniLibs/arm64-v8a'
    for name in ('libmagpie.so','libbun.so'):
        if not (libs/name).is_file(): raise FileNotFoundError('missing ARM64 runtime '+name)
        z.write(libs/name,'lib/arm64-v8a/'+name)
run([bt/'zipalign','-f','-p','4',out/'unsigned.apk',out/'aligned.apk'])
filename='Magpie-Mobile-'+info['versionName']+'-arm64'+('-unsigned' if unsigned else '')+'.apk'
final=pathlib.Path(os.environ.get('MAGPIE_APK_OUTPUT',project/'deliverables'/filename))
final.parent.mkdir(parents=True,exist_ok=True)
if unsigned:
    shutil.copyfile(out/'aligned.apk',final)
else:
    signing=pathlib.Path(os.environ.get('SIGNING_DIR',project/'private-signing'))
    password=signing/'password.txt'; keystore=signing/'magpie-mobile.p12'
    if not password.is_file() or not keystore.is_file(): raise RuntimeError('Existing update signing key required: set SIGNING_DIR or build MAGPIE_UNSIGNED=1')
    env=dict(os.environ,MAGPIE_SIGN_PASS=password.read_text().strip())
    run([bt/'apksigner','sign','--v2-signing-enabled','true','--v3-signing-enabled','true','--ks',keystore,'--ks-key-alias','mobile','--ks-pass','env:MAGPIE_SIGN_PASS','--out',final,out/'aligned.apk'],env=env)
    verify=subprocess.check_output([str(bt/'apksigner'),'verify','--print-certs',str(final)],text=True)
    actual=next(x.split(': ',1)[1] for x in verify.splitlines() if 'certificate SHA-256 digest:' in x)
    if actual.lower()!=info['signerSha256'].lower(): final.unlink(); raise RuntimeError('Signing certificate differs from update channel')
    print('APK update signing certificate verified')
run([bt/'aapt','dump','badging',final],stdout=open(out/'badging.txt','w'))
print('Built', final, 'bytes=', final.stat().st_size)
