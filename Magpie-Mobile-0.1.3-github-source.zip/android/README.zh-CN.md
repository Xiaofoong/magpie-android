# Magpie Mobile 0.1.3 — Web 直入、后台保护与更新

0.1.3 保留下面的后台保护，加入 APK 更新页、GitHub 发布渠道及自动构建流程；内置核心已更新到官方 0.1.1762。手机打开仍直接进入原版供应商页。预设更新仓库尚未部署验证，当前不能宣称自动更新已启用。部署步骤与当前构建说明见根目录 README.md。

本轮通过核心接口契约、宿主网关聊天/流式/DNS/配置保留测试，以及更新规则和 APK 编译签名检查；没有完成 ARM64 手机安装器、后台长时间运行测试。以下为 0.1.2 后台机制的历史说明，其中历史版本号和核心不变说明不适用于 0.1.3。

打开 App 仍自动进入原版 Magpie Web 的供应商页，没有启动首页或外层管理工具栏。此次改进后台运行和异常恢复；不改变 Web 页面、账号存储位置、内置 Go/Bun 核心及端口。

适用 Android 9.0+ ARM64 手机。包名与个人升级签名保持一致，versionCode=5。覆盖安装保留数据，请勿先卸载。

## 本次变化

- 前台服务一直监护内置网关。进程异常退出或启动失败时自动重试，间隔从 1 秒逐步增加，最多 60 秒；稳定运行两分钟后恢复较短的重试间隔。
- 启动阶段最多等待 45 秒；运行后每 20 秒检查本机管理健康接口和端口，连续三次失败后重建进程。检查不调用外部模型，不会因互联网短暂断开就重启网关。
- 保持部分 CPU 唤醒锁；较旧安卓在连接 Wi-Fi 时额外使用 Wi-Fi 锁。Android 14+ 的旧高性能 Wi-Fi 锁已经映射为受限制的低延迟锁，不能靠它保证锁屏网络在线。
- 从最近任务移除界面不会主动停止服务。系统回收后的 sticky 服务恢复、保留运行意愿的开机/覆盖安装恢复均保留。手机重启后恢复可以在后台保护中关闭。
- 服务被异常销毁时，在安卓允许后台启动的条件下安排一次非精确恢复；未获电池豁免等情况下会提示从通知重新打开。没有申请精确闹钟、悬浮窗或无障碍权限，也没有用不可见服务规避系统限制。
- 停止通知中的“停止网关”会持久保存停止状态并取消恢复任务。检测到系统记录的用户停止时，不用恢复闹钟强行重新启动。部分厂商将划掉任务也记为用户停止，这种情况仍需系统后台权限和任务锁定。
- 避免重复进程：监护线程持有文件锁；启动前只会清理 PID 记录、可执行路径和 UID 都匹配本应用的残留网关进程。
- 网络变化时更新安卓 DNS。保留脱敏后的轮转日志，以及重试次数/时间，供排查后台掉线。

## 安装后的设置

1. 允许通知，方便看到持续运行状态和停止入口。
2. 按首次提示允许“不受电池优化限制”。
3. 在手机系统的 Magpie 应用设置中允许后台运行/自启动，并在最近任务中锁定 Magpie。
4. 日后从通知中的“后台保护”，或长按 App 图标的“后台保护”快捷方式重新进入。

常驻运行会增加耗电。用户强制停止、系统/厂商清理、重启过程或网络断开仍可能中断服务，不能保证永不掉线。进程重启会中断当时正在进行的连接；自动恢复面向后续请求。

## 验证与限制

- 真实子进程故障注入测试通过：启动失败退避、进程被杀后恢复、连续本机健康失败后恢复、显式停止清理子进程并停止重试、重试等待期取消、启动未就绪超时重建。
- Android 资源、Java/D8、APK 签名、Manifest/ABI 检查通过；正式包不含测试入口。签名沿用之前版本，内置 Go/Bun 文件与 0.1.1 保持相同。
- 本轮没有 ARM64 手机的长时间锁屏、Doze、厂商清理、开机广播实测。宿主进程测试不代替手机系统和实际网关的完整运行测试。

## 构建

```sh
ANDROID_SDK_ROOT=/absolute/path/to/sdk ECJ_JAR=/absolute/path/to/ecj.jar python3 android/build.py
```

子进程监护测试无需 Android 设备：

```sh
java -jar /path/to/ecj.jar -1.8 -proc:none -d build-supervisor android/app/src/main/java/ai/magpie/mobile/BackendSupervisor.java android/tests/BackendSupervisorTest.java
java -cp build-supervisor ai.magpie.mobile.BackendSupervisorTest
```

后台行为依据 Android 官方文档：
- https://developer.android.com/training/monitoring-device-state/doze-standby
- https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start
- https://developer.android.com/develop/background-work/services/fgs/handle-user-stopping

源码 ZIP 含用于后续覆盖升级的个人签名密钥，请私有保管，不要公开分享整个 ZIP。对外只分享 APK。内置核心仍为之前的 0.2.0-native 编译文件；Android 包版本为 0.1.2，表示 Web 直入方案的后台更新。
