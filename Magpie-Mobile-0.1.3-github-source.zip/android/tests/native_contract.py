#!/usr/bin/env python3
"""Native editing contract against the real process; local fixture data only."""
import json,os,pathlib,subprocess,tempfile,time,urllib.request,urllib.error,socket,sys
binary=str(pathlib.Path(sys.argv[1]).resolve())
with tempfile.TemporaryDirectory(prefix='magpie-native-contract-') as h:
 root=pathlib.Path(h);c=root/'.config/magpie';c.mkdir(parents=True)
 (c/'settings.json').write_text(json.dumps({'lang':'system','proxy':'direct','redact':True}))
 (c/'providers.json').write_text(json.dumps({'providers':[{'id':'fixture','name':'Original','key':'fixture-key','chat':'http://127.0.0.1:19999/v1','models':['one','two'],'headers':{'X-Keep':'retained'},'maxRPM':7}]}))
 env={k:v for k,v in os.environ.items() if 'proxy' not in k.lower() and k not in ['CODEX_HOME','CLAUDE_CONFIG_DIR','GEMINI_CLI_HOME']}
 key='native-contract-key-0123456789'
 env.update(HOME=h,XDG_CONFIG_HOME=str(root/'.config'),XDG_CACHE_HOME=str(root/'.cache'),XDG_DATA_HOME=str(root/'.local/share'),MAGPIE_NO_ACCOUNTS='1',MAGPIE_TEST_SANDBOX=h,MAGPIE_WEB_KEY=key,MAGPIE_NATIVE_ADDR='127.0.0.1:3431',MAGPIE_ADDR='127.0.0.1:3425',MAGPIE_ANDROID_LAN='0',DO_NOT_TRACK='1')
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 def req(path,body=None,auth=True):
  r=urllib.request.Request('http://127.0.0.1:3431'+path,None if body is None else json.dumps(body).encode(),{'Authorization':'Bearer '+key if auth else '','Content-Type':'application/json'})
  with opener.open(r,timeout=15) as response:return json.load(response)
 with open(root/'log','w') as log:
  p=subprocess.Popen([binary,'web','--no-open','--gateway'],env=env,stdout=log,stderr=log)
  try:
   for _ in range(150):
    try:
     req('/mobile/health')
     with socket.create_connection(('127.0.0.1',3430),timeout=1):pass
     break
    except Exception:time.sleep(.1)
   try:req('/mobile/health',auth=False);raise AssertionError('unauthenticated native management was accepted')
   except urllib.error.HTTPError as e:assert e.code==401
   print('PASS native management key is required')
   req('/mobile/settings',{'theme':'dark'})
   settings=json.loads((c/'settings.json').read_text());assert settings['proxy']=='direct' and settings['lang']=='system' and settings['redact'] is True and settings['theme']=='dark'
   print('PASS settings edit preserves unrelated user choices')
   req('/mobile/provider/save',{'id':'fixture','name':'Renamed','key':''})
   provider=json.loads((c/'providers.json').read_text())['providers'][0]
   assert provider['key']=='fixture-key' and provider['headers']=={'X-Keep':'retained'} and provider['maxRPM']==7 and provider['models']==['one','two']
   print('PASS small native editor preserves API key, headers, models and advanced limits')
   req('/mobile/provider/models',{'id':'fixture','models':[]})
   provider=json.loads((c/'providers.json').read_text())['providers'][0];assert provider['noModels'] is True
   req('/mobile/provider/models',{'id':'fixture','models':['two']})
   provider=json.loads((c/'providers.json').read_text())['providers'][0];assert provider['models']==['two'] and not provider.get('noModels')
   print('PASS model selection can disable every model and re-enable a chosen model')
   req('/mobile/provider/save',{'new':True,'name':'Second fixture','key':'second-key','chat':'https://api.example.test/v1','models':['test-model']})
   providers=json.loads((c/'providers.json').read_text())['providers'];assert len(providers)==2 and providers[1]['key']=='second-key'
   print('PASS native provider creation persists a separate provider')
   export=req('/mobile/backup/export',{'pass':'fixture-backup-password'})
   assert export.get('data')
   request=urllib.request.Request('http://127.0.0.1:3430/api/backup/import',json.dumps({'data':export['data'],'pass':'fixture-backup-password','agents':False,'library':False}).encode(),{'Cookie':'magpie_web_3430='+key,'Content-Type':'application/json'})
   with opener.open(request,timeout=20) as response:restored=json.load(response)
   assert any(p['key']=='fixture-key' for p in json.loads((c/'providers.json').read_text())['providers'])
   print('PASS encrypted native backup export and existing backup import round trip')

  finally:p.terminate();p.wait(timeout=15)
