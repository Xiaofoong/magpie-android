package ai.magpie.mobile;
import java.net.*;
import java.util.*;
public final class LanAddressesTest {
  public static void main(String[] args)throws Exception{
    List<InetAddress> addresses=new ArrayList<>();
    for(String value:Arrays.asList("127.0.0.1","0.0.0.0","169.254.1.2","224.0.0.1","::1","::","fe80::1","ff02::1","fd12:3456::2","192.168.1.8","192.168.1.8"))addresses.add(InetAddress.getByName(value));
    List<String> urls=LanAddresses.apiUrls(addresses);
    if(urls.size()!=2||!urls.get(0).equals("http://192.168.1.8:3425/v1")||!urls.get(1).startsWith("http://[fd12:3456:")||!urls.get(1).endsWith("]:3425/v1"))throw new AssertionError(urls);
    if(!LanAddresses.apiUrls(Collections.<InetAddress>emptyList()).isEmpty())throw new AssertionError("stale address");
    System.out.println("LAN address policy passed: IPv4 first, deduplication, bracketed IPv6, unsafe/unusable addresses excluded");
  }
}
