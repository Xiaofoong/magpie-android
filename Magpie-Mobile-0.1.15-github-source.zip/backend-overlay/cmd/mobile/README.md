# Android launcher and native editing API

The APK runs `cmd/mobile` as an extracted ARM64 executable, with a private HOME,
Android DNS servers and Bun supplied by its foreground service. The command
keeps the existing Magpie gateway and JSON API on loopback for the native
Android screens. It never opens the HTML interface.

`MAGPIE_NATIVE_ADDR=127.0.0.1:3431` enables the additional native editing
endpoints. Every endpoint requires `Authorization: Bearer <MAGPIE_WEB_KEY>`;
the Android service supplies that random app-private key. `/mobile/health`
participates in service readiness. Native provider edits merge into the
stored provider, and a blank API-key field preserves the stored key. An empty
native model selection means no models, rather than the upstream default of
all models. Native settings edits preserve omitted values. Auto-updating the
executable is disabled because Android owns APK replacement.

`POST /mobile/backup/export` requires an 8-character-or-longer password and
returns the upstream encrypted backup as base64; Android writes it using the
system document picker. Import uses the existing authenticated backup API.

Run `android/tests/native_contract.py` against a host build for these contracts,
and `android/tests/smoke.py` for the original gateway path. Both isolate their
files and use fixture credentials. `android/tests/NativeInstrumentation.java`
checks actual Android Views against a locally forwarded fixture backend;
its test build contains no ARM64 backend and is not the shipped APK.

## WorkBuddy account files

`POST /mobile/accounts/import-workbuddy` uses the same loopback management key. JSON body: `data` (the JSON file as a string), `commit` (false for a read-only preview). Supports provider/secret array entries, accounts wrappers and region/auth/account objects. Preview returns only name, site, status and a safe explanation. Commit adopts the existing community provider, skips existing or repeated UIDs, and calls the plugin host import API; the plugin owns credential writes, refresh and normal gateway routing. Import failures are per-row and never include tokens. Existing auth-store read/parse failures abort instead of treating stored accounts as empty. The Android activity uses a system document picker and confirmation, limits files to 1 MB/200 accounts and keeps file contents only in memory. Tests use synthetic secrets, never user credentials.
