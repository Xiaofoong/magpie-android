package main

import (
	"context"
	"encoding/json"
	"errors"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/yetone/magpie/internal/plugin"
	"github.com/yetone/magpie/internal/testenv"
)

func TestMain(m *testing.M) { os.Exit(testenv.Run(m)) }

const cnFixture = `{"provider":"codebuddy","uid":"cn-user","nickname":"Fixture CN","secret":{"accessToken":"fixture-access-cn","refreshToken":"fixture-refresh-cn","expiresAt":1800000000,"domain":"copilot.tencent.com","uid":"cn-user"}}`
const aiFixture = `{"region":"international","auth":{"accessToken":"fixture-access-ai","refreshToken":"fixture-refresh-ai","expiresIn":3600,"refreshExpiresIn":86400,"tokenType":"Bearer","domain":"www.workbuddy.ai"},"account":{"uid":"ai-user","nickname":"Fixture AI","enterpriseId":"fixture-team"}}`

func TestImportFormatsAndTimeUnits(t *testing.T) {
	for _, data := range []string{"[" + cnFixture + "]", cnFixture, `{"accounts":[` + cnFixture + `]}`} {
		rows, e := parseImport(data)
		if e != nil || len(rows) != 1 {
			t.Fatal("batch format", e)
		}
		a, e := normalizeImport(rows[0])
		if e != nil || a.site != "workbuddy" || a.auth["expires"] != int64(1800000000000) {
			t.Fatal("CN mapping/time", e)
		}
	}
	rows, e := parseImport(aiFixture)
	if e != nil {
		t.Fatal(e)
	}
	a, e := normalizeImport(rows[0])
	if e != nil || a.site != "workbuddy-ai" || a.auth["expires"] != int64(1) || a.auth["enterpriseId"] != "fixture-team" || a.auth["refresh"] != "fixture-refresh-ai" {
		t.Fatal("AI mapping, relative lifetime, enterprise", e)
	}
	for _, input := range []string{`null`, `[]`, `{"accounts":{}}`, cnFixture + "garbage", strings.Repeat("x", 1<<20+1)} {
		if _, e := parseImport(input); e == nil {
			t.Fatal("invalid input accepted")
		}
	}
}
func TestImportRejectsMismatchAndUntrustedDomain(t *testing.T) {
	for _, data := range []string{strings.Replace(cnFixture, "copilot.tencent.com", "evil.invalid", 1), strings.Replace(aiFixture, "international", "cn", 1), strings.Replace(cnFixture, `"uid":"cn-user"}`, `"uid":"other"}`, 1), strings.Replace(cnFixture, `"refreshToken":"fixture-refresh-cn"`, `"refreshToken":""`, 1)} {
		rows, e := parseImport(data)
		if e != nil {
			continue
		}
		if _, e := normalizeImport(rows[0]); e == nil {
			t.Fatal("unsafe/mismatched credential accepted")
		}
	}
}
func importHarness(t *testing.T) map[string]map[string]any {
	t.Helper()
	oa, ol, os, or, od := adoptImport, listImport, saveImport, readImport, discoveryOffImport
	t.Cleanup(func() { adoptImport, listImport, saveImport, readImport, discoveryOffImport = oa, ol, os, or, od })
	all := map[string]map[string]any{}
	readImport = func() (map[string]map[string]any, error) { return all, nil }
	discoveryOffImport = func() bool { return false }
	adoptImport = func(context.Context, string) error { return nil }
	listImport = func(context.Context) ([]plugin.Provider, error) {
		return []plugin.Provider{{ID: "workbuddy", Spec: wbPackage}, {ID: "workbuddy-ai", Spec: wbPackage}}, nil
	}
	saveImport = func(_ context.Context, id string, a map[string]any) (string, error) {
		key := id + "#" + a["uid"].(string)
		all[key] = a
		return key, nil
	}
	return all
}
func callImport(t *testing.T, data string, commit bool) string {
	t.Helper()
	body, _ := json.Marshal(map[string]any{"data": data, "commit": commit})
	w := httptest.NewRecorder()
	importAccounts(w, httptest.NewRequest("POST", "/mobile/accounts/import-workbuddy", strings.NewReader(string(body))))
	return w.Body.String()
}
func TestImportPreviewIsReadOnlyCommitKeepsDuplicates(t *testing.T) {
	all := importHarness(t)
	data := "[" + cnFixture + "," + aiFixture + "," + cnFixture + "]"
	preview := callImport(t, data, false)
	if len(all) != 0 || strings.Contains(preview, "fixture-access") || strings.Contains(preview, "fixture-refresh") || strings.Count(preview, `"status":"ready"`) != 2 || !strings.Contains(preview, `"status":"duplicate"`) {
		t.Fatal("preview wrote, leaked or miscounted accounts")
	}
	committed := callImport(t, data, true)
	if len(all) != 2 || strings.Count(committed, `"status":"imported"`) != 2 {
		t.Fatal("did not import both sites")
	}
	old := all["workbuddy#cn-user"]["refresh"]
	again := callImport(t, strings.ReplaceAll(data, "fixture-refresh-cn", "new-fixture-refresh"), true)
	if len(all) != 2 || all["workbuddy#cn-user"]["refresh"] != old || strings.Count(again, `"status":"duplicate"`) != 3 {
		t.Fatal("repeat replaced an existing credential")
	}
}
func TestImportPartialFailureDoesNotLeakOrLoseOthers(t *testing.T) {
	all := importHarness(t)
	save := saveImport
	saveImport = func(ctx context.Context, id string, a map[string]any) (string, error) {
		if id == "workbuddy-ai" {
			return "", errors.New("fixture-refresh-sensitive")
		}
		return save(ctx, id, a)
	}
	response := callImport(t, "["+cnFixture+","+aiFixture+"]", true)
	if len(all) != 1 || !strings.Contains(response, `"status":"failed"`) || strings.Contains(response, "sensitive") {
		t.Fatal("partial failure leaked or lost successful account")
	}
	readImport = func() (map[string]map[string]any, error) {
		return nil, errors.New("已有账号文件损坏，已停止导入以保护原账号")
	}
	response = callImport(t, cnFixture, true)
	if len(all) != 1 || !strings.Contains(response, `"error"`) {
		t.Fatal("corrupt storage did not stop import")
	}
}
