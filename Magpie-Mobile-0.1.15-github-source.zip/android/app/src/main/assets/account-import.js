(() => {
  if (location.origin !== 'http://127.0.0.1:3430' || window.top !== window || window.__magpieAccountImport) return;
  window.__magpieAccountImport = true;
  const reconcile = () => {
    const add = document.getElementById('addProvider');
    const parent = document.getElementById('view-providers');
    if (!add || !parent || document.getElementById('android-workbuddy-import')) return;
    const button = document.createElement('button');
    button.id = 'android-workbuddy-import'; button.type = 'button'; button.className = 'text';
    button.textContent = '导入 WorkBuddy / CodeBuddy 账号';
    button.style.cssText = 'display:block;align-self:flex-start;flex:none;max-width:100%;white-space:normal;text-align:left;margin:12px 4px';
    button.onclick = () => location.assign('magpie-mobile://import-workbuddy');
    // The sticky .after-list becomes invisible while Add sheet is in view.
    // Keep this independent entry before it, visible in empty and open sheets.
    parent.insertBefore(button, parent.querySelector('.after-list'));
  };
  let scheduled = 0, active = true;
  const observer = new MutationObserver(() => {
    if (!active || scheduled) return;
    scheduled = requestAnimationFrame(() => { scheduled = 0; if (active) reconcile(); });
  });
  const observe = () => observer.observe(document.documentElement,{childList:true,subtree:true});
  window.addEventListener('pagehide',() => { active = false; observer.disconnect(); if (scheduled) cancelAnimationFrame(scheduled); scheduled = 0; });
  window.addEventListener('pageshow',() => { active = true; observe(); reconcile(); });
  observe(); reconcile();
})();
