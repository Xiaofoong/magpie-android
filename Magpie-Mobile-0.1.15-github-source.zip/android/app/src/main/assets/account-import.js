(() => {
  if (location.origin !== 'http://127.0.0.1:3430' || window.top !== window || window.__magpieAccountImport) return;
  window.__magpieAccountImport = true;
  const reconcile = () => {
    const add = document.getElementById('addProvider');
    if (!add?.parentElement || document.getElementById('android-workbuddy-import')) return;
    const button = document.createElement('button');
    button.id = 'android-workbuddy-import'; button.type = 'button'; button.className = 'text';
    button.textContent = '导入 WorkBuddy / CodeBuddy 账号';
    button.style.cssText = 'display:block;max-width:100%;white-space:normal;text-align:left;margin-top:8px';
    button.onclick = () => location.assign('magpie-mobile://import-workbuddy');
    add.parentElement.append(button);
  };
  let scheduled = 0, active = true;
  const observer = new MutationObserver(() => {
    if (!active || scheduled) return;
    scheduled = requestAnimationFrame(() => { scheduled = 0; if (active) reconcile(); });
  });
  const observe = () => observer.observe(document.documentElement,{childList:true,subtree:true});
  window.addEventListener('pagehide',() => { active = false; observer.disconnect(); if (scheduled) cancelAnimationFrame(scheduled); scheduled = 0; });
  window.addEventListener('pageshow',() => { active = true; observe(); reconcile(); });
  observe(); reconcile();
})();
