package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.WindowManager;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import org.json.*;

/** Local file picker -> safe backend preview -> explicit import confirmation. */
public final class AccountImportActivity extends Activity {
  private NativeUi ui;
  private final Handler main=new Handler(Looper.getMainLooper());
  private String pending="", message="支持账号数组、accounts 列表，以及 auth + account 单账号文件。";
  private JSONArray accounts=new JSONArray();
  private boolean busy, committed, changed, destroyed;
  private int generation;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
    ui=new NativeUi(this);render();
  }
  private void render() {
    if(destroyed) return;
    LinearLayout body=ui.screen();
    ui.header(body,"导入账号","WorkBuddy · CodeBuddy","账号",()->leave());
    LinearLayout info=ui.card();
    ui.add(info,ui.label(busy?"正在处理…":committed?"导入结果":"从 JSON 文件导入",21,NativeUi.INK,true));ui.gap(info,10);
    ui.add(info,ui.label(message,14,NativeUi.MUTED,false));ui.gap(info,18);
    ui.primary(info,pending.isEmpty()?"选择 JSON 文件":"换一个文件",!busy,"download",()->pick());
    ui.add(body,info);ui.gap(body,22);
    int ready=0, imported=0;
    if(accounts.length()>0) {
      ui.section(body,committed?"处理明细":"账号预览");
      LinearLayout list=ui.card();
      for(int i=0;i<accounts.length();i++) {
        JSONObject a=accounts.optJSONObject(i);if(a==null)continue;
        String status=a.optString("status");if("ready".equals(status))ready++;if("imported".equals(status))imported++;
        if(i>0)ui.divider(list);
        ui.add(list,ui.label(a.optString("name","账号"),16,NativeUi.INK,true));ui.gap(list,6);
        String site=a.optString("site");if(!site.isEmpty()) {ui.add(list,ui.label(site,12,NativeUi.ACCENT,false));ui.gap(list,6);}
        ui.add(list,ui.label(a.optString("detail"),13,"imported".equals(status)?NativeUi.GREEN:NativeUi.MUTED,false));
      }
      ui.add(body,list);ui.gap(body,18);
    }
    if(!committed && !pending.isEmpty()) {
      LinearLayout note=ui.card();
      ui.add(note,ui.label("凭证仅保存在本机应用数据中。确认后由对应站点的插件续期和使用；令牌刷新可能使原工具的旧登录失效。首次导入可能需要下载 WorkBuddy 插件。",13,NativeUi.MUTED,false));
      ui.gap(note,18);final int count=ready;
      ui.primary(note,"确认导入 "+count+" 个账号",!busy && count>0,"check",()->request(true));ui.add(body,note);ui.gap(body,18);
    }
    ui.secondary(body,committed?"完成并返回 Magpie":"返回 Magpie",!busy,()->leave());
  }
  private void pick() {
    Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
    try {startActivityForResult(intent,81);}catch(ActivityNotFoundException e){message="设备没有文件选择器";render();}
  }
  @Override protected void onActivityResult(int request,int result,Intent data) {
    super.onActivityResult(request,result,data);
    if(request!=81 || result!=RESULT_OK || data==null || data.getData()==null)return;
    final Uri uri=data.getData();final int ticket=++generation;
    busy=true;pending="";accounts=new JSONArray();committed=false;message="正在读取文件并生成预览，不会导入账号。";render();
    new Thread(()->{
      String content;
      try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()) {
        if(in==null)throw new IOException();byte[] buffer=new byte[8192];int n;
        while((n=in.read(buffer))!=-1){if(out.size()+n>1024*1024)throw new IOException();out.write(buffer,0,n);}
        content=new String(out.toByteArray(),StandardCharsets.UTF_8);
      }catch(Exception e){main.post(()->{if(destroyed || ticket!=generation)return;busy=false;message="无法读取文件，请选择不超过 1 MB 的 JSON 导出文件。";render();});return;}
      final String file=content;
      main.post(()->{if(destroyed || ticket!=generation)return;pending=file;request(false);});
    },"magpie-import-file").start();
  }
  private void request(boolean commit) {
    final String content=pending;final int ticket=++generation;
    busy=true;message=commit?"正在导入，请稍候。已有账号会保留。":"正在识别格式与检查重复账号…";render();
    new Thread(()->{
      try {
        NativeApi api=new NativeApi(GatewayService.webKey(this));
        JSONObject response=NativeApi.object(api.post("/mobile/accounts/import-workbuddy",NativeApi.obj("data",content,"commit",commit)));
        JSONArray rows=response.optJSONArray("accounts");if(rows==null)throw new IOException();
        main.post(()->{
          if(destroyed || ticket!=generation)return;
          busy=false;accounts=rows;committed=commit;
          int added=0,skip=0,invalid=0;
          for(int i=0;i<rows.length();i++){String s=rows.optJSONObject(i).optString("status");if("imported".equals(s))added++;else if("duplicate".equals(s))skip++;else if(!"ready".equals(s))invalid++;}
          changed|=added>0;
          message=commit?"已导入 "+added+" 个，跳过重复 "+skip+" 个，未导入 "+invalid+" 个。返回后刷新供应商查看模型和登录状态。":"已识别 "+rows.length()+" 个账号。请核对地区和结果后确认导入。";
          if(commit)pending="";
          render();
        });
      }catch(Exception e){main.post(()->{
        if(destroyed || ticket!=generation)return;busy=false;
        message="处理未完成，请确认网关正在运行。可重新选择文件重试；已导入的账号会自动跳过。";
        // Only display explicitly safe, structured messages from our local API.
        try {String safe=new JSONObject(e.getMessage()==null?"":e.getMessage()).optString("error");if(!safe.isEmpty() && safe.length()<150)message=safe;}catch(Exception ignored){}
        render();
      });}
    },"magpie-import-accounts").start();
  }
  private void leave(){if(busy)return;if(changed)setResult(RESULT_OK);pending="";finish();}
  @Override public void onBackPressed(){leave();}
  @Override protected void onDestroy(){destroyed=true;generation++;pending="";accounts=new JSONArray();main.removeCallbacksAndMessages(null);super.onDestroy();}
}
