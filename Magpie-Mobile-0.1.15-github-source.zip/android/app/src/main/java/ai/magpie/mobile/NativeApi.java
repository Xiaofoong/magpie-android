package ai.magpie.mobile;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import org.json.*;

/** Only authenticated JSON endpoints are used by the Android screens. */
final class NativeApi {
  private final String key;

  NativeApi(String key) {
    this.key = key;
  }

  Object get(String path) throws Exception {
    return request("GET", path, null);
  }

  Object post(String path, JSONObject body) throws Exception {
    return request("POST", path, body == null ? new JSONObject() : body);
  }

  Object request(String method, String path, JSONObject body) throws Exception {
    String base = path.startsWith("/mobile/") ? "http://127.0.0.1:3431" : "http://127.0.0.1:3430";
    HttpURLConnection c = (HttpURLConnection) new URL(base + path).openConnection();
    c.setConnectTimeout(4000);
    c.setReadTimeout(path.contains("plugins/add") || path.contains("import-workbuddy") ? 300000 : 45000);
    c.setRequestMethod(method);
    c.setInstanceFollowRedirects(false);
    c.setRequestProperty("Cookie", "magpie_web_3430=" + key);
    c.setRequestProperty("Authorization", "Bearer " + key);
    c.setRequestProperty("Accept", "application/json");
    c.setRequestProperty("Origin", "http://127.0.0.1:3430");
    try {
      if (body != null) {
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        try (OutputStream o = c.getOutputStream()) {
          o.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
      }
      int status = c.getResponseCode();
      InputStream in = status >= 400 ? c.getErrorStream() : c.getInputStream();
      String text = "";
      if (in != null)
        try (InputStream source = in;
            ByteArrayOutputStream out = new ByteArrayOutputStream()) {
          byte[] b = new byte[8192];
          int n, total = 0;
          while ((n = source.read(b)) != -1) {
            total += n;
            if (total > 16 * 1024 * 1024) throw new IOException("返回数据过大");
            out.write(b, 0, n);
          }
          text = new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
      if (status >= 400)
        throw new IOException(text.trim().isEmpty() ? "请求失败（" + status + "）" : text.trim());
      if (status == 204 || text.trim().isEmpty()) return new JSONObject();
      return new JSONTokener(text).nextValue();
    } finally {
      c.disconnect();
    }
  }

  static JSONObject obj(Object... values) {
    JSONObject o = new JSONObject();
    try {
      for (int i = 0; i < values.length; i += 2) o.put((String) values[i], values[i + 1]);
    } catch (JSONException e) {
      throw new IllegalArgumentException(e);
    }
    return o;
  }

  static JSONObject object(Object v) {
    return v instanceof JSONObject ? (JSONObject) v : new JSONObject();
  }

  static JSONArray array(Object v) {
    return v instanceof JSONArray ? (JSONArray) v : new JSONArray();
  }

  static String enc(String s) {
    try {
      return URLEncoder.encode(s, "UTF-8");
    } catch (Exception e) {
      return "";
    }
  }
}
