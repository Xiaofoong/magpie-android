package ai.magpie.mobile;
import android.app.Activity;
import android.content.*;
/** Test-only gateway state; no native process runs in the UI test APK. */
final class GatewayService {
 static boolean running=true,starting=false;
 static String webKey(Context c){return "offline-ui-fixture-key";}
 static String message="网关运行中 · 127.0.0.1:3425";
 static boolean listening;
 static SharedPreferences prefs(Context c){
  if(c instanceof BackgroundProtectionActivity){String scenario=((Activity)c).getIntent().getStringExtra("scenario");running=!"stopped".equals(scenario)&&!"starting".equals(scenario);starting="starting".equals(scenario);message=starting?"正在自动连接本地网关…":running?"网关运行中 · 127.0.0.1:3425":"网关已停止";}
  SharedPreferences prefs=c.getSharedPreferences("ui-preview",Context.MODE_PRIVATE);
  if(!listening){listening=true;android.content.ClipboardManager clipboard=c.getSystemService(android.content.ClipboardManager.class);clipboard.addPrimaryClipChangedListener(()->{if(clipboard.hasPrimaryClip())prefs.edit().putString("copied_api_url",clipboard.getPrimaryClip().getItemAt(0).coerceToText(c).toString()).apply();});}
  return prefs;
 }
 static boolean lanEnabled(Context c){return !"sharing-off".equals(((Activity)c).getIntent().getStringExtra("scenario"));}
 static String logs(Context c){return "[08:30:00] 网关启动成功\n[08:30:01] 本机健康检查通过\n[08:30:02] 等待 Agent 请求";}
}
