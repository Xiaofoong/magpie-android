package ai.magpie.mobile;
import org.json.*;
/** Offline boundary fixture. Parsing and persistence are tested in Go. */
final class NativeApi {
 NativeApi(String key){}
 Object post(String path,JSONObject request)throws Exception {
  if(!"/mobile/accounts/import-workbuddy".equals(path))throw new Exception("unexpected fixture endpoint");
  boolean commit=request.optBoolean("commit");
  return new JSONObject().put("accounts",new JSONArray().put(new JSONObject().put("name","Fixture CN").put("site","WorkBuddy（国内）").put("status",commit?"imported":"ready").put("detail",commit?"已导入；首次使用时由插件验证并续期":"格式通过，导入后验证登录状态")));
 }
 static JSONObject object(Object v){return (JSONObject)v;}
 static JSONObject obj(Object... a){JSONObject o=new JSONObject();try{for(int i=0;i<a.length;i+=2)o.put((String)a[i],a[i+1]);}catch(JSONException e){throw new IllegalArgumentException(e);}return o;}
}
