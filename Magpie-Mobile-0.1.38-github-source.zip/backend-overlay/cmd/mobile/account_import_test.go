package main

import (
	"context"
	"encoding/json"
	"errors"
	"net/http/httptest"
	"os"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/yetone/magpie/internal/plugin"
	"github.com/yetone/magpie/internal/testenv"
)

func TestMain(m *testing.M) { os.Exit(testenv.Run(m)) }

const cnFixture = `{"provider":"codebuddy","uid":"cn-user","nickname":"Fixture CN","secret":{"accessToken":"fixture-access-cn","refreshToken":"fixture-refresh-cn","expiresAt":1800000000,"domain":"copilot.tencent.com","uid":"cn-user"}}`
const aiFixture = `{"region":"international","auth":{"accessToken":"fixture-access-ai","refreshToken":"fixture-refresh-ai","expiresAt":1800000000,"refreshExpiresIn":86400,"tokenType":"Bearer","domain":"www.workbuddy.ai"},"account":{"uid":"ai-user","nickname":"Fixture AI","enterpriseId":"fixture-team"}}`
const flatFixture = `{"id":"fixture-id","label":"Fixture label","uid":"flat-cn","nickname":"Fixture flat","accessToken":"fixture-flat-access","refreshToken":"fixture-flat-refresh","expiresAt":1800000000000,"refreshExpiresAt":1801000000000,"domain":"copilot.tencent.com","edition":"cn","type":"personal","enterpriseId":""}`

func TestFlatAndDomesticFormats(t *testing.T) {
	for _, input := range []string{flatFixture, "[" + flatFixture + "]", `{"accounts":[` + flatFixture + `]}`} {
		rows, e := parseImport(input)
		if e != nil || len(rows) != 1 {
			t.Fatal("flat decode", e)
		}
		a, e := normalizeImport(rows[0])
		if e != nil || a.site != "workbuddy" || a.uid != "flat-cn" || a.auth["expires"] != int64(1800000000000) || a.auth["refreshExpiresAt"] != nil {
			t.Fatal("flat normalization", e)
		}
	}
	input := strings.ReplaceAll(strings.ReplaceAll(flatFixture, `"edition":"cn"`, `"edition":"intl"`), "copilot.tencent.com", "www.workbuddy.ai")
	rows, e := parseImport(input)
	if e != nil {
		t.Fatal(e)
	}
	a, e := normalizeImport(rows[0])
	if e != nil || a.site != "workbuddy-ai" {
		t.Fatal("flat international", e)
	}
	domestic := strings.ReplaceAll(strings.ReplaceAll(aiFixture, "international", "domestic"), "www.workbuddy.ai", "copilot.tencent.com")
	rows, e = parseImport(domestic)
	if e != nil {
		t.Fatal(e)
	}
	a, e = normalizeImport(rows[0])
	if e != nil || a.site != "workbuddy" {
		t.Fatal("domestic region", e)
	}
	bad := strings.Replace(flatFixture, `"edition":"cn"`, `"edition":"cn","region":"international"`, 1)
	rows, _ = parseImport(bad)
	if _, e = normalizeImport(rows[0]); e == nil {
		t.Fatal("conflicting edition accepted")
	}
}

func TestSelectedExportRoundTripsWithoutChangingCredentials(t *testing.T) {
	all := importHarness(t)
	rows, _ := parseImport("[" + flatFixture + "," + aiFixture + "]")
	for _, row := range rows {
		a, e := normalizeImport(row)
		if e != nil {
			t.Fatal(e)
		}
		all[a.site+"#fixture"] = a.auth
		if a.site == "workbuddy" {
			a.auth["refresh"] = "fixture-flat-refresh"
		} else {
			a.auth["refresh"] = "fixture-refresh-ai"
		}
	}
	all["unrelated-provider"] = map[string]any{"type": "oauth", "uid": "other", "access": "never-export-this", "refresh": "never-export-this-refresh"}
	all["workbuddy#desktop"] = map[string]any{"type": "oauth", "source": "desktop", "uid": "desktop", "accountId": "Desktop"}
	before, _ := json.Marshal(all)
	w := httptest.NewRecorder()
	exportAccounts(w, httptest.NewRequest("GET", "/mobile/accounts/export-workbuddy", nil))
	if strings.Contains(w.Body.String(), "fixture-flat-access") || strings.Contains(w.Body.String(), "never-export") {
		t.Fatal("export list leaked secrets/another provider")
	}
	if !strings.Contains(w.Body.String(), `"exportable":false`) || strings.Count(w.Body.String(), `"exportable":true`) != 2 {
		t.Fatal("eligibility preview incorrect")
	}
	data, e := workbuddyExportData(all, []string{"workbuddy#fixture", "workbuddy-ai#fixture", "workbuddy#fixture"})
	if e != nil {
		t.Fatal(e)
	}
	parsed, e := parseImport(data)
	if e != nil || len(parsed) != 2 {
		t.Fatal("export not importable", e)
	}
	for _, row := range parsed {
		a, e := normalizeImport(row)
		if e != nil || a.auth["access"] != all[a.site+"#fixture"]["access"] || a.auth["refresh"] != nil || a.auth["nickname"] != all[a.site+"#fixture"]["nickname"] {
			t.Fatal("round trip lost credential fields", e)
		}
	}
	for _, selection := range [][]string{nil, {"missing"}, {"unrelated-provider"}, {"workbuddy#desktop"}} {
		if _, e := workbuddyExportData(all, selection); e == nil {
			t.Fatal("invalid selection exported")
		}
	}
	body, _ := json.Marshal(map[string]any{"keys": []string{"workbuddy#fixture"}})
	w = httptest.NewRecorder()
	exportAccounts(w, httptest.NewRequest("POST", "/mobile/accounts/export-workbuddy", strings.NewReader(string(body))))
	if w.Code != 200 || !strings.Contains(w.Body.String(), "fixture-flat-refresh") || strings.Contains(w.Body.String(), "fixture-refresh-ai") {
		t.Fatal("selection endpoint exported wrong accounts")
	}
	after, _ := json.Marshal(all)
	if string(before) != string(after) {
		t.Fatal("export modified active logins")
	}
}

func TestImportFormatsAndTimeUnits(t *testing.T) {
	for _, data := range []string{"[" + cnFixture + "]", cnFixture, `{"accounts":[` + cnFixture + `]}`} {
		rows, e := parseImport(data)
		if e != nil || len(rows) != 1 {
			t.Fatal("batch format", e)
		}
		a, e := normalizeImport(rows[0])
		if e != nil || a.site != "workbuddy" || a.auth["expires"] != int64(1800000000000) {
			t.Fatal("CN mapping/time", e)
		}
	}
	rows, e := parseImport(strings.Replace(aiFixture, `"expiresAt":1800000000`, `"expiresIn":3600`, 1))
	if e != nil {
		t.Fatal(e)
	}
	a, e := normalizeImport(rows[0])
	if e != nil || a.site != "workbuddy-ai" || a.auth["expires"] != int64(0) || a.auth["enterpriseId"] != "fixture-team" || a.auth["refresh"] != nil {
		t.Fatal("AI mapping, relative lifetime, enterprise", e)
	}
	for _, input := range []string{`null`, `[]`, `{"accounts":{}}`, cnFixture + "garbage", strings.Repeat("x", 1<<20+1)} {
		if _, e := parseImport(input); e == nil {
			t.Fatal("invalid input accepted")
		}
	}
}
func TestImportRejectsMismatchAndUntrustedDomain(t *testing.T) {
	for _, data := range []string{strings.Replace(cnFixture, "copilot.tencent.com", "evil.invalid", 1), strings.Replace(aiFixture, "international", "cn", 1), strings.Replace(cnFixture, `"uid":"cn-user"}`, `"uid":"other"}`, 1), strings.Replace(cnFixture, `"accessToken":"fixture-access-cn"`, `"accessToken":""`, 1)} {
		rows, e := parseImport(data)
		if e != nil {
			continue
		}
		if _, e := normalizeImport(rows[0]); e == nil {
			t.Fatal("unsafe/mismatched credential accepted")
		}
	}
}
func importHarness(t *testing.T) map[string]map[string]any {
	t.Helper()
	oa, ol, os, or, od := adoptImport, listImport, saveImport, readImport, discoveryOffImport
	t.Cleanup(func() { adoptImport, listImport, saveImport, readImport, discoveryOffImport = oa, ol, os, or, od })
	all := map[string]map[string]any{}
	readImport = func() (map[string]map[string]any, error) { return all, nil }
	discoveryOffImport = func() bool { return false }
	adoptImport = func(context.Context, string) error { return nil }
	listImport = func(context.Context) ([]plugin.Provider, error) {
		return []plugin.Provider{{ID: "workbuddy", Spec: wbPackage}, {ID: "workbuddy-ai", Spec: wbPackage}}, nil
	}
	saveImport = func(_ context.Context, id string, a map[string]any) (string, error) {
		key := id + "#" + a["uid"].(string)
		all[key] = a
		return key, nil
	}
	return all
}
func currentFixture(data string) string {
	return strings.ReplaceAll(data, "1800000000", strconv.FormatInt(time.Now().Add(time.Hour).Unix(), 10))
}

func callImport(t *testing.T, data string, commit bool) string {
	t.Helper()
	body, _ := json.Marshal(map[string]any{"data": data, "commit": commit})
	w := httptest.NewRecorder()
	importAccounts(w, httptest.NewRequest("POST", "/mobile/accounts/import-workbuddy", strings.NewReader(string(body))))
	return w.Body.String()
}
func TestImportPreviewIsReadOnlyCommitKeepsDuplicates(t *testing.T) {
	all := importHarness(t)
	data := currentFixture("[" + cnFixture + "," + aiFixture + "," + cnFixture + "]")
	preview := callImport(t, data, false)
	if len(all) != 0 || strings.Contains(preview, "fixture-access") || strings.Contains(preview, "fixture-refresh") || strings.Count(preview, `"status":"ready"`) != 2 || !strings.Contains(preview, `"status":"duplicate"`) {
		t.Fatal("preview wrote, leaked or miscounted accounts")
	}
	committed := callImport(t, data, true)
	if len(all) != 2 || strings.Count(committed, `"status":"imported"`) != 2 {
		t.Fatal("did not import both sites")
	}
	old := all["workbuddy#cn-user"]["access"]
	again := callImport(t, strings.ReplaceAll(data, "fixture-access-cn", "new-fixture-access"), true)
	if len(all) != 2 || all["workbuddy#cn-user"]["access"] != old || strings.Count(again, `"status":"duplicate"`) != 3 {
		t.Fatal("repeat replaced an existing credential")
	}
}
func TestImportPartialFailureDoesNotLeakOrLoseOthers(t *testing.T) {
	all := importHarness(t)
	save := saveImport
	saveImport = func(ctx context.Context, id string, a map[string]any) (string, error) {
		if id == "workbuddy-ai" {
			return "", errors.New("fixture-refresh-sensitive")
		}
		return save(ctx, id, a)
	}
	response := callImport(t, currentFixture("["+cnFixture+","+aiFixture+"]"), true)
	if len(all) != 1 || !strings.Contains(response, `"status":"failed"`) || strings.Contains(response, "sensitive") {
		t.Fatal("partial failure leaked or lost successful account")
	}
	readImport = func() (map[string]map[string]any, error) {
		return nil, errors.New("已有账号文件损坏，已停止导入以保护原账号")
	}
	response = callImport(t, cnFixture, true)
	if len(all) != 1 || !strings.Contains(response, `"error"`) {
		t.Fatal("corrupt storage did not stop import")
	}
}

func TestWorkBuddyImportRejectsUnusableExpiryAndNeverCopiesRefresh(t *testing.T) {
	all := importHarness(t)
	adoptions := 0
	adoptImport = func(context.Context, string) error {
		adoptions++
		return nil
	}
	expired := strings.Replace(cnFixture, `"expiresAt":1800000000`, `"expiresAt":1700000000`, 1)
	unknown := strings.Replace(aiFixture, `"expiresAt":1800000000`, `"expiresIn":3600`, 1)
	for _, commit := range []bool{false, true} {
		result := callImport(t, "["+expired+","+unknown+"]", commit)
		if len(all) != 0 || adoptions != 0 || strings.Count(result, `"status":"reauth"`) != 2 {
			t.Fatal("unusable snapshot was allowed to activate")
		}
	}
	result := callImport(t, currentFixture(cnFixture), true)
	a := all["workbuddy#cn-user"]
	if !strings.Contains(result, `"status":"imported"`) || a["access"] != "fixture-access-cn" ||
		a["refresh"] != nil || a["refreshExpiresAt"] != nil {
		t.Fatal("valid import lost access or copied a refresh token")
	}
	export, err := workbuddyExportData(all, []string{"workbuddy#cn-user"})
	if err != nil || strings.Contains(export, "refreshToken") {
		t.Fatal("access-only account failed to export or acquired a refresh token", err)
	}
	delete(all, "workbuddy#cn-user")
	if result = callImport(t, export, true); !strings.Contains(result, `"status":"imported"`) {
		t.Fatal("access-only export cannot be re-imported")
	}
}
