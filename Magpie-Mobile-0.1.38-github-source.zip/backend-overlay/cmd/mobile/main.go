// The APK starts this executable from its extracted native-library directory.
// Its private HOME and DNS file come from Android's foreground service.
package main

import (
	"context"
	"errors"
	"log"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/yetone/magpie/internal/access"
	"github.com/yetone/magpie/internal/appdir"
	"github.com/yetone/magpie/internal/cli"
	"github.com/yetone/magpie/internal/settings"
	_ "github.com/yetone/magpie/plugins/all"
)

var version = "0.2.0-native"

func main() {
	if _, err := appdir.CheckEnv(); err != nil {
		log.Fatal(err)
	}
	if file := os.Getenv("MAGPIE_ANDROID_DNS_FILE"); filepath.IsAbs(file) {
		net.DefaultResolver = &net.Resolver{PreferGo: true, Dial: func(ctx context.Context, network, _ string) (net.Conn, error) {
			data, err := os.ReadFile(file)
			if err != nil {
				return nil, err
			}
			last := errors.New("Android has no DNS server: reconnect Wi-Fi or mobile data")
			for _, address := range strings.Fields(string(data)) {
				if net.ParseIP(address) != nil {
					address = net.JoinHostPort(address, "53")
				} else {
					host, port, err := net.SplitHostPort(address)
					n, perr := strconv.Atoi(port)
					if err != nil || perr != nil || net.ParseIP(host) == nil || n < 1 || n > 65535 {
						continue
					}
				}
				d := net.Dialer{Timeout: 3 * time.Second}
				conn, err := d.DialContext(ctx, network, address)
				if err == nil {
					return conn, nil
				}
				last = err
			}
			return nil, last
		}}
	}
	// Updating a native executable in an installed APK is Android's job.
	// Leave all other settings alone, and reject unreadable settings.
	s, err := settings.LoadChecked()
	if err != nil {
		log.Fatal(err)
	}
	s.NoAutoUpdate = true
	_, statErr := os.Stat(settings.Path())
	firstRun := errors.Is(statErr, os.ErrNotExist)
	if firstRun {
		s.Lang = "zh"
	}
	if err := settings.Save(s); err != nil {
		log.Fatal(err)
	}
	// Seed the sharing default on a new install. The Gateway card owns it
	// thereafter, unless the wrapper explicitly requires loopback only.
	if v := os.Getenv("MAGPIE_ANDROID_LAN"); v == "0" || (v == "1" && firstRun) {
		if err := access.ConfigureLAN(v == "1", false); err != nil {
			log.Fatal(err)
		}
	}
	startNativeAPI()
	cli.Main(version)
}
