"""Read an Android UI-test preference snapshot while apply() may be writing it."""
import time
import xml.etree.ElementTree as ET


def read_preferences(read_bytes, *, attempts=10, pause=time.sleep):
    if attempts < 1:
        raise ValueError('at least one preference read is required')
    for attempt in range(attempts):
        raw = read_bytes()
        try:
            root = ET.fromstring(raw)
        except ET.ParseError as error:
            # A concurrent asynchronous write can expose an empty or incomplete
            # snapshot to adb cat. Retry only parsing, never supply fake values.
            if attempt + 1 == attempts:
                raise AssertionError(
                    f'UI preference XML remained unreadable after {attempts} reads '
                    f'(last snapshot: {len(raw)} bytes)'
                ) from error
            pause(.15)
            continue
        if root.tag != 'map':
            raise AssertionError('Unexpected UI preference XML root: ' + root.tag)
        return root
