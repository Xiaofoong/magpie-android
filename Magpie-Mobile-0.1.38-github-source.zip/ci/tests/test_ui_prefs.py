import pathlib
import subprocess
import sys
import unittest
from unittest.mock import Mock

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from ui_prefs import read_preferences


class PreferenceSnapshotTests(unittest.TestCase):
    def test_complete_snapshot_keeps_actual_value_without_retry(self):
        read = Mock(return_value=b'<map><int name="float_ball_dp" value="28"/></map>')
        pause = Mock()
        saved = read_preferences(read, pause=pause)
        self.assertEqual(saved.find("int[@name='float_ball_dp']").get('value'), '28')
        read.assert_called_once()
        pause.assert_not_called()

    def test_empty_and_partial_writes_retry_until_actual_snapshot(self):
        read = Mock(side_effect=[b'', b'<map><string', b'<map><string name="copied_api_url">http://10.0.2.16:3425/v1</string></map>'])
        pause = Mock()
        saved = read_preferences(read, pause=pause)
        self.assertEqual(saved.find("string[@name='copied_api_url']").text, 'http://10.0.2.16:3425/v1')
        self.assertEqual(read.call_count, 3)
        self.assertEqual(pause.call_count, 2)

    def test_permanently_empty_or_corrupt_file_fails_with_bounded_reads(self):
        for raw in (b'', b'<map><int', b'not xml'):
            with self.subTest(raw=raw):
                read, pause = Mock(return_value=raw), Mock()
                with self.assertRaisesRegex(AssertionError, 'unreadable after 3 reads'):
                    read_preferences(read, attempts=3, pause=pause)
                self.assertEqual(read.call_count, 3)
                self.assertEqual(pause.call_count, 2)

    def test_valid_but_wrong_value_is_never_changed_or_treated_as_success(self):
        saved = read_preferences(lambda: b'<map><string name="copied_api_url">wrong</string></map>')
        self.assertNotEqual(saved.find("string[@name='copied_api_url']").text, 'http://10.0.2.16:3425/v1')
        self.assertIsNone(saved.find("int[@name='float_ball_dp']"))

    def test_unexpected_root_or_adb_error_fails_immediately(self):
        read, pause = Mock(return_value=b'<other/>'), Mock()
        with self.assertRaisesRegex(AssertionError, 'Unexpected UI preference XML root'):
            read_preferences(read, pause=pause)
        read.assert_called_once()
        pause.assert_not_called()
        error = subprocess.CalledProcessError(1, ['adb', 'shell', 'run-as'])
        read = Mock(side_effect=error)
        with self.assertRaises(subprocess.CalledProcessError):
            read_preferences(read, pause=pause)
        read.assert_called_once()


if __name__ == '__main__':
    unittest.main()
