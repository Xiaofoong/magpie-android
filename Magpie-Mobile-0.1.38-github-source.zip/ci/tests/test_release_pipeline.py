import copy,importlib.util,json,pathlib,sys,tempfile,unittest
from unittest.mock import patch
from argparse import Namespace
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'ci'))
import follow_official,package_plan,sign_release
class ReleaseContracts(unittest.TestCase):
 def setUp(self):
  self.local=json.loads((ROOT/'android/release.json').read_text())
  self.latest={'tag_name':'v0.1.1234','draft':False,'prerelease':False,'body':'fixture release'}
 def test_channel_and_version_plan(self):
  p=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local)
  self.assertEqual(p['releaseTag'],'android-v0.1.1234-r'+str(self.local['mobileRevision']))
  self.assertGreater(p['versionCode'],self.local['versionCode'])
  self.assertEqual(p['signerSha256'],self.local['signerSha256'])
 def test_every_published_apk_advances_visible_version(self):
  previous={'versionName':'0.1.5-core0.1.1886','versionCode':29886454}
  first=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local,previous)
  self.assertEqual(first['wrapperVersion'],self.local['wrapperVersion'])
  next_release={**self.latest,'tag_name':'v0.1.1235'}
  second=follow_official.plan('Xiaofoong/magpie-android',next_release,self.local,first)
  expected='.'.join(map(str,(*follow_official.app_version(self.local['wrapperVersion'])[:2],follow_official.app_version(self.local['wrapperVersion'])[2]+1)))
  self.assertEqual(second['wrapperVersion'],expected)
  self.assertTrue(second['versionName'].startswith(expected+'-core'))
  self.assertGreater(second['versionCode'],first['versionCode'])
  package_plan.merge(second,{**second,'upstreamCommit':'a'*40},self.local)
 def test_release_retry_reuses_visible_version_and_clock_cannot_downgrade(self):
  parts=list(follow_official.app_version(self.local['wrapperVersion']));parts[2]+=3
  previous_version='.'.join(map(str,parts));parts[2]+=1;expected_version='.'.join(map(str,parts))
  previous={'wrapperVersion':previous_version,'versionName':previous_version+'-core0.1.1886','versionCode':999999999}
  with patch.object(follow_official.time,'time',return_value=0):
   first=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local,previous)
   retry=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local,previous)
  self.assertEqual(first['wrapperVersion'],expected_version)
  self.assertEqual(first,retry)
  self.assertEqual(first['versionCode'],1000000000)
 def test_no_new_core_or_wrapper_does_not_publish_another_apk(self):
  previous={'versionName':'0.1.6-core0.1.1234','versionCode':29886455}
  with tempfile.TemporaryDirectory() as d,patch.object(follow_official,'channel_info',return_value=previous),patch.object(follow_official,'api',side_effect=[{'private':False},self.latest,{'draft':False}]):
   output=pathlib.Path(d)/'output'
   with patch.dict(follow_official.os.environ,{'GITHUB_OUTPUT':str(output)}):
    follow_official.probe(Namespace(repository='Xiaofoong/magpie-android',plan=str(pathlib.Path(d)/'plan.json')))
   self.assertEqual(output.read_text(),'changed=false\nui_required=false\n')
 def test_wrapper_changes_require_ui_even_on_scheduled_builds(self):
  for revision,expected in [(self.local['mobileRevision']-1,'true'),(self.local['mobileRevision'],'false')]:
   previous={'versionName':'0.1.35-core0.1.1200','versionCode':29893117,'mobileRevision':revision}
   with tempfile.TemporaryDirectory() as d,patch.object(follow_official,'channel_info',return_value=previous),patch.object(follow_official,'api',side_effect=[{'private':False},self.latest,None]):
    output=pathlib.Path(d)/'output'
    with patch.dict(follow_official.os.environ,{'GITHUB_OUTPUT':str(output)}):
     follow_official.probe(Namespace(repository='Xiaofoong/magpie-android',plan=str(pathlib.Path(d)/'plan.json')))
    self.assertEqual(output.read_text(),'changed=true\nui_required='+expected+'\n')
 def test_invalid_published_versions_fail_instead_of_resetting(self):
  for previous in [{'versionName':'unknown','versionCode':1},{'wrapperVersion':'0.1.9','versionName':'0.1.8-core0.1.1234','versionCode':1},{'versionName':'0.1.5-core0.1.1234','versionCode':True}]:
   with self.assertRaises(ValueError):follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local,previous)
 def test_reject_draft_prerelease_and_malicious_tags(self):
  for edit in [{'draft':True},{'prerelease':True},{'tag_name':'v1; echo bad'},{'tag_name':'../../elsewhere'}]:
   with self.assertRaises(ValueError):follow_official.plan('Xiaofoong/magpie-android',{**self.latest,**edit},self.local)
 def test_isolated_package_job_rejects_modified_plan(self):
  p=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local);core={**p,'upstreamCommit':'a'*40}
  self.assertEqual(package_plan.merge(p,core,self.local)['upstreamCommit'],'a'*40)
  for field,value in [('signerSha256','b'*64),('versionCode',1),('updateRepository','other/repo')]:
   with self.assertRaises(ValueError):package_plan.merge(p,{**core,field:value},self.local)
 def test_feed_hash_size_and_release_url_are_derived(self):
  p=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local)
  with tempfile.TemporaryDirectory() as d:
   apk=pathlib.Path(d)/'test.apk';apk.write_bytes(b'fixture package')
   feed=sign_release.descriptor(p,apk)
   self.assertEqual(feed['wrapperVersion'],p['wrapperVersion'])
   self.assertEqual(feed['size'],len(b'fixture package'));self.assertEqual(len(feed['sha256']),64)
   self.assertTrue(feed['apkUrl'].startswith('https://github.com/Xiaofoong/magpie-android/releases/download/android-v0.1.1234-r'+str(self.local['mobileRevision'])+'/'))
 def test_workflow_has_no_signing_secrets_in_core_job(self):
  import yaml
  workflow=yaml.load((ROOT/'.github/workflows/follow-official.yml').read_text(),Loader=yaml.BaseLoader)
  self.assertNotIn('ANDROID_KEYSTORE',json.dumps(workflow['jobs']['core']))
  self.assertIn('ANDROID_KEYSTORE',json.dumps(workflow['jobs']['package']))
  for job in workflow['jobs'].values():
   for step in job['steps']:
    if 'uses' in step:self.assertRegex(step['uses'],r'^actions/[a-z-]+@[a-f0-9]{40}$')
if __name__=='__main__':unittest.main()
