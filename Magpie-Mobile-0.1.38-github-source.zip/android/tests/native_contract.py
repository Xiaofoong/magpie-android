#!/usr/bin/env python3
"""Native editing contract against the real process; local fixture data only."""
import json,os,pathlib,subprocess,tempfile,time,urllib.request,urllib.error,socket,sys
binary=str(pathlib.Path(sys.argv[1]).resolve())
with tempfile.TemporaryDirectory(prefix='magpie-native-contract-') as h:
 root=pathlib.Path(h);c=root/'.config/magpie';c.mkdir(parents=True)
 (c/'settings.json').write_text(json.dumps({'lang':'system','proxy':'direct','redact':True}))
 (c/'providers.json').write_text(json.dumps({'providers':[{'id':'fixture','name':'Original','key':'fixture-key','chat':'http://127.0.0.1:19999/v1','models':['one','two'],'headers':{'X-Keep':'retained'},'maxRPM':7}]}))
 env={k:v for k,v in os.environ.items() if 'proxy' not in k.lower() and k not in ['CODEX_HOME','CLAUDE_CONFIG_DIR','GEMINI_CLI_HOME']}
 key='native-contract-key-0123456789'
 env.update(HOME=h,XDG_CONFIG_HOME=str(root/'.config'),XDG_CACHE_HOME=str(root/'.cache'),XDG_DATA_HOME=str(root/'.local/share'),MAGPIE_NO_ACCOUNTS='1',MAGPIE_TEST_SANDBOX=h,MAGPIE_WEB_KEY=key,MAGPIE_NATIVE_ADDR='127.0.0.1:3431',MAGPIE_ADDR='127.0.0.1:3425',MAGPIE_ANDROID_LAN='0',DO_NOT_TRACK='1')
 wifi_file=root/'wifi-addresses.txt'
 env['MAGPIE_ANDROID_WIFI_FILE']=str(wifi_file)
 opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
 def req(path,body=None,auth=True):
  r=urllib.request.Request('http://127.0.0.1:3431'+path,None if body is None else json.dumps(body).encode(),{'Authorization':'Bearer '+key if auth else '','Content-Type':'application/json'})
  with opener.open(r,timeout=15) as response:return json.load(response)
 def page_api(path,body=None):
  request=urllib.request.Request('http://127.0.0.1:3430/api/'+path,None if body is None else json.dumps(body).encode(),{'Cookie':'magpie_web_3430='+key,'Content-Type':'application/json'})
  with opener.open(request,timeout=20) as response:return json.load(response)
 with open(root/'log','w') as log:
  p=subprocess.Popen([binary,'web','--no-open','--gateway'],env=env,stdout=log,stderr=log)
  try:
   for _ in range(150):
    try:
     req('/mobile/health')
     with socket.create_connection(('127.0.0.1',3430),timeout=1):pass
     break
    except Exception:time.sleep(.1)
   try:req('/mobile/health',auth=False);raise AssertionError('unauthenticated native management was accepted')
   except urllib.error.HTTPError as e:assert e.code==401
   print('PASS native management key is required')
   wifi_file.write_text('192.168.43.27\nfd00::43\n127.0.0.1\nfe80::1%wlan0\n198.18.0.1\n192.168.43.27\n')
   assert not page_api('providers')['gateway'].get('lanURLs')
   page_api('settings/lan',{'on':True})
   # A second loopback address exercises the wildcard bind without reaching
   # another machine or depending on the runner's physical interfaces.
   with socket.create_connection(('127.0.0.2',3425),timeout=1):pass
   gateway=page_api('providers')['gateway']
   assert gateway['url']=='http://127.0.0.1:3425',gateway
   assert gateway.get('lanURLs')==['http://192.168.43.27:3425','http://[fd00::43]:3425'],gateway
   wifi_file.write_text('10.23.0.17\n')
   assert page_api('providers')['gateway'].get('lanURLs')==['http://10.23.0.17:3425']
   wifi_file.write_text('')
   assert not page_api('providers')['gateway'].get('lanURLs')
   wifi_file.write_text('10.23.0.17\n')
   page_api('settings/lan',{'on':False})
   assert not page_api('providers')['gateway'].get('lanURLs')
   try:
    with socket.create_connection(('127.0.0.2',3425),timeout=1):pass
   except ConnectionRefusedError:pass
   else:raise AssertionError('the shared listener is still open after sharing was turned off')
   print('PASS gateway card receives loopback and physical Wi-Fi addresses, follows Wi-Fi changes, and hides LAN when sharing is off')
   sample=[{'provider':'codebuddy','uid':'fixture-cn','nickname':'Fixture CN','secret':{'uid':'fixture-cn','accessToken':'fixture-access-only','refreshToken':'fixture-refresh-only','expiresAt':int(time.time()+3600),'domain':'copilot.tencent.com'}}, {'region':'international','account':{'uid':'fixture-ai','nickname':'Fixture AI'},'auth':{'accessToken':'fixture-access-ai','refreshToken':'fixture-refresh-ai','expiresIn':3600,'domain':'www.workbuddy.ai'}}]
   preview=req('/mobile/accounts/import-workbuddy',{'data':json.dumps(sample),'commit':False})
   assert [x['site'] for x in preview['accounts']]==['WorkBuddy（国内）','WorkBuddy AI（国际）']
   assert [x['status'] for x in preview['accounts']]==['ready','reauth']
   assert 'fixture-access' not in json.dumps(preview) and 'fixture-refresh' not in json.dumps(preview)
   assert not (c/'plugin-auth.json').exists()
   try:req('/mobile/accounts/import-workbuddy',{'data':json.dumps(sample),'commit':True});raise AssertionError('account discovery off was bypassed')
   except urllib.error.HTTPError as e:assert e.code==400
   assert not (c/'plugin-auth.json').exists()
   print('PASS authenticated account preview recognizes both formats without saving or exposing credentials; privacy guard blocks commit')
   flat={'edition':'cn','uid':'flat-fixture','nickname':'Flat fixture','accessToken':'fixture-flat-access','refreshToken':'fixture-flat-refresh','expiresAt':int((time.time()+3600)*1000),'domain':'copilot.tencent.com'}
   domestic={'region':'domestic','account':{'uid':'domestic-fixture','nickname':'Domestic fixture'},'auth':{'accessToken':'fixture-domestic-access','refreshToken':'fixture-domestic-refresh','domain':'copilot.tencent.com','expiresIn':3600}}
   preview=req('/mobile/accounts/import-workbuddy',{'data':json.dumps([flat,domestic]),'commit':False})
   assert [x['status'] for x in preview['accounts']]==['ready','reauth']
   assert all(x['site']=='WorkBuddy（国内）' for x in preview['accounts'])
   auths={'workbuddy#fixture':{'type':'oauth','uid':'export-cn','nickname':'Export fixture','accountId':'Export fixture','access':'fixture-export-access','refresh':'fixture-export-refresh','expires':1800000000000,'domain':'copilot.tencent.com'},'unrelated':{'type':'oauth','uid':'other','access':'other-credential','refresh':'other-refresh'}}
   (c/'plugin-auth.json').write_text(json.dumps(auths));before=(c/'plugin-auth.json').read_bytes()
   listing=req('/mobile/accounts/export-workbuddy');assert len(listing['accounts'])==1 and listing['accounts'][0]['exportable']
   assert 'fixture-export-refresh' not in json.dumps(listing) and 'other-credential' not in json.dumps(listing)
   exported=req('/mobile/accounts/export-workbuddy',{'keys':['workbuddy#fixture']});roundtrip=req('/mobile/accounts/import-workbuddy',{'data':exported['data'],'commit':False})
   assert roundtrip['accounts'][0]['status']=='duplicate'
   assert (c/'plugin-auth.json').read_bytes()==before
   try:req('/mobile/accounts/export-workbuddy',{'keys':['unrelated']});raise AssertionError('non-WorkBuddy account was exported')
   except urllib.error.HTTPError as e:assert e.code==400
   (c/'plugin-auth.json').unlink()
   print('PASS flat/domestic import formats and authenticated selected JSON export round trip; listing omits tokens and active accounts stay unchanged')
   req('/mobile/settings',{'theme':'dark'})
   settings=json.loads((c/'settings.json').read_text());assert settings['proxy']=='direct' and settings['lang']=='system' and settings['redact'] is True and settings['theme']=='dark'
   print('PASS settings edit preserves unrelated user choices')
   req('/mobile/provider/save',{'id':'fixture','name':'Renamed','key':''})
   provider=json.loads((c/'providers.json').read_text())['providers'][0]
   assert provider['key']=='fixture-key' and provider['headers']=={'X-Keep':'retained'} and provider['maxRPM']==7 and provider['models']==['one','two']
   print('PASS small native editor preserves API key, headers, models and advanced limits')
   req('/mobile/provider/models',{'id':'fixture','models':[]})
   provider=json.loads((c/'providers.json').read_text())['providers'][0];assert provider['noModels'] is True
   req('/mobile/provider/models',{'id':'fixture','models':['two']})
   provider=json.loads((c/'providers.json').read_text())['providers'][0];assert provider['models']==['two'] and not provider.get('noModels')
   print('PASS model selection can disable every model and re-enable a chosen model')
   req('/mobile/provider/save',{'new':True,'name':'Second fixture','key':'second-key','chat':'https://api.example.test/v1','models':['test-model']})
   providers=json.loads((c/'providers.json').read_text())['providers'];assert len(providers)==2 and providers[1]['key']=='second-key'
   print('PASS native provider creation persists a separate provider')
   export=req('/mobile/backup/export',{'pass':'fixture-backup-password'})
   assert export.get('data')
   request=urllib.request.Request('http://127.0.0.1:3430/api/backup/import',json.dumps({'data':export['data'],'pass':'fixture-backup-password','agents':False,'library':False}).encode(),{'Cookie':'magpie_web_3430='+key,'Content-Type':'application/json'})
   with opener.open(request,timeout=20) as response:restored=json.load(response)
   assert any(p['key']=='fixture-key' for p in json.loads((c/'providers.json').read_text())['providers'])
   print('PASS encrypted native backup export and existing backup import round trip')

  finally:p.terminate();p.wait(timeout=15)
