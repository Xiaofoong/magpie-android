#!/usr/bin/env python3
"""Exercise the actual portable gateway with a local fake OpenAI server.
No vendor credentials or remote services are used. The DNS fixture checks the
Android resolver path, including a live change to the DNS file.
"""
import contextlib, http.server, http.cookiejar, json, os, pathlib, socket, socketserver, struct, subprocess, sys, tempfile, threading, time, urllib.request, urllib.error
binary=str(pathlib.Path(sys.argv[1]).resolve())
class DNS(socketserver.BaseRequestHandler):
    def handle(self):
        data,sock=self.request
        end=12
        while data[end]: end+=data[end]+1
        end+=5
        qtype=struct.unpack('!H',data[end-4:end-2])[0]
        answer=b'\xc0\x0c'+struct.pack('!HHIH',1,1,60,4)+socket.inet_aton('127.0.0.1') if qtype==1 else b''
        sock.sendto(data[:2]+b'\x81\x80'+struct.pack('!HHHH',1,1 if answer else 0,0,0)+data[12:end]+answer,self.client_address)
class Upstream(http.server.BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def do_GET(self):
        data=json.dumps({'object':'list','data':[{'id':'mobile-test','object':'model'}]}).encode()
        self.send_response(200); self.send_header('Content-Type','application/json'); self.end_headers(); self.wfile.write(data)
    def do_POST(self):
        body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        assert self.headers.get('Authorization')=='Bearer test-fixture-key'
        if body.get('stream'):
            data='data: '+json.dumps({'id':'chatcmpl-mobile','object':'chat.completion.chunk','model':'mobile-test','choices':[{'index':0,'delta':{'content':'mobile stream ok'},'finish_reason':None}]})+'\n\ndata: '+json.dumps({'id':'chatcmpl-mobile','object':'chat.completion.chunk','model':'mobile-test','choices':[{'index':0,'delta':{},'finish_reason':'stop'}]})+'\n\ndata: [DONE]\n\n'
            kind='text/event-stream'
        else:
            data=json.dumps({'id':'chatcmpl-mobile','object':'chat.completion','model':'mobile-test','choices':[{'index':0,'message':{'role':'assistant','content':'mobile gateway ok'},'finish_reason':'stop'}],'usage':{'prompt_tokens':3,'completion_tokens':4,'total_tokens':7}})
            kind='application/json'
        self.send_response(200); self.send_header('Content-Type',kind); self.end_headers(); self.wfile.write(data.encode())

def request(url,data=None,key=None,cookie=False):
    headers={}
    if key: headers['Authorization']='Bearer '+key
    if data is not None: headers['Content-Type']='application/json'
    req=urllib.request.Request(url,json.dumps(data).encode() if data is not None else None,headers)
    return (opener if cookie else plain).open(req,timeout=25)
plain=urllib.request.build_opener(urllib.request.ProxyHandler({}))
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
with tempfile.TemporaryDirectory(prefix='magpie-mobile-smoke-') as task_home:
    h=pathlib.Path(task_home); c=h/'.config/magpie'; c.mkdir(parents=True)
    upstream=http.server.ThreadingHTTPServer(('127.0.0.1',0),Upstream)
    dns=socketserver.ThreadingUDPServer(('127.0.0.1',0),DNS)
    for s in (upstream,dns): threading.Thread(target=s.serve_forever,daemon=True).start()
    (h/'dns.txt').write_text(f'127.0.0.1:{dns.server_address[1]}\n')
    (c/'settings.json').write_text(json.dumps({'lang':'system'}))
    (c/'providers.json').write_text(json.dumps({'providers':[{'id':'fixture','name':'Mobile fixture','key':'test-fixture-key','chat':f'http://mobile-fixture.test:{upstream.server_port}/v1/chat/completions','models':['mobile-test'],'proxy':'direct'}]}))
    env={k:v for k,v in os.environ.items() if 'proxy' not in k.lower() and k not in ['CODEX_HOME','CLAUDE_CONFIG_DIR','GEMINI_CLI_HOME']}
    env.update(MAGPIE_NO_ACCOUNTS='1',HOME=str(h),XDG_CONFIG_HOME=str(h/'.config'),XDG_CACHE_HOME=str(h/'.cache'),XDG_DATA_HOME=str(h/'.local/share'),MAGPIE_TEST_SANDBOX=str(h),MAGPIE_ANDROID_DNS_FILE=str(h/'dns.txt'),MAGPIE_ANDROID_WIFI_FILE=str(h/'wifi-addresses.txt'),MAGPIE_ANDROID_LAN='1',MAGPIE_ADDR='127.0.0.1:3425',MAGPIE_WEB_KEY='test-mobile-web-key-0123456789',DO_NOT_TRACK='1')
    log=open(h/'process.log','w')
    def start():
        p=subprocess.Popen([binary,'web','--no-open','--gateway'],env=env,cwd=h,stdout=log,stderr=log)
        until=time.monotonic()+45
        while time.monotonic()<until:
            if p.poll() is not None: raise RuntimeError('backend exited: '+(h/'process.log').read_text())
            try:
                with socket.create_connection(('127.0.0.1',3430),timeout=.3): return p
            except OSError: time.sleep(.1)
        p.terminate(); raise TimeoutError('backend did not start')
    p=None
    try:
        p=start()
        saved=json.loads((c/'settings.json').read_text())
        assert saved['lang']=='system' and saved['noAutoUpdate'] is True
        assert not saved.get('lan'), 'startup enabled sharing despite existing settings'
        print('PASS user language preserved and native self-update disabled')
        try:
            request('http://127.0.0.1:3430/api/state')
            raise AssertionError('management API accepted no management key')
        except urllib.error.HTTPError as e: assert e.code==401,e.code
        request('http://127.0.0.1:3430/?k='+env['MAGPIE_WEB_KEY'],cookie=True).close()
        state=json.load(request('http://127.0.0.1:3430/api/state',cookie=True))
        assert state
        print('PASS management authentication and state API')
        request('http://127.0.0.1:3430/api/settings/lan',{'on':True},cookie=True).close()
        key=json.loads((c/'caller-keys.json').read_text())[0]['secret']
        assert key.startswith('sk-')
        try:
            request('http://127.0.0.1:3430/v1/models')
            raise AssertionError('LAN/page gateway accepted no API key')
        except urllib.error.HTTPError as e: assert e.code==401,e.code
        models=json.load(request('http://127.0.0.1:3430/v1/models',key=key))
        assert any(m['id']=='fixture/mobile-test' for m in models['data']),str(models)[:500]
        print('PASS API key protection and model catalog')
        data={'model':'fixture/mobile-test','messages':[{'role':'user','content':'hello'}]}
        reply=json.load(request('http://127.0.0.1:3425/v1/chat/completions',data,key))
        assert reply['choices'][0]['message']['content']=='mobile gateway ok',reply
        print('PASS OpenAI chat through Android DNS resolver')
        data['stream']=True
        text=request('http://127.0.0.1:3425/v1/chat/completions',data,key).read().decode()
        assert 'mobile stream ok' in text and '[DONE]' in text,text[:1000]
        print('PASS streaming response')
        (h/'dns.txt').write_text(f'not-an-ip\n127.0.0.1:{dns.server_address[1]}\n')
        data['stream']=False
        assert json.load(request('http://127.0.0.1:3425/v1/chat/completions',data,key))['choices'][0]['message']['content']=='mobile gateway ok'
        print('PASS DNS file is re-read after a network change')
        p.terminate(); p.wait(timeout=15); p=None
        p=start()
        assert json.loads((c/'settings.json').read_text())['lan'] is True
        assert json.loads((c/'caller-keys.json').read_text())[0]['secret']==key
        assert json.load(request('http://127.0.0.1:3430/api/state',cookie=True))
        print('PASS configuration/key and management cookie survive restart')
    except Exception:
        print((h/'process.log').read_text()[-6000:]); raise
    finally:
        if p is not None: p.terminate(); p.wait(timeout=15)
        upstream.shutdown(); dns.shutdown(); log.close()
