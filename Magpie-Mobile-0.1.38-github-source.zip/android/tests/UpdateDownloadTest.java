package ai.magpie.mobile;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;

public final class UpdateDownloadTest {
  private static final byte[] DATA = "0123456789".getBytes(java.nio.charset.StandardCharsets.UTF_8);
  private static final UpdateDownload.Progress QUIET = new UpdateDownload.Progress() {
    public void received(long bytes) {}
    public void retry(long bytes, int attempt) {}
  };
  private static String hash() throws Exception {
    StringBuilder hex = new StringBuilder();
    for (byte b : MessageDigest.getInstance("SHA-256").digest(DATA)) hex.append(String.format("%02x", b & 255));
    return hex.toString();
  }
  private static HttpURLConnection response(int code, String range, byte[] body, int failAt) throws Exception {
    return new HttpURLConnection(new URL("https://github.com/fixture")) {
      public void disconnect() {}
      public boolean usingProxy() { return false; }
      public void connect() {}
      public int getResponseCode() { return code; }
      public String getHeaderField(String name) { return "Content-Range".equals(name) ? range : null; }
      public long getContentLengthLong() { return body.length; }
      public InputStream getInputStream() {
        if (failAt < 0) return new ByteArrayInputStream(body);
        return new InputStream() {
          private int position;
          public int read() throws IOException {
            if (position == failAt) throw new SocketTimeoutException("simulated read timeout");
            return position < body.length ? body[position++] & 255 : -1;
          }
          public int read(byte[] bytes, int start, int length) throws IOException {
            if (position == failAt) throw new SocketTimeoutException("simulated read timeout");
            if (position == body.length) return -1;
            int count = Math.min(length, Math.min(failAt - position, body.length - position));
            System.arraycopy(body, position, bytes, start, count);
            position += count;
            return count;
          }
        };
      }
    };
  }
  private static HttpURLConnection reply(int code, String range, byte[] body, int failAt) throws IOException {
    try { return response(code, range, body, failAt); }
    catch (Exception e) { throw new IOException(e); }
  }
  private static void equal(File file, byte[] expected) throws IOException {
    if (!Arrays.equals(Files.readAllBytes(file.toPath()), expected)) throw new AssertionError("download bytes differ");
  }
  public static void main(String[] args) throws Exception {
    Path directory = Files.createTempDirectory("magpie-download-");
    File part = directory.resolve("fixture.part.apk").toFile();
    String sha = hash();
    try {
      List<Long> offsets = new ArrayList<>();
      UpdateDownload.download(part, DATA.length, sha, offset -> {
        offsets.add(offset);
        if (offset == 0) return reply(200, null, DATA, 3);
        return reply(206, "bytes 3-9/10", Arrays.copyOfRange(DATA, 3, 10), -1);
      }, QUIET);
      equal(part, DATA);
      if (!offsets.equals(Arrays.asList(0L, 3L))) throw new AssertionError("timeout restarted from zero: " + offsets);
      System.out.println("PASS timeout resumes using the existing byte offset");

      Files.write(part.toPath(), Arrays.copyOf(DATA, 4));
      int[] attempts = {0};
      try {
        UpdateDownload.download(part, DATA.length, sha, offset -> {
          if (offset != 4) throw new AssertionError("lost saved bytes");
          attempts[0]++;
          throw new SocketTimeoutException("offline");
        }, QUIET);
        throw new AssertionError("offline download succeeded");
      } catch (SocketTimeoutException expected) {}
      equal(part, Arrays.copyOf(DATA, 4));
      if (attempts[0] != 4) throw new AssertionError("unbounded retries");
      UpdateDownload.download(part, DATA.length, sha, offset -> {
        if (offset != 4) throw new AssertionError("manual retry lost progress");
        return reply(206, "bytes 4-9/10", Arrays.copyOfRange(DATA, 4, 10), -1);
      }, QUIET);
      equal(part, DATA);
      System.out.println("PASS bounded retries preserve bytes for a later retry");

      Files.write(part.toPath(), Arrays.copyOf(DATA, 4));
      UpdateDownload.download(part, DATA.length, sha, offset -> reply(200, null, DATA, -1), QUIET);
      equal(part, DATA);
      System.out.println("PASS a server ignoring Range replaces the file without duplicating bytes");

      for (String range : new String[]{"bytes 0-5/10", "bytes 4-9/11", "bytes 4-10/10", "invalid"}) {
        Files.write(part.toPath(), Arrays.copyOf(DATA, 4));
        try {
          UpdateDownload.download(part, DATA.length, sha, offset -> reply(206, range, Arrays.copyOfRange(DATA, 4, 10), -1), QUIET);
          throw new AssertionError("invalid range accepted: " + range);
        } catch (ProtocolException expected) {}
        equal(part, Arrays.copyOf(DATA, 4));
      }
      System.out.println("PASS wrong ranges and changed object lengths are refused before appending");

      byte[] damaged = DATA.clone();
      damaged[0] = 'x';
      Files.write(part.toPath(), damaged);
      try {
        UpdateDownload.download(part, DATA.length, sha, offset -> { throw new AssertionError("full file downloaded again"); }, QUIET);
        throw new AssertionError("corrupt file accepted");
      } catch (ProtocolException expected) {}
      if (part.exists()) throw new AssertionError("corrupt file was kept");
      System.out.println("PASS checksum failures discard corrupted downloads");

      Files.write(part.toPath(), DATA);
      UpdateDownload.download(part, DATA.length, sha, offset -> { throw new AssertionError("full file requested again"); }, QUIET);
      equal(part, DATA);
      if (!UpdatePolicy.releaseApiAsset("https://api.github.com/repos/Xiaofoong/magpie-android/releases/assets/123", "Xiaofoong/magpie-android"))
        throw new AssertionError("valid API asset refused");
      for (String url : new String[]{"https://api.github.com/repos/other/repo/releases/assets/123", "https://api.github.com/repos/Xiaofoong/magpie-android/releases/assets/123?x=1", "https://evil.test/123"})
        if (UpdatePolicy.releaseApiAsset(url, "Xiaofoong/magpie-android")) throw new AssertionError("wrong release API accepted");
      System.out.println("PASS completed partial file is verified locally and alternate URLs stay within the configured repository");
    } finally {
      part.delete();
      Files.delete(directory);
    }
  }
}
