package ai.magpie.testdriver;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Instrumentation;
import android.app.UiAutomation;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.util.Xml;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.io.File;
import java.io.FileOutputStream;
import org.xmlpull.v1.XmlSerializer;

/** Separate test-only package: inspecting all windows must never restart Magpie. */
public final class WindowDump extends Instrumentation {
    private Bundle arguments;
    @Override public void onCreate(Bundle args) { super.onCreate(args); arguments=args==null?new Bundle():args; start(); }
    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            UiAutomation automation = getUiAutomation();
            if ("double_tap".equals(arguments.getString("action"))) {
                float x=Float.parseFloat(arguments.getString("x"));
                float y=Float.parseFloat(arguments.getString("y"));
                tap(automation,x,y); SystemClock.sleep(60); tap(automation,x,y);
            }
            AccessibilityServiceInfo info = automation.getServiceInfo();
            info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            automation.setServiceInfo(info);
            // New accessibility connections need time to receive non-focusable
            // windows after Home/task transitions. Busy UI is still dumpable.
            try { automation.waitForIdle(500,3000); }
            catch (java.util.concurrent.TimeoutException ignored) {}
            File output = new File(getTargetContext().getFilesDir(), "windows.xml");
            try (FileOutputStream stream = new FileOutputStream(output)) {
                XmlSerializer xml = Xml.newSerializer();
                xml.setOutput(stream, "UTF-8"); xml.startDocument("UTF-8", true);
                xml.startTag(null, "hierarchy");
                for (AccessibilityWindowInfo window : automation.getWindows()) {
                    AccessibilityNodeInfo root = window.getRoot();
                    if (root != null) node(xml, root);
                }
                xml.endTag(null, "hierarchy"); xml.endDocument();
            }
            result.putString("dump", output.toString()); finish(-1, result);
        } catch (Exception error) {
            result.putString("error", error.toString()); finish(0, result);
        }
    }
    private static void tap(UiAutomation automation,float x,float y) {
        long down=SystemClock.uptimeMillis();
        MotionEvent event=MotionEvent.obtain(down,down,MotionEvent.ACTION_DOWN,x,y,0);
        event.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        if (!automation.injectInputEvent(event,true))throw new IllegalStateException("Touch down rejected");
        event.recycle();SystemClock.sleep(30);
        event=MotionEvent.obtain(down,SystemClock.uptimeMillis(),MotionEvent.ACTION_UP,x,y,0);
        event.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        if (!automation.injectInputEvent(event,true))throw new IllegalStateException("Touch up rejected");
        event.recycle();
    }
    private static String text(CharSequence value) { return value == null ? "" : value.toString(); }
    private static void node(XmlSerializer xml, AccessibilityNodeInfo node) throws Exception {
        if (!node.isVisibleToUser()) return;
        xml.startTag(null, "node");
        xml.attribute(null, "text", text(node.getText()));
        xml.attribute(null, "content-desc", text(node.getContentDescription()));
        xml.attribute(null, "class", text(node.getClassName()));
        xml.attribute(null, "package", text(node.getPackageName()));
        xml.attribute(null, "checked", String.valueOf(node.isChecked()));
        xml.attribute(null, "enabled", String.valueOf(node.isEnabled()));
        Rect bounds = new Rect(); node.getBoundsInScreen(bounds);
        xml.attribute(null, "bounds", bounds.toShortString());
        for (int index = 0; index < node.getChildCount(); index++) {
            AccessibilityNodeInfo child = node.getChild(index);
            if (child != null) node(xml, child);
        }
        xml.endTag(null, "node");
    }
}
