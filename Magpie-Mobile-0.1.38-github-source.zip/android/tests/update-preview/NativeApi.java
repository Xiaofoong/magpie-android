package ai.magpie.mobile;
import org.json.*;
/** Offline boundary fixture. Parsing and persistence are tested in Go. */
final class NativeApi {
 NativeApi(String key){}
 Object get(String path)throws Exception {
  if(path.startsWith("/api/usage?"))return new JSONObject().put("calls",96);
  if(!"/mobile/accounts/export-workbuddy".equals(path))throw new Exception("unexpected fixture endpoint");
  return new JSONObject().put("accounts",new JSONArray().put(new JSONObject().put("key","workbuddy#fixture").put("name","Fixture CN").put("site","WorkBuddy（国内）").put("exportable",true).put("detail","导出当前保存在本机的登录凭证")));
 }
 Object post(String path,JSONObject request)throws Exception {
  if("/mobile/accounts/export-workbuddy".equals(path))return new JSONObject().put("data","[]\n");
  if(!"/mobile/accounts/import-workbuddy".equals(path))throw new Exception("unexpected fixture endpoint");
  boolean commit=request.optBoolean("commit");
  return new JSONObject().put("accounts",new JSONArray().put(new JSONObject().put("name","Fixture CN").put("site","WorkBuddy（国内）").put("status",commit?"imported":"ready").put("detail",commit?"已导入当前授权，到期或失效后请在供应商页面重新登录":"可导入当前授权，到期后请重新登录")));
 }
 static JSONObject object(Object v){return (JSONObject)v;}
 static JSONObject obj(Object... a){JSONObject o=new JSONObject();try{for(int i=0;i<a.length;i+=2)o.put((String)a[i],a[i+1]);}catch(JSONException e){throw new IllegalArgumentException(e);}return o;}
}
