package ai.magpie.mobile;
import android.content.*;
import org.json.JSONObject;
/** Test-only fixture. Never compiled into the release APK. */
final class AppUpdates {
  static Info available;
  static String message="",officialVersion="0.1.3646",scenario="waiting";
  static int progress=-1;
  static boolean busy;
  static class Info { String upstream="0.1.3645",notes="优化路由与供应商体验。"; long size=59233366; }
  static JSONObject build(Context c) {
    try(java.io.InputStream in=c.getAssets().open("mobile-release.json");java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()) {
      byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
      JSONObject j=new JSONObject(new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8));
      j.put("upstreamVersion","0.1.3645");return j;
    } catch(Exception e) {throw new IllegalStateException("Missing preview build information",e);}
  }
  static String repository(Context c) {return GatewayService.prefs(c).getString("repo","Xiaofoong/magpie-android");}
  static boolean working() {return busy;}
  static void attach(UpdateActivity a) {
    scenario=a.getIntent().getStringExtra("scenario");if(scenario==null)scenario="waiting";
    available=new Info(); progress=-1;busy=false;message="检查完成";
    if(scenario.equals("latest"))officialVersion="0.1.3645";else officialVersion="0.1.3646";
    if(newer(a))available.upstream="0.1.3646";
    if(scenario.equals("downloading")){busy=true;progress=48;message="正在下载并验证更新…";}
    if(scenario.equals("error"))message="检查未完成：网络暂不可用，请稍后重试";
    if(scenario.equals("paused")){progress=50;message="下载或验证失败：timeout。已保留 50%，点击继续下载。";}
  }
  static void detach(UpdateActivity a){}
  static boolean newer(Context c){return scenario.equals("available")||scenario.equals("ready")||scenario.equals("downloading")||scenario.equals("paused");}
  static boolean downloaded(Context c){return scenario.equals("ready");}
  static void check(Context c,boolean manual){}
  static void install(UpdateActivity a){GatewayService.prefs(a).edit().putString("action","install").apply();}
  static long partial(Context a){return scenario.equals("paused")?available.size/2:0;}
  static void download(Context a){GatewayService.prefs(a).edit().putString("action","download").apply();}
  static void setRepository(Context c,String v){String repo=v.trim().isEmpty()?"":UpdatePolicy.repository(v);GatewayService.prefs(c).edit().putString("repo",repo).apply();}
}
