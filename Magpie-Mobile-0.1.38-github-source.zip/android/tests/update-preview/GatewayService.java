package ai.magpie.mobile;
import android.app.Activity;
import android.content.*;
/** Test-only gateway state; no native process runs in the UI test APK. */
final class GatewayService {
 static boolean running=true,starting=false;
 static boolean initialized;
 static final String STOP="ai.magpie.mobile.STOP";
 static void reloadFromUser(Context c){prefs(c).edit().putInt("float_reload_count",prefs(c).getInt("float_reload_count",0)+1).apply();}
 static void startFromUser(Context c){SharedPreferences p=prefs(c);if(running||starting)return;running=true;starting=false;p.edit().putBoolean("wanted",true).putInt("float_start_count",p.getInt("float_start_count",0)+1).commit();}
 static void stopFromUser(Context c){SharedPreferences p=prefs(c);running=false;starting=false;p.edit().putBoolean("wanted",false).putBoolean("float_stop_called",true).commit();}
 static String webKey(Context c){return "offline-ui-fixture-key";}
 static String message="网关运行中 · 127.0.0.1:3425";
 static boolean listening;
 static SharedPreferences prefs(Context c){
  SharedPreferences prefs=c.getSharedPreferences("ui-preview",Context.MODE_PRIVATE);
  if(!initialized){initialized=true;running=prefs.getBoolean("wanted",true);}
  if(c instanceof BackgroundProtectionActivity){String scenario=((Activity)c).getIntent().getStringExtra("scenario");running=!"stopped".equals(scenario)&&!"starting".equals(scenario);starting="starting".equals(scenario);message=starting?"正在自动连接本地网关…":running?"网关运行中 · 127.0.0.1:3425":"网关已停止";}
  if(!prefs.contains("gateway_base"))prefs.edit().putString("gateway_base","http://127.0.0.1:4545").apply();
  if(!listening){listening=true;android.content.ClipboardManager clipboard=c.getSystemService(android.content.ClipboardManager.class);clipboard.addPrimaryClipChangedListener(()->{if(clipboard.hasPrimaryClip())prefs.edit().putString("copied_api_url",clipboard.getPrimaryClip().getItemAt(0).coerceToText(c).toString()).apply();});}
  return prefs;
 }
 static boolean lanEnabled(Context c){return !"sharing-off".equals(((Activity)c).getIntent().getStringExtra("scenario"));}
 static String logs(Context c){return "[08:30:00] 网关启动成功\n[08:30:01] 本机健康检查通过\n[08:30:02] 等待 Agent 请求";}
}
