package ai.magpie.mobile;

import android.content.Context;
import android.net.*;
import java.net.InetAddress;
import java.util.*;

/** Watches physical Wi-Fi even when a VPN or cellular network is the default. */
final class LanNetwork {
  private final ConnectivityManager manager;
  private final Runnable changed;
  private final Map<Network,List<InetAddress>> networks=new HashMap<>();
  private boolean registered,failed;
  LanNetwork(Context context,Runnable listener){manager=context.getSystemService(ConnectivityManager.class);changed=listener;}
  private final ConnectivityManager.NetworkCallback callback=new ConnectivityManager.NetworkCallback(){
    @Override public void onAvailable(Network network){synchronized(LanNetwork.this){if(!registered)return;networks.put(network,new ArrayList<InetAddress>());}changed.run();}
    @Override public void onCapabilitiesChanged(Network network,NetworkCapabilities caps){
      if(!caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)||caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)){
        synchronized(LanNetwork.this){networks.remove(network);}changed.run();
      }
    }
    @Override public void onLinkPropertiesChanged(Network network,LinkProperties properties){
      synchronized(LanNetwork.this){
        if(!networks.containsKey(network))return;
        List<InetAddress> addresses=new ArrayList<>();for(LinkAddress address:properties.getLinkAddresses())addresses.add(address.getAddress());
        networks.put(network,addresses);
      }
      changed.run();
    }
    @Override public void onLost(Network network){synchronized(LanNetwork.this){networks.remove(network);}changed.run();}
  };
  synchronized void start(){
    if(registered)return;failed=false;
    try{
      if(manager==null)throw new IllegalStateException("Network state unavailable");
      NetworkRequest request=new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
          .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build();
      manager.registerNetworkCallback(request,callback);registered=true;
    }catch(RuntimeException e){failed=true;changed.run();}
  }
  void stop(){
    synchronized(this){if(registered){try{manager.unregisterNetworkCallback(callback);}catch(RuntimeException ignored){}registered=false;}networks.clear();}
  }
  synchronized boolean connected(){return !networks.isEmpty();}
  synchronized boolean unavailable(){return failed;}
  private List<InetAddress> addresses(){
    List<InetAddress> addresses=new ArrayList<>();
    for(List<InetAddress> values:networks.values())addresses.addAll(values);
    return addresses;
  }
  synchronized List<String> apiUrls(){return LanAddresses.apiUrls(addresses());}
  synchronized List<String> hosts(){return LanAddresses.hosts(addresses());}
}
