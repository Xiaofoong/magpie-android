package ai.magpie.mobile

import android.app.Activity
import android.content.Context
import android.content.Intent
import java.lang.ref.WeakReference

/** 仅保留当前可见主页的弱引用；退后台不销毁网页，也不触碰网关。 */
internal object FloatNavigation {
    private var home = WeakReference<Activity>(null)

    @JvmStatic fun resumed(activity: Activity) { home = WeakReference(activity) }
    @JvmStatic fun paused(activity: Activity) {
        if (home.get() === activity) home.clear()
    }

    fun toggle(context: Context) {
        val visible = home.get()
        if (visible != null && !visible.isFinishing && !visible.isDestroyed) {
            if (visible.moveTaskToBack(true)) return
        }
        context.startActivity(Intent(context, MainActivity::class.java)
            .putExtra("from_float", true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }
}
