package ai.magpie.mobile;

import java.io.*;
import java.net.*;
import java.security.MessageDigest;
import java.util.regex.*;

/** Resumes a hash-named private file. Only a fully verified file is installable. */
final class UpdateDownload {
  interface Connection { HttpURLConnection open(long offset) throws IOException; }
  interface Progress {
    void received(long bytes);
    void retry(long bytes, int attempt);
  }
  private static final Pattern RANGE = Pattern.compile("bytes ([0-9]+)-([0-9]+)/([0-9]+)");
  private static final int ATTEMPTS = 4;

  static void download(File part, long size, String sha256, Connection source, Progress progress) throws Exception {
    if (part.length() > size) discard(part);
    IOException last = null;
    for (int attempt = 0; attempt < ATTEMPTS; attempt++) {
      try {
        if (part.length() < size) transfer(part, size, source, progress);
        verify(part, size, sha256);
        progress.received(size);
        return;
      } catch (ProtocolException e) {
        throw e;
      } catch (IOException e) {
        last = e;
        if (attempt + 1 == ATTEMPTS) break;
        progress.retry(part.length(), attempt + 1);
        Thread.sleep(1000L << attempt);
      }
    }
    throw last;
  }

  private static void transfer(File part, long size, Connection source, Progress progress) throws IOException {
    long offset = part.length();
    progress.received(offset);
    HttpURLConnection connection = source.open(offset);
    try {
      int status = connection.getResponseCode();
      long expectedEnd = size;
      if (status == HttpURLConnection.HTTP_PARTIAL) {
        Matcher range = RANGE.matcher(String.valueOf(connection.getHeaderField("Content-Range")));
        if (!range.matches()) throw new ProtocolException("续传响应缺少有效范围");
        try {
          long start = Long.parseLong(range.group(1)), end = Long.parseLong(range.group(2));
          if (start != offset || end < start || end >= size || Long.parseLong(range.group(3)) != size)
            throw new ProtocolException("续传范围与安装包不匹配");
          expectedEnd = end + 1;
        } catch (NumberFormatException e) { throw new ProtocolException("续传范围无效"); }
      } else if (status == HttpURLConnection.HTTP_OK) {
        // A server that ignores Range sends the complete object. Replace the
        // partial file only after a successful response, never append it.
        offset = 0;
      } else {
        if (status == 408 || status == 429 || status >= 500)
          throw new IOException("更新服务器暂不可用（" + status + "）");
        throw new ProtocolException("更新服务器返回 " + status);
      }
      String encoding = connection.getHeaderField("Content-Encoding");
      if (encoding != null && !encoding.equalsIgnoreCase("identity"))
        throw new ProtocolException("续传响应使用了不支持的压缩");
      long length = connection.getContentLengthLong();
      if (length >= 0 && length != expectedEnd - offset)
        throw new ProtocolException("续传长度与安装包不匹配");
      try (InputStream in = connection.getInputStream(); OutputStream out = new FileOutputStream(part, offset > 0)) {
        byte[] buffer = new byte[32768];
        long total = offset;
        int count;
        while ((count = in.read(buffer)) != -1) {
          if (total + count > expectedEnd) throw new ProtocolException("安装包超过声明大小");
          out.write(buffer, 0, count);
          total += count;
          progress.received(total);
        }
        if (total != size) throw new EOFException("下载连接中断");
      }
    } finally { connection.disconnect(); }
  }

  private static void verify(File part, long size, String sha256) throws Exception {
    if (part.length() != size) throw new EOFException("安装包尚未下载完整");
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    try (InputStream in = new FileInputStream(part)) {
      byte[] buffer = new byte[32768];
      int count;
      while ((count = in.read(buffer)) != -1) digest.update(buffer, 0, count);
    }
    if (!UpdatePolicy.sameHash(sha256, digest.digest())) {
      discard(part);
      throw new ProtocolException("安装包 SHA-256 校验失败，请重新下载");
    }
  }

  private static void discard(File part) throws IOException {
    if (part.exists() && !part.delete()) throw new IOException("无法清理旧的下载文件");
  }
}
