package ai.magpie.mobile

import android.content.Context

/** 小球与命中窗口共用一个尺寸。保留旧版 9dp 默认值，只保存用户主动选择。 */
internal object FloatSize {
    const val MIN_DP = 9
    const val MAX_DP = 48
    const val DEFAULT_DP = 9
    const val KEY = "float_ball_dp"

    fun read(context: Context): Int = GatewayService.prefs(context)
        .getInt(KEY, DEFAULT_DP).coerceIn(MIN_DP, MAX_DP)

    fun save(context: Context, value: Int) {
        val size = value.coerceIn(MIN_DP, MAX_DP)
        if (GatewayService.prefs(context).getInt(KEY, DEFAULT_DP) != size) {
            GatewayService.prefs(context).edit().putInt(KEY, size).apply()
        }
    }
}
