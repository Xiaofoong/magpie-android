package ai.magpie.mobile;

import java.net.*;
import java.util.*;

/** Only addresses supplied by a physical Wi-Fi network are passed here. */
final class LanAddresses {
  static List<String> apiUrls(Collection<InetAddress> addresses) {
    ArrayList<String> urls = new ArrayList<>();
    for (String host : hosts(addresses)) {
      if (host.indexOf(':') >= 0) host = "[" + host + "]";
      urls.add("http://" + host + ":3425/v1");
    }
    return urls;
  }

  static List<String> hosts(Collection<InetAddress> addresses) {
    TreeSet<String> ipv4=new TreeSet<>(),ipv6=new TreeSet<>();
    for(InetAddress address:addresses){
      if(address==null||address.isAnyLocalAddress()||address.isLoopbackAddress()
          ||address.isLinkLocalAddress()||address.isMulticastAddress())continue;
      String host=address.getHostAddress();
      if(address instanceof Inet4Address)ipv4.add(host);
      else if(address instanceof Inet6Address && host.indexOf('%')<0)ipv6.add(host);
    }
    ArrayList<String> result=new ArrayList<>(ipv4);result.addAll(ipv6);return result;
  }
}
