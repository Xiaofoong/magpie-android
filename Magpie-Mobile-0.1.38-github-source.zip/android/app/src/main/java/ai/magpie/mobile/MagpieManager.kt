package ai.magpie.mobile

import android.content.Context
import android.content.Intent
import java.util.TimeZone
import java.net.URLEncoder

/** 悬浮窗只观察现有网关；不创建第二个 Go 进程，也不拥有网关生命周期。 */
internal object MagpieManager {
    data class Snapshot(val state: String, val address: String, val requests: Long?)

    fun address(context: Context): String = GatewayService.prefs(context)
        .getString("gateway_base", "http://127.0.0.1:3425")!!

    fun snapshot(context: Context, readUsage: Boolean): Snapshot {
        val state = if (GatewayService.starting) "加载中" else if (GatewayService.running) "运行中" else "已停止 / 离线"
        var count: Long? = null
        if (readUsage && GatewayService.running) {
            try {
                val zone = URLEncoder.encode(TimeZone.getDefault().id, "UTF-8")
                val body = NativeApi.`object`(NativeApi(GatewayService.webKey(context)).get("/api/usage?period=today&tz=$zone"))
                if (body.has("calls") && !body.isNull("calls")) count = body.getLong("calls")
            } catch (_: Exception) { /* 未知不能显示成 0；下次面板打开时重试。 */ }
        }
        return Snapshot(state, address(context), count)
    }

    fun start(context: Context) = GatewayService.startFromUser(context)

    fun stop(context: Context) {
        // 复用原有停止入口，取消恢复任务、释放端口的逻辑仍由 GatewayService 处理。
        GatewayService.stopFromUser(context)
    }

    fun logs(context: Context): String = GatewayService.logs(context).takeLast(1800)
}
