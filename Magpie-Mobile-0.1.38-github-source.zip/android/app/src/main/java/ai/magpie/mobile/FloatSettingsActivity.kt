package ai.magpie.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast

/** 只有用户在可见页面明确开启时才启动悬浮服务，授权返回后重新确认权限。 */
class FloatSettingsActivity : Activity() {
    private lateinit var state: TextView
    private var pendingEnable=false
    override fun onCreate(saved: Bundle?) {
        super.onCreate(saved)
        val ui=NativeUi(this);val body=ui.screen()
        ui.header(body,"悬浮小球","单击展开 / 收起 · 双击切换主页与后台。","工具") { finish() }
        val card=ui.card()
        state=ui.label("",14,NativeUi.ACCENT,true);ui.add(card,state);ui.gap(card,14)
        ui.add(card,ui.label("${FloatChrome.BALL_DP}dp 金属小球 · 青蓝玻璃面板",16,NativeUi.INK,true));ui.gap(card,10)
        ui.add(card,ui.label("拖动后自动贴边。单击展开小面板，再单击收起；双击进入供应商首页，在主页再次双击退到后台，只留小球。停止后，小球仍保留，可直接点「启动」重新运行网关。",14,NativeUi.MUTED,false))
        ui.gap(card,18);ui.primary(card,"开启悬浮小球",true,"window") { enable() }
        ui.gap(card,10);ui.secondary(card,"关闭悬浮窗",true) { FloatService.hide(this);state.postDelayed({refresh()},150) }
        ui.divider(card);ui.add(card,ui.label("关闭悬浮窗只隐藏小球；原来的网关、后台保护和自动更新继续按当前设置运行。停止网关请在小面板点「停止」。",13,NativeUi.MUTED,false));ui.add(body,card)
        ui.gap(body,20);ui.secondary(body,"悬浮窗权限设置",true) { permission() }
        ui.gap(body,12);ui.secondary(body,"后台保护设置",true) { startActivity(Intent(this,BackgroundProtectionActivity::class.java)) }
        ui.gap(body,12);ui.add(body,ui.label("允许不受电池优化限制后，划掉任务或服务意外退出会安排一次悬浮窗恢复，时间由系统调度。关闭小球会取消恢复。一加 / OxygenOS 还需允许后台活动，并在最近任务菜单锁定 Magpie；强行停止后需要重新打开 App。",13,NativeUi.MUTED,false))
    }
    override fun onResume() { super.onResume();refresh();if(pendingEnable && Settings.canDrawOverlays(this)) {pendingEnable=false;enable()} }
    private fun refresh() { if(::state.isInitialized)state.text=if(FloatService.active)"悬浮小球已开启" else if(Settings.canDrawOverlays(this))"权限已允许，可以开启" else "首次开启需要允许显示在其他应用上层" }
    private fun enable() {
        if(!Settings.canDrawOverlays(this)) {pendingEnable=true;permission();return}
        try { FloatService.enable(this);state.postDelayed({refresh()},400) }
        catch(_:RuntimeException) {Toast.makeText(this,"暂时无法开启，请保持此页面在前台重试",Toast.LENGTH_LONG).show()}
    }
    private fun permission() {
        try {startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}
        catch(_:RuntimeException) {try {startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION))}catch(_:RuntimeException){Toast.makeText(this,"请在系统设置中允许 Magpie 显示悬浮窗",Toast.LENGTH_LONG).show()}}
    }
}
