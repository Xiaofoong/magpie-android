package ai.magpie.mobile

import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings

/** 一次性的悬浮窗恢复，补充 START_STICKY；不创建第二套网关或循环唤醒。 */
class FloatRecoveryReceiver : BroadcastReceiver() {
    companion object {
        const val RECOVER = "ai.magpie.mobile.FLOAT_RECOVER"
        private const val REQUEST = 47
        private const val NOTICE = 18
        private fun intent(c: Context) = Intent(c, FloatRecoveryReceiver::class.java).setAction(RECOVER)
        private fun permitted(c: Context) = Build.VERSION.SDK_INT < 31 || BackgroundProtectionActivity.exempt(c)

        fun cancel(c: Context) {
            val pending = PendingIntent.getBroadcast(c, REQUEST, intent(c), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
            if (pending != null) {
                c.getSystemService(AlarmManager::class.java).cancel(pending)
                pending.cancel()
            }
            c.getSystemService(NotificationManager::class.java).cancel(NOTICE)
        }

        @JvmStatic fun beforeBackground(c: Context) {
            // 在 OEM 来不及派发 onTaskRemoved/onDestroy 就清理进程前，先登记一次。
            // 保留短暂的最近任务操作窗口；不是定时循环保活。
            if (FloatService.active) schedule(c, 30000)
        }

        fun schedule(c: Context, delayMs: Long = 3000) {
            if (!GatewayService.prefs(c).getBoolean("float_enabled", false) || !Settings.canDrawOverlays(c)) {
                cancel(c); return
            }
            // 普通闹钟不是后台启动豁免。只有已允许不受电池优化限制时才安排恢复。
            if (!permitted(c)) return
            try {
                val pending = PendingIntent.getBroadcast(c, REQUEST, intent(c), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                c.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + delayMs, pending)
            } catch (error: RuntimeException) {
                android.util.Log.w("MagpieFloat", "Floating recovery could not be scheduled", error)
            }
        }

        private fun userStopped(c: Context): Boolean {
            if (Build.VERSION.SDK_INT < 30) return false
            val prefs = GatewayService.prefs(c)
            val enabledAt = prefs.getLong("float_user_enabled_at", 0)
            val taskRemovedAt = prefs.getLong("float_last_task_removed", 0)
            try {
                val exit = c.getSystemService(ActivityManager::class.java)
                    .getHistoricalProcessExitReasons(null, 0, 10).firstOrNull { it.processName == c.packageName }
                if (exit != null && exit.timestamp > enabledAt && exit.reason == ApplicationExitInfo.REASON_USER_REQUESTED) {
                    // 部分系统把划掉最近任务也记为 USER_REQUESTED；只接受本服务刚收到的任务移除。
                    return taskRemovedAt == 0L || exit.timestamp - taskRemovedAt !in -2000L..10000L
                }
            } catch (_: RuntimeException) {}
            return false
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != RECOVER) return
        if (!GatewayService.prefs(context).getBoolean("float_enabled", false) || !Settings.canDrawOverlays(context)) {
            cancel(context); return
        }
        if (FloatService.active || !permitted(context) || userStopped(context)) return
        try {
            val prefs = GatewayService.prefs(context)
            prefs.edit().putLong("float_last_recovery", System.currentTimeMillis())
                .putInt("float_recovery_count", prefs.getInt("float_recovery_count", 0) + 1).commit()
            context.startForegroundService(Intent(context, FloatService::class.java))
        } catch (error: RuntimeException) {
            android.util.Log.w("MagpieFloat", "Floating recovery needs a visible user entry", error)
            val manager = context.getSystemService(NotificationManager::class.java)
            if (!manager.areNotificationsEnabled()) return
            manager.createNotificationChannel(NotificationChannel("magpie_float", "Magpie 悬浮窗", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(context, REQUEST, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            manager.notify(NOTICE, Notification.Builder(context, "magpie_float").setSmallIcon(R.drawable.ic_bird)
                .setContentTitle("点击恢复 Magpie 悬浮窗").setContentText("系统限制了后台恢复，请允许后台活动并锁定最近任务")
                .setContentIntent(open).setAutoCancel(true).build())
        }
    }
}
