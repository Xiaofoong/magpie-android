package ai.magpie.mobile

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

/** 仅负责悬浮 UI。网关依然由原有 GatewayService / BackendSupervisor 运行。 */
class FloatService : Service() {
    companion object {
        @JvmField var active = false
        const val HIDE = "ai.magpie.mobile.FLOAT_HIDE"
        private const val CHANNEL = "magpie_float"
        private const val ENABLED = "float_enabled"

        /** 用户选择持久化；与网关 wanted 独立，停止网关不隐藏小球。 */
        @JvmStatic fun enable(context: Context) {
            check(Settings.canDrawOverlays(context)) { "需要悬浮窗权限" }
            GatewayService.prefs(context).edit().putBoolean(ENABLED,true)
                .putLong("float_user_enabled_at",System.currentTimeMillis()).commit()
            try { context.startForegroundService(Intent(context,FloatService::class.java)) }
            catch (error: RuntimeException) {
                GatewayService.prefs(context).edit().putBoolean(ENABLED,false).commit()
                throw error
            }
        }
        @JvmStatic fun hide(context: Context) {
            GatewayService.prefs(context).edit().putBoolean(ENABLED,false).commit()
            FloatRecoveryReceiver.cancel(context)
            context.stopService(Intent(context,FloatService::class.java))
        }
        /** 只在用户回到可见主页时补恢复；不使用后台轮询或强行拉活。 */
        @JvmStatic fun restoreIfEnabled(activity: Activity) {
            if(!active && GatewayService.prefs(activity).getBoolean(ENABLED,false) && Settings.canDrawOverlays(activity)) {
                try { activity.startForegroundService(Intent(activity,FloatService::class.java)) }
                catch (_: RuntimeException) { /* 保留选择，下次用户回到前台再恢复。 */ }
            }
        }
    }
    private lateinit var wm: WindowManager
    private lateinit var ball: FrameLayout
    private lateinit var position: WindowManager.LayoutParams
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var alive = true
    private var attached = false
    private var reading = false
    private var lastState = ""
    private var lastCount: Long? = null
    private var logsMode = false
    private var screenOn = true
    private var screenRegistered = false
    private var ballDp = FloatSize.DEFAULT_DP
    private val resize = Runnable { if (alive && attached) resizeBall() }
    private val sizeChanges = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == FloatSize.KEY) {
            // 合并一次滑动中的连续变化；只更新现有窗口，不重启服务或网关。
            main.removeCallbacks(resize)
            main.post(resize)
        }
    }
    private val screen = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            screenOn = i.action != Intent.ACTION_SCREEN_OFF
            if (!screenOn) collapse()
            main.removeCallbacks(tick)
            if (screenOn) main.post(tick)
        }
    }
    private val tick = object : Runnable {
        override fun run() {
            if (!alive || !attached) return
            if (!Settings.canDrawOverlays(this@FloatService)) {
                GatewayService.prefs(this@FloatService).edit().putBoolean(ENABLED,false).commit()
                stopSelf(); return
            }
            refresh()
            if (screenOn) main.postDelayed(this, if (panel == null) 4000 else 6000)
        }
    }

    override fun onBind(intent: Intent?) = null
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        screenOn = getSystemService(PowerManager::class.java).isInteractive
        ballDp = FloatSize.read(this)
        GatewayService.prefs(this).registerOnSharedPreferenceChangeListener(sizeChanges)
    }
    private fun attachControls(): Boolean {
        try {
            addBall()
            // 只在权限已允许且小球已添加后进入前台；入口由可见 Activity 用户点击触发。
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Magpie 悬浮窗", NotificationManager.IMPORTANCE_LOW))
            val home = PendingIntent.getActivity(this, 40, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val hide = PendingIntent.getService(this, 41, Intent(this, FloatService::class.java).setAction(HIDE), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val note = Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_bird)
                .setContentTitle("Magpie 悬浮小球").setContentText("单击展开 / 收起 · 双击切换主页与后台")
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(home)
                .addAction(Notification.Action.Builder(null, "关闭悬浮窗", hide).build()).build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(17, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(17, note)
            active = true
            FloatRecoveryReceiver.cancel(this)
            registerReceiver(screen, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF) }, if(Build.VERSION.SDK_INT>=33) RECEIVER_NOT_EXPORTED else 0)
            screenRegistered = true
            main.post(tick)
            return true
        } catch (error: RuntimeException) {
            android.util.Log.e("MagpieFloat", "Unable to attach floating controls", error)
            Toast.makeText(this, "悬浮窗未开启，请检查悬浮窗权限并从 App 内重试", Toast.LENGTH_LONG).show()
            GatewayService.prefs(this).edit().putBoolean(ENABLED,false).commit()
            stopSelf()
            return false
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, id: Int): Int {
        if (intent?.action == HIDE) {
            GatewayService.prefs(this).edit().putBoolean(ENABLED,false).commit()
            FloatRecoveryReceiver.cancel(this)
            stopSelf(); return START_NOT_STICKY
        }
        if(!GatewayService.prefs(this).getBoolean(ENABLED,false) || !Settings.canDrawOverlays(this)) {
            GatewayService.prefs(this).edit().putBoolean(ENABLED,false).commit()
            FloatRecoveryReceiver.cancel(this)
            stopSelf(); return START_NOT_STICKY
        }
        if(!attached && !attachControls())return START_NOT_STICKY
        // 系统回收后的 null Intent 可恢复可见工具；主动关闭不会被重新拉起。
        return START_STICKY
    }
    override fun onTaskRemoved(rootIntent: Intent?) {
        // 最近任务卡片与悬浮前台服务独立；不停止、不复制网关进程。
        GatewayService.prefs(this).edit().putLong("float_last_task_removed",System.currentTimeMillis()).commit()
        FloatRecoveryReceiver.schedule(this)
        super.onTaskRemoved(rootIntent)
    }
    private fun dp(v: Int) = FloatChrome.dp(this, v)
    private fun ballPx() = dp(ballDp)
    private fun bounds(): android.graphics.Rect {
        if(Build.VERSION.SDK_INT<30) {
            val metrics=resources.displayMetrics
            return android.graphics.Rect(0,dp(28),metrics.widthPixels,(metrics.heightPixels-dp(32)).coerceAtLeast(dp(76)))
        }
        val m = wm.currentWindowMetrics
        val inset = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        return android.graphics.Rect(inset.left, inset.top, m.bounds.width() - inset.right, m.bounds.height() - inset.bottom)
    }
    private fun params(width: Int, height: Int) = WindowManager.LayoutParams(width, height,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
        PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            // 位置使用屏幕物理坐标，自己扣除刘海和导航栏，再加窗口无布局插入偏移。
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER
            flags = flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
    private fun addBall() {
        val b = bounds()
        position = params(ballPx(), ballPx())
        val prefs = GatewayService.prefs(this)
        position.x = if (prefs.getBoolean("float_right", true)) b.right - ballPx() else b.left
        val fraction = prefs.getFloat("float_y", .35f).coerceIn(0f, 1f)
        position.y = b.top + ((b.height() - ballPx()).coerceAtLeast(0) * fraction).toInt()
        ball = FrameLayout(this)
        ball.contentDescription = "Magpie 悬浮小球：单击展开或收起，双击切换主页与后台，拖动贴边"
        ball.background = FloatChrome.ball(this, "加载中", ballDp)
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_bird); icon.setColorFilter(FloatChrome.CYAN)
        val iconSize = (ballPx() * 9 / 16).coerceAtLeast(1)
        ball.addView(icon, FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER))
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: android.view.MotionEvent) = true
            override fun onSingleTapConfirmed(e: android.view.MotionEvent): Boolean { if(panel==null)expand() else collapse(); return true }
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                collapse()
                try { FloatNavigation.toggle(this@FloatService) }
                catch (_: RuntimeException) { Toast.makeText(this@FloatService,"请从通知打开 Magpie",Toast.LENGTH_SHORT).show() }
                return true
            }
        })
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var oldX = 0; var oldY = 0; var dragging = false
        ball.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; oldX=position.x; oldY=position.y; dragging=false; gesture.onTouchEvent(e) }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && (abs(e.rawX-downX)>slop || abs(e.rawY-downY)>slop)) {
                        dragging=true; collapse()
                        val cancel=MotionEvent.obtain(e); cancel.action=MotionEvent.ACTION_CANCEL; gesture.onTouchEvent(cancel); cancel.recycle()
                    }
                    if (dragging) {
                        val area=bounds()
                        position.x=(oldX+(e.rawX-downX).toInt()).coerceIn(area.left,(area.right-ballPx()).coerceAtLeast(area.left))
                        position.y=(oldY+(e.rawY-downY).toInt()).coerceIn(area.top,(area.bottom-ballPx()).coerceAtLeast(area.top))
                        updateBall()
                    } else gesture.onTouchEvent(e)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) snap() else gesture.onTouchEvent(e)
                    dragging=false
                }
                else -> gesture.onTouchEvent(e)
            }
            true
        }
        if (Build.VERSION.SDK_INT >= 29) {
            // 排除区始终只覆盖当前小球尺寸，其他区域保留系统返回手势。
            ball.addOnLayoutChangeListener { view,_,_,_,_,_,_,_,_ ->
                view.systemGestureExclusionRects = listOf(android.graphics.Rect(0,0,view.width,view.height))
            }
        }
        wm.addView(ball, position); attached=true
    }
    private fun updateBall() { try { wm.updateViewLayout(ball, position) } catch (_: RuntimeException) { stopSelf() } }
    private fun resizeBall() {
        val next = FloatSize.read(this)
        if (next == ballDp) return
        collapse()
        val area = bounds()
        val previousPx = ballPx()
        val right = position.x + previousPx / 2 > area.centerX()
        // 使用拖动贴边时保存的比例，避免连续调节中逐像素取整造成位置漂移。
        val fraction = GatewayService.prefs(this).getFloat("float_y", .35f).coerceIn(0f, 1f)
        ballDp = next
        val size = ballPx()
        position.width = size; position.height = size
        position.x = if (right) (area.right - size).coerceAtLeast(area.left) else area.left
        position.y = area.top + ((area.height() - size).coerceAtLeast(0) * fraction).toInt()
        val icon = ball.getChildAt(0)
        val iconSize = (size * 9 / 16).coerceAtLeast(1)
        icon.layoutParams = FrameLayout.LayoutParams(iconSize, iconSize, Gravity.CENTER)
        ball.background = FloatChrome.ball(this, lastState.ifEmpty { "加载中" }, ballDp)
        updateBall()
    }
    private fun snap() {
        val b=bounds(); val right=position.x+ballPx()/2>b.centerX()
        position.x=if(right) b.right-ballPx() else b.left
        updateBall()
        GatewayService.prefs(this).edit().putBoolean("float_right",right)
            .putFloat("float_y",((position.y-b.top).toFloat()/(b.height()-ballPx()).coerceAtLeast(1)).coerceIn(0f,1f)).apply()
    }
    private fun expand() {
        if (panel != null) return
        logsMode=false
        val view=LayoutInflater.from(this).inflate(R.layout.float_panel,null)
        view.background=FloatChrome.glass(this)
        view.findViewById<Button>(R.id.float_minimize).setOnClickListener { collapse() }
        view.findViewById<Button>(R.id.float_start).setOnClickListener {
            try { MagpieManager.start(this); refreshSoon() }
            catch (_: RuntimeException) { Toast.makeText(this,"暂时无法启动，请返回 App 后重试",Toast.LENGTH_SHORT).show() }
        }
        view.findViewById<Button>(R.id.float_stop).setOnClickListener { MagpieManager.stop(this); refreshSoon() }
        view.findViewById<Button>(R.id.float_logs).setOnClickListener { showLogs() }
        addPanel(view); refresh()
    }
    private fun addPanel(view: View) {
        val b=bounds()
        val width=min(dp(260),b.width().coerceAtLeast(1))
        val maxHeight=min(dp(260),b.height().coerceAtLeast(1))
        view.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(maxHeight,View.MeasureSpec.AT_MOST))
        val p=params(width,view.measuredHeight.coerceAtMost(maxHeight))
        // 小球边上摆得下就横向展开；窄屏放在小球上下，绝不超出安全区域。
        p.x=(if(position.x+ballPx()+width<=b.right) position.x+ballPx() else position.x-width).coerceIn(b.left,(b.right-width).coerceAtLeast(b.left))
        p.y=position.y.coerceIn(b.top,(b.bottom-p.height).coerceAtLeast(b.top))
        if (p.x<position.x+ballPx() && p.x+width>position.x) {
            p.y=if(position.y+ballPx()+p.height<=b.bottom) position.y+ballPx() else (position.y-p.height).coerceAtLeast(b.top)
        }
        view.setOnTouchListener { _, e ->
            if(e.actionMasked==MotionEvent.ACTION_OUTSIDE) {
                // 小球是独立窗口。点击小球也会让面板收到 OUTSIDE，必须交给
                // 小球的单击/双击判定，否则先收起后会被单击回调再次展开。
                val onBall=e.rawX>=position.x && e.rawX<position.x+ballPx() &&
                    e.rawY>=position.y && e.rawY<position.y+ballPx()
                if(!onBall)collapse()
                true
            } else false
        }
        try { wm.addView(view,p); panel=view; panelParams=p }
        catch (error: RuntimeException) { android.util.Log.e("MagpieFloat","Unable to attach floating panel",error);collapse() }
    }
    private fun showLogs() {
        collapse(); logsMode=true
        val column=LinearLayout(this);column.orientation=LinearLayout.VERTICAL;column.setPadding(dp(14),dp(12),dp(14),dp(10));column.background=FloatChrome.glass(this)
        val label=TextView(this);label.text="Magpie · 运行日志";label.textSize=15f;label.setTextColor(FloatChrome.TEXT);column.addView(label)
        val scroller=ScrollView(this);val text=TextView(this);text.text=MagpieManager.logs(this);text.textSize=11f;text.setTextColor(FloatChrome.TEXT);text.typeface=android.graphics.Typeface.MONOSPACE;scroller.addView(text)
        column.addView(scroller,LinearLayout.LayoutParams(-1,dp(130)))
        val back=Button(this);back.text="返回面板";back.setTextColor(FloatChrome.CYAN);back.setBackgroundColor(android.graphics.Color.TRANSPARENT);back.setOnClickListener { collapse();expand() };column.addView(back,LinearLayout.LayoutParams(-1,dp(48)))
        addPanel(column)
    }
    private fun collapse() {
        panel?.let { try { wm.removeView(it) } catch (_: RuntimeException) {} }
        panel=null; panelParams=null; logsMode=false
    }
    private fun refresh() {
        if (reading || !alive) return
        reading=true
        val readUsage=panel!=null && !logsMode
        worker.execute {
            val snapshot=MagpieManager.snapshot(this,readUsage)
            main.post {
                reading=false
                if (!alive) return@post
                if (lastState!=snapshot.state) { lastState=snapshot.state;ball.background=FloatChrome.ball(this,snapshot.state,ballDp) }
                if(readUsage)lastCount=snapshot.requests
                if(!logsMode) panel?.let { p ->
                    p.findViewById<TextView>(R.id.float_status)?.apply { text=snapshot.state;setTextColor(FloatChrome.ringColor(snapshot.state)) }
                    p.findViewById<TextView>(R.id.float_address)?.text=snapshot.address
                    p.findViewById<TextView>(R.id.float_requests)?.text="今日请求  ${lastCount?.toString() ?: "—"}"
                    p.findViewById<Button>(R.id.float_start)?.isEnabled=!GatewayService.running && !GatewayService.starting
                    p.findViewById<Button>(R.id.float_stop)?.isEnabled=GatewayService.running || GatewayService.starting
                }
            }
        }
    }
    private fun refreshSoon() {
        refresh()
        main.postDelayed({if(alive)refresh()},300)
        main.postDelayed({if(alive)refresh()},900)
    }
    override fun onConfigurationChanged(config: android.content.res.Configuration) {
        super.onConfigurationChanged(config);collapse()
        if(attached) { val b=bounds(); position.y=position.y.coerceIn(b.top,(b.bottom-ballPx()).coerceAtLeast(b.top));snap() }
    }
    override fun onDestroy() {
        alive=false;active=false;main.removeCallbacksAndMessages(null)
        GatewayService.prefs(this).unregisterOnSharedPreferenceChangeListener(sizeChanges)
        if(screenRegistered)unregisterReceiver(screen)
        collapse()
        if(attached) { try { wm.removeView(ball) } catch (_: RuntimeException) {};attached=false }
        worker.shutdownNow();stopForeground(STOP_FOREGROUND_REMOVE)
        FloatRecoveryReceiver.schedule(this)
        // 不触碰 GatewayService，关闭悬浮窗不会影响已有请求。
        super.onDestroy()
    }
}
