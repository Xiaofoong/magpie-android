package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.WindowManager;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import org.json.*;

/** Local file picker -> safe backend preview -> explicit import confirmation. */
public final class AccountImportActivity extends Activity {
  private NativeUi ui;
  private ScrollView screenScroll;
  private final Handler main=new Handler(Looper.getMainLooper());
  private String pending="", message="支持顶层凭证数组、secret 嵌套数组、accounts 列表，以及 auth + account 单账号文件。";
  private JSONArray accounts=new JSONArray();
  private JSONArray exportAccounts=new JSONArray();
  private final Set<String> exportSelected=new HashSet<>();
  private byte[] pendingExport;
  private String exportMessage="将已有 WorkBuddy / CodeBuddy 账号保存为 JSON，支持选择单个或多个账号。文件含登录凭证，请妥善保存。";
  private boolean exportOpen;
  private boolean busy, committed, changed, destroyed;
  private int generation;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
    ui=new NativeUi(this);render();
  }
  private void render() {
    if(destroyed) return;
    final int oldY=screenScroll==null?0:screenScroll.getScrollY();
    LinearLayout body=ui.screen();
    ui.header(body,"账号导入与导出","WorkBuddy · CodeBuddy","账号",()->leave());
    LinearLayout info=ui.card();
    ui.add(info,ui.label(busy?"正在处理…":committed?"导入结果":"从 JSON 文件导入",21,NativeUi.INK,true));ui.gap(info,10);
    ui.add(info,ui.label(message,14,NativeUi.MUTED,false));ui.gap(info,18);
    ui.primary(info,pending.isEmpty()?"选择 JSON 文件":"换一个文件",!busy,"download",()->pick());
    ui.add(body,info);ui.gap(body,22);
    int ready=0, imported=0;
    if(accounts.length()>0) {
      ui.section(body,committed?"处理明细":"账号预览");
      LinearLayout list=ui.card();
      for(int i=0;i<accounts.length();i++) {
        JSONObject a=accounts.optJSONObject(i);if(a==null)continue;
        String status=a.optString("status");if("ready".equals(status))ready++;if("imported".equals(status))imported++;
        if(i>0)ui.divider(list);
        ui.add(list,ui.label(a.optString("name","账号"),16,NativeUi.INK,true));ui.gap(list,6);
        String site=a.optString("site");if(!site.isEmpty()) {ui.add(list,ui.label(site,12,NativeUi.ACCENT,false));ui.gap(list,6);}
        ui.add(list,ui.label(a.optString("detail"),13,"imported".equals(status)?NativeUi.GREEN:NativeUi.MUTED,false));
      }
      ui.add(body,list);ui.gap(body,18);
    }
    if(!committed && !pending.isEmpty()) {
      LinearLayout note=ui.card();
      ui.add(note,ui.label("导入只保存有效的访问令牌。授权到期或失效后，请回供应商页面重新登录。首次导入可能需要下载 WorkBuddy 插件。",13,NativeUi.MUTED,false));
      ui.gap(note,18);final int count=ready;
      ui.primary(note,"确认导入 "+count+" 个账号",!busy && count>0,"check",()->request(true));ui.add(body,note);ui.gap(body,18);
    }
    renderExport(body);
    ui.secondary(body,committed?"完成并返回 Magpie":"返回 Magpie",!busy,()->leave());
    for(android.view.ViewParent parent=body.getParent();parent!=null;parent=parent.getParent())if(parent instanceof ScrollView){screenScroll=(ScrollView)parent;break;}
    final ScrollView current=screenScroll;
    body.post(()->{if(!destroyed && current!=null && screenScroll==current)current.scrollTo(0,oldY);});
  }
  private void renderExport(LinearLayout body) {
    ui.section(body,"导出 WorkBuddy 账号");
    LinearLayout card=ui.card();ui.add(card,ui.label(exportMessage,13,NativeUi.MUTED,false));ui.gap(card,14);
    ui.secondary(card,exportOpen?"刷新可导出账号":"选择要导出的账号",!busy,()->loadExports());
    final List<CheckBox> checks=new ArrayList<>();
    if(exportOpen && exportAccounts.length()>0) {
      ui.gap(card,12);LinearLayout actions=ui.row();
      Button all=ui.button("全选",!busy,()->{for(CheckBox c:checks)if(c.isEnabled())c.setChecked(true);});
      Button clear=ui.button("清空选择",!busy,()->{for(CheckBox c:checks)c.setChecked(false);});
      all.setTextColor(NativeUi.ACCENT);clear.setTextColor(NativeUi.ACCENT);
      all.setBackground(ui.surface(android.graphics.Color.TRANSPARENT,12,NativeUi.LINE));clear.setBackground(ui.surface(android.graphics.Color.TRANSPARENT,12,NativeUi.LINE));
      actions.addView(all,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams clearLp=new LinearLayout.LayoutParams(0,-2,1);clearLp.leftMargin=ui.dp(8);actions.addView(clear,clearLp);ui.add(card,actions);
      int available=0;
      for(int i=0;i<exportAccounts.length();i++) {
        JSONObject row=exportAccounts.optJSONObject(i);if(row==null)continue;
        final String key=row.optString("key");boolean eligible=row.optBoolean("exportable");if(eligible)available++;
        CheckBox choice=new CheckBox(this);choice.setText(row.optString("name")+"\n"+row.optString("site")+(eligible?"":"\n"+row.optString("detail")));
        choice.setTextSize(14);choice.setTextColor(NativeUi.INK);choice.setPadding(0,ui.dp(10),0,ui.dp(10));
        choice.setButtonTintList(android.content.res.ColorStateList.valueOf(NativeUi.ACCENT));
        choice.setChecked(eligible && exportSelected.contains(key));choice.setEnabled(!busy && eligible);choice.setAlpha(eligible?1f:.5f);
        choice.setOnCheckedChangeListener((v,on)->{if(on)exportSelected.add(key);else exportSelected.remove(key);});
        checks.add(choice);ui.add(card,choice);
      }
      ui.gap(card,14);ui.primary(card,"导出所选账号",!busy && available>0,"download",()->exportSelection());
    }
    ui.add(body,card);ui.gap(body,20);
  }
  private String safeError(Exception e,String fallback) {
    try {String safe=new JSONObject(e.getMessage()==null?"":e.getMessage()).optString("error");if(!safe.isEmpty() && safe.length()<150)return safe;}catch(Exception ignored){}
    return fallback;
  }
  private void loadExports() {
    final int ticket=++generation;busy=true;exportMessage="正在读取本机账号列表…";render();
    new Thread(()->{
      try {
        JSONObject response=NativeApi.object(new NativeApi(GatewayService.webKey(this)).get("/mobile/accounts/export-workbuddy"));
        JSONArray rows=response.optJSONArray("accounts");if(rows==null)throw new IOException();
        main.post(()->{
          if(destroyed || ticket!=generation)return;busy=false;exportOpen=true;exportAccounts=rows;
          Set<String> valid=new HashSet<>();for(int i=0;i<rows.length();i++){JSONObject a=rows.optJSONObject(i);if(a!=null && a.optBoolean("exportable"))valid.add(a.optString("key"));}
          exportSelected.retainAll(valid);
          exportMessage=rows.length()==0?"当前没有可列出的 WorkBuddy 账号。请先登录或导入账号，再刷新。":"请选择要导出的账号。JSON 含登录凭证，请保存到自己的位置。";render();
        });
      }catch(Exception e){main.post(()->{if(destroyed || ticket!=generation)return;busy=false;exportMessage=safeError(e,"读取未完成，请确认网关正在运行后重试。");render();});}
    },"magpie-export-list").start();
  }
  private void exportSelection() {
    if(exportSelected.isEmpty()){Toast.makeText(this,"请先选择要导出的账号",Toast.LENGTH_SHORT).show();return;}
    final JSONArray selected=new JSONArray();for(String key:exportSelected)selected.put(key);
    final int ticket=++generation;busy=true;exportMessage="正在准备所选账号的导出文件…";render();
    new Thread(()->{
      try {
        JSONObject response=NativeApi.object(new NativeApi(GatewayService.webKey(this)).post("/mobile/accounts/export-workbuddy",NativeApi.obj("keys",selected)));
        String json=response.optString("data");if(json.isEmpty() || json.length()>1024*1024)throw new IOException();
        final byte[] bytes=json.getBytes(StandardCharsets.UTF_8);
        main.post(()->{
          if(destroyed || ticket!=generation){Arrays.fill(bytes,(byte)0);return;}
          pendingExport=bytes;exportMessage="请选择 JSON 文件的保存位置。";render();
          String name="workbuddy-accounts-"+new java.text.SimpleDateFormat("yyyyMMdd-HHmmss",Locale.ROOT).format(new Date())+".json";
          Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE,name);
          try {startActivityForResult(save,82);}catch(ActivityNotFoundException e){Arrays.fill(pendingExport,(byte)0);pendingExport=null;busy=false;exportMessage="设备没有文件保存器";render();}
        });
      }catch(Exception e){main.post(()->{if(destroyed || ticket!=generation)return;busy=false;exportMessage=safeError(e,"导出未完成，请刷新账号列表后重试。");render();});}
    },"magpie-export-file").start();
  }
  private void pick() {
    Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
    try {startActivityForResult(intent,81);}catch(ActivityNotFoundException e){message="设备没有文件选择器";render();}
  }
  @Override protected void onActivityResult(int request,int result,Intent data) {
    super.onActivityResult(request,result,data);
    if(request==82) {
      final byte[] bytes=pendingExport;pendingExport=null;
      if(result!=RESULT_OK || data==null || data.getData()==null || bytes==null) {
        if(bytes!=null)Arrays.fill(bytes,(byte)0);busy=false;exportMessage="未保存导出文件，可重新选择账号导出。";render();return;
      }
      final Uri uri=data.getData();
      new Thread(()->{
        boolean saved=false;
        try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){if(out==null)throw new IOException();out.write(bytes);saved=true;}catch(Exception ignored){saved=false;}
        finally {Arrays.fill(bytes,(byte)0);}
        final boolean ok=saved;
        main.post(()->{if(destroyed)return;busy=false;exportMessage=ok?"JSON 已保存，可以再次导入。已有账号保持登录。":"保存失败，请重新选择保存位置。";render();});
      },"magpie-export-save").start();return;
    }
    if(request!=81 || result!=RESULT_OK || data==null || data.getData()==null)return;
    final Uri uri=data.getData();final int ticket=++generation;
    busy=true;pending="";accounts=new JSONArray();committed=false;message="正在读取文件并生成预览，不会导入账号。";render();
    new Thread(()->{
      String content;
      try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()) {
        if(in==null)throw new IOException();byte[] buffer=new byte[8192];int n;
        while((n=in.read(buffer))!=-1){if(out.size()+n>1024*1024)throw new IOException();out.write(buffer,0,n);}
        content=new String(out.toByteArray(),StandardCharsets.UTF_8);
      }catch(Exception e){main.post(()->{if(destroyed || ticket!=generation)return;busy=false;message="无法读取文件，请选择不超过 1 MB 的 JSON 导出文件。";render();});return;}
      final String file=content;
      main.post(()->{if(destroyed || ticket!=generation)return;pending=file;request(false);});
    },"magpie-import-file").start();
  }
  private void request(boolean commit) {
    final String content=pending;final int ticket=++generation;
    busy=true;message=commit?"正在导入，请稍候。已有账号会保留。":"正在识别格式与检查重复账号…";render();
    new Thread(()->{
      try {
        NativeApi api=new NativeApi(GatewayService.webKey(this));
        JSONObject response=NativeApi.object(api.post("/mobile/accounts/import-workbuddy",NativeApi.obj("data",content,"commit",commit)));
        JSONArray rows=response.optJSONArray("accounts");if(rows==null)throw new IOException();
        main.post(()->{
          if(destroyed || ticket!=generation)return;
          busy=false;accounts=rows;committed=commit;
          int added=0,skip=0,invalid=0;
          for(int i=0;i<rows.length();i++){String s=rows.optJSONObject(i).optString("status");if("imported".equals(s))added++;else if("duplicate".equals(s))skip++;else if(!"ready".equals(s))invalid++;}
          changed|=added>0;
          if(added>0){exportAccounts=new JSONArray();exportSelected.clear();exportOpen=false;exportMessage="账号已更新，请重新选择要导出的账号。";}
          message=commit?"已导入 "+added+" 个，跳过重复 "+skip+" 个，未导入 "+invalid+" 个。返回后刷新供应商查看模型和登录状态。":"已识别 "+rows.length()+" 个账号。请核对地区和结果后确认导入。";
          if(commit)pending="";
          render();
        });
      }catch(Exception e){main.post(()->{
        if(destroyed || ticket!=generation)return;busy=false;
        message="处理未完成，请确认网关正在运行。可重新选择文件重试；已导入的账号会自动跳过。";
        // Only display explicitly safe, structured messages from our local API.
        try {String safe=new JSONObject(e.getMessage()==null?"":e.getMessage()).optString("error");if(!safe.isEmpty() && safe.length()<150)message=safe;}catch(Exception ignored){}
        render();
      });}
    },"magpie-import-accounts").start();
  }
  private void leave(){if(busy)return;if(changed)setResult(RESULT_OK);pending="";finish();}
  @Override public void onBackPressed(){leave();}
  @Override protected void onDestroy(){destroyed=true;generation++;pending="";accounts=new JSONArray();exportAccounts=new JSONArray();exportSelected.clear();if(pendingExport!=null)Arrays.fill(pendingExport,(byte)0);pendingExport=null;main.removeCallbacksAndMessages(null);super.onDestroy();}
}
