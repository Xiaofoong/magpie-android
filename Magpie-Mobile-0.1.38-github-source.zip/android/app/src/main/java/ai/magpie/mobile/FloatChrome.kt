package ai.magpie.mobile

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable

/** 静态二维渐变：无模糊、粒子、3D、逐帧动画或离屏位图。 */
internal object FloatChrome {
    const val CYAN = 0xff8ceaf0.toInt()
    const val TEXT = 0xffe9f6f7.toInt()
    fun dp(c: Context, value: Int) = (c.resources.displayMetrics.density * value + .5f).toInt()

    fun ringColor(state: String): Int = when (state) {
        "运行中" -> 0xff66dfa0.toInt()
        "加载中" -> 0xfff0b368.toInt()
        else -> 0xffed7b81.toInt()
    }

    fun ball(c: Context, state: String, diameterDp: Int): Drawable {
        // 金属边、状态环与内边距随用户选择缩放，最小保留一个物理像素。
        val scale = diameterDp.coerceIn(FloatSize.MIN_DP, FloatSize.MAX_DP) / 48f
        fun scaled(value: Float) = (c.resources.displayMetrics.density * value * scale + .5f).toInt().coerceAtLeast(1)
        val metal = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xffeef7fa.toInt(), 0xff7e909a.toInt(), 0xff121b22.toInt(), 0xffc8d7dd.toInt(), 0xff50636b.toInt()))
        metal.shape = GradientDrawable.OVAL
        metal.setStroke(scaled(1f), 0xff9dbdc6.toInt())
        val inner = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xff172f37.toInt(), 0xff07131b.toInt()))
        inner.shape = GradientDrawable.OVAL
        inner.setStroke(scaled(2f), ringColor(state))
        val layers = LayerDrawable(arrayOf(metal, inner))
        val inset = scaled(4f)
        layers.setLayerInset(1, inset, inset, inset, inset)
        return layers
    }

    fun glass(c: Context): Drawable {
        val border = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xc0a5f8ff.toInt(), 0x55407591, 0xaa77bbc9.toInt()))
        border.cornerRadius = dp(c, 22).toFloat()
        val fill = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xeb263f4b.toInt(), 0xe312202b.toInt()))
        fill.cornerRadius = dp(c, 21).toFloat()
        return LayerDrawable(arrayOf(border, fill)).also {
            val inset = dp(c, 1)
            it.setLayerInset(1, inset, inset, inset, inset)
        }
    }
}
