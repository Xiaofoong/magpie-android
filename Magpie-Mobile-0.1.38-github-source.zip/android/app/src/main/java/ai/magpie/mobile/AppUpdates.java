package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import java.io.*;
import java.lang.ref.WeakReference;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;

/** Public release metadata discovers updates; the installed certificate authenticates APKs. */
final class AppUpdates {
  static final long INTERVAL = UpdatePolicy.CHECK_INTERVAL;
  private static final ExecutorService io = Executors.newSingleThreadExecutor();
  private static final Handler main = new Handler(Looper.getMainLooper());
  private static final AtomicBoolean busy = new AtomicBoolean();
  private static WeakReference<UpdateActivity> screen = new WeakReference<>(null);
  static volatile Info available;
  static volatile String message = "尚未检查";
  static volatile String officialVersion = "";
  static volatile int progress = -1;

  static final class Info {
    final JSONObject json;
    final String repo, versionName, upstream, apkUrl, sha256, notes;
    final long versionCode, size;
    Info(JSONObject j, String repository) throws Exception {
      if (j.optInt("schema") != 1 || !"ai.magpie.mobile".equals(j.optString("packageName"))) throw new IOException("不是此 App 的更新描述");
      repo = UpdatePolicy.repository(repository);
      versionCode = j.getLong("versionCode");
      if (versionCode < 1 || versionCode > 2100000000L) throw new IOException("更新版本号无效");
      versionName = j.getString("versionName"); upstream = j.optString("upstreamVersion", "未知");
      apkUrl = j.getString("apkUrl"); UpdatePolicy.releaseAsset(apkUrl, repo);
      sha256 = j.getString("sha256").toLowerCase(Locale.ROOT); UpdatePolicy.digest(sha256);
      size = j.getLong("size"); UpdatePolicy.size(size);
      String text = j.optString("notes"); notes = text.substring(0, Math.min(12000, text.length()));
      json = new JSONObject(j.toString());
    }
  }

  static JSONObject build(Context c) {
    try (InputStream in = c.getAssets().open("mobile-release.json")) {
      return new JSONObject(new String(read(in, 65536), StandardCharsets.UTF_8));
    } catch (Exception e) { return new JSONObject(); }
  }
  static String repository(Context c) { return GatewayService.prefs(c).getString("update_repository", build(c).optString("updateRepository")); }
  static boolean working() { return busy.get(); }
  static long installed(Context c) {
    try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).getLongVersionCode(); }
    catch (PackageManager.NameNotFoundException e) { return 0; }
  }
  static boolean newer(Context c) { return available != null && available.repo.equals(repository(c)) && available.versionCode > installed(c); }
  static void attach(UpdateActivity a) {
    screen = new WeakReference<>(a);
    if (available == null) try {
      String repo = repository(a);
      String saved = GatewayService.prefs(a).getString("update_manifest", "");
      if (!repo.isEmpty() && !saved.isEmpty()) available = new Info(new JSONObject(saved), repo);
    } catch (Exception ignored) {}
  }
  static void detach(UpdateActivity a) { if (screen.get() == a) screen.clear(); }
  private static void changed() { main.post(() -> { UpdateActivity a = screen.get(); if (a != null && !a.isDestroyed()) a.render(); }); }
  private static void say(String text) { message = text; changed(); }

  static void setRepository(Context c, String value) {
    if (working()) throw new IllegalStateException("请等待当前检查或下载完成");
    String repo = value.trim().isEmpty() ? "" : UpdatePolicy.repository(value);
    GatewayService.prefs(c).edit().putString("update_repository", repo).remove("update_manifest").remove("update_last_check").apply();
    available = null; say(repo.isEmpty() ? "未配置更新发布仓库" : "更新仓库已保存，请检查更新");
  }

  static void automatic(Context context) {
    Context c = context.getApplicationContext();
    if (!GatewayService.prefs(c).getBoolean("update_auto_check", true) || repository(c).isEmpty()) return;
    long last = GatewayService.prefs(c).getLong("update_last_check", 0);
    if (UpdatePolicy.checkDue(System.currentTimeMillis(), last)) check(c, false);
  }

  static void check(Context context, boolean manual) {
    Context c = context.getApplicationContext();
    String repo = repository(c);
    if (repo.isEmpty()) { if (manual) say("尚未配置发布仓库，自动更新还未启用"); return; }
    if (!busy.compareAndSet(false, true)) return;
    GatewayService.prefs(c).edit().putLong("update_last_check", System.currentTimeMillis()).apply();
    progress = -1; say("正在检查安卓版更新…");
    io.execute(() -> {
      try {
        UpdatePolicy.repository(repo);
        JSONObject release = json("https://api.github.com/repos/" + repo + "/releases/latest", 1024 * 1024);
        JSONArray assets = release.getJSONArray("assets"); String descriptor = "";
        for (int i=0;i<assets.length();i++) if ("android-update.json".equals(assets.getJSONObject(i).optString("name"))) descriptor = assets.getJSONObject(i).getString("browser_download_url");
        if (descriptor.isEmpty()) throw new IOException("该仓库尚未发布可验证的安卓更新");
        UpdatePolicy.releaseAsset(descriptor, repo);
        Info info = new Info(json(descriptor, 65536), repo);
        boolean listed = false;
        for (int i=0;i<assets.length();i++) {
          JSONObject asset = assets.getJSONObject(i);
          if (info.apkUrl.equals(asset.optString("browser_download_url")) && info.size == asset.optLong("size") && asset.optString("name").endsWith(".apk")) listed = true;
        }
        if (!listed) throw new IOException("更新描述与发布中的 APK 不匹配");
        if (!repo.equals(repository(c))) return;
        available = info;
        GatewayService.prefs(c).edit().putString("update_manifest", info.json.toString()).apply();
        String officialError = "";
        try {
          JSONObject upstream = json("https://api.github.com/repos/yetone/magpie-releases/releases/latest", 1024 * 1024);
          if (!upstream.optBoolean("draft") && !upstream.optBoolean("prerelease")) {
            String tag = upstream.optString("tag_name");
            if (tag.matches("v[0-9]{1,9}(?:\\.[0-9]{1,9}){1,3}")) officialVersion = tag.substring(1);
          }
        } catch (Exception ignored) { officialError = "；官方版本暂未核实，可稍后重试"; }
        boolean waitingForBuild = UpdatePolicy.versionNewer(officialVersion, info.upstream);
        String status = newer(c) ? "发现可安装 APK：" + info.versionName : "当前已是发布渠道最新的安卓 APK（核心 " + info.upstream + "）";
        if (waitingForBuild) status += "；官方 " + officialVersion + " 已发布，安卓 APK 尚待构建。" + UpdatePolicy.cloudCheckHint();
        say(status + officialError);
        if (newer(c)) {
          if (!manual && info.versionCode > GatewayService.prefs(c).getLong("update_notified_code", 0)) {
            if (notice(c, "Magpie 有新版可安装", info.versionName + " · 点击查看和下载"))
              GatewayService.prefs(c).edit().putLong("update_notified_code", info.versionCode).apply();
          }
        }
      } catch (Exception e) { say("检查未完成：" + error(e)); }
      finally { busy.set(false); changed(); }
    });
  }

  static File cached(Context c, Info info) { return new File(new File(c.getCacheDir(), "updates"), info.sha256 + ".apk"); }
  static boolean downloaded(Context c) { return available != null && cached(c, available).isFile() && cached(c, available).length() == available.size; }

  static void download(Context context) {
    Context c = context.getApplicationContext(); Info info = available;
    if (info == null || !newer(c) || !busy.compareAndSet(false, true)) return;
    say("正在下载并验证更新…"); progress = 0;
    io.execute(() -> {
      File part = new File(cached(c, info).getParentFile(), info.sha256 + ".part.apk");
      HttpURLConnection connection = null;
      try {
        part.getParentFile().mkdirs();
        connection = connect(info.apkUrl);
        MessageDigest digest = MessageDigest.getInstance("SHA-256"); long total = 0, shown = 0;
        try (InputStream in = connection.getInputStream(); OutputStream out = new FileOutputStream(part)) {
          byte[] buffer = new byte[32768]; int n;
          while ((n = in.read(buffer)) != -1) {
            total += n;
            if (total > info.size || total > UpdatePolicy.MAX_APK) throw new IOException("安装包超过声明大小");
            out.write(buffer,0,n); digest.update(buffer,0,n);
            if (SystemClock.elapsedRealtime() - shown > 300) { shown = SystemClock.elapsedRealtime(); progress = (int)(100 * total / info.size); changed(); }
          }
        }
        if (total != info.size || !UpdatePolicy.sameHash(info.sha256, digest.digest())) throw new IOException("安装包 SHA-256 校验失败");
        verifyPackage(c, part, info);
        Files.move(part.toPath(), cached(c, info).toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        progress = 100; say("文件校验和更新证书检查通过，待系统确认安装");
        notice(c, "Magpie 更新已下载", "点击打开更新页并确认安装");
        // Keep one verified package; private temporary files never receive URI grants.
        File[] files = part.getParentFile().listFiles();
        if (files != null) for (File f : files) if (!f.equals(cached(c,info)) && f.getName().matches("[a-f0-9]{64}(?:\\.part)?\\.apk")) f.delete();
      } catch (Exception e) { part.delete(); progress = -1; say("下载或验证失败：" + error(e)); }
      finally { if (connection != null) connection.disconnect(); busy.set(false); changed(); }
    });
  }

  private static Set<String> signers(PackageInfo pkg) throws Exception {
    if (pkg == null || pkg.signingInfo == null) throw new IOException("无法读取 APK 签名");
    Set<String> result = new HashSet<>();
    for (android.content.pm.Signature signer : pkg.signingInfo.getApkContentsSigners())
      result.add(android.util.Base64.encodeToString(signer.toByteArray(), android.util.Base64.NO_WRAP));
    if (result.isEmpty()) throw new IOException("安装包未签名");
    return result;
  }
  private static void verifyPackage(Context c, File file, Info info) throws Exception {
    PackageManager pm = c.getPackageManager();
    PackageInfo next = pm.getPackageArchiveInfo(file.getAbsolutePath(), PackageManager.GET_SIGNING_CERTIFICATES);
    PackageInfo current = pm.getPackageInfo(c.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
    if (next == null || !c.getPackageName().equals(next.packageName)) throw new IOException("不是 Magpie Mobile 安装包");
    if (next.getLongVersionCode() != info.versionCode || next.getLongVersionCode() <= current.getLongVersionCode()) throw new IOException("安装包版本不匹配或不是升级版本");
    if (!signers(current).equals(signers(next))) throw new IOException("安装包签名不一致，已拒绝安装");
  }

  static void install(UpdateActivity a) {
    Info info = available;
    if (info == null || working() || !downloaded(a)) return;
    if (!a.getPackageManager().canRequestPackageInstalls()) {
      a.waitingForPermission = true;
      try { a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName()))); }
      catch (RuntimeException e) { a.waitingForPermission = false; say("请在系统设置允许此应用安装更新"); }
      return;
    }
    if (!busy.compareAndSet(false,true)) return;
    say("正在重新校验安装包…");
    Context c = a.getApplicationContext();
    io.execute(() -> {
      try {
        File file = cached(c, info); MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(file)) { byte[] b = new byte[32768]; int n; while ((n=in.read(b))!=-1) digest.update(b,0,n); }
        if (file.length() != info.size || !UpdatePolicy.sameHash(info.sha256,digest.digest())) throw new IOException("缓存安装包校验失败，请重新下载");
        verifyPackage(c, file, info);
        main.post(() -> {
          if (a.isDestroyed() || a.isFinishing()) return;
          try {
            Uri uri = new Uri.Builder().scheme("content").authority(UpdateFileProvider.AUTHORITY).appendPath("apk").appendPath(file.getName()).build();
            Intent intent = new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive")
              .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setClipData(ClipData.newRawUri("Magpie update",uri));
            a.startActivity(intent); say("请在安卓安装界面确认更新");
          } catch (RuntimeException e) { say("无法打开系统安装器：" + error(e)); }
        });
      } catch (Exception e) { say("已拒绝安装：" + error(e)); }
      finally { busy.set(false); changed(); }
    });
  }

  static boolean notice(Context c, String title, String text) {
    NotificationManager manager = c.getSystemService(NotificationManager.class);
    manager.createNotificationChannel(new NotificationChannel(GatewayService.CHANNEL,"Magpie 网关",NotificationManager.IMPORTANCE_LOW));
    if (!manager.areNotificationsEnabled()) return false;
    PendingIntent open = PendingIntent.getActivity(c, 10, new Intent(c,UpdateActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    manager.notify(10,new Notification.Builder(c,GatewayService.CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download_done)
      .setContentTitle(title).setContentText(text).setContentIntent(open).setAutoCancel(true).build());
    return true;
  }
  private static String error(Exception e) { return e.getMessage()==null ? e.getClass().getSimpleName() : e.getMessage(); }
  private static JSONObject json(String url, int limit) throws Exception {
    HttpURLConnection connection = connect(url);
    try (InputStream in = connection.getInputStream()) { return new JSONObject(new String(read(in,limit),StandardCharsets.UTF_8)); }
    finally { connection.disconnect(); }
  }
  private static HttpURLConnection connect(String url) throws Exception {
    for (int redirects=0;redirects<6;redirects++) {
      UpdatePolicy.secure(url);
      HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
      c.setInstanceFollowRedirects(false); c.setConnectTimeout(15000); c.setReadTimeout(30000);
      c.setRequestProperty("User-Agent","Magpie-Mobile-Android-Updater"); c.setRequestProperty("Accept","application/vnd.github+json, application/octet-stream;q=0.9");
      int status;
      try { status = c.getResponseCode(); } catch (IOException e) { c.disconnect(); throw e; }
      if (status>=300 && status<400) {
        String location=c.getHeaderField("Location"); c.disconnect();
        if (location==null) throw new IOException("更新下载重定向缺少地址");
        url=new URL(new URL(url),location).toString(); continue;
      }
      if (status != 200) {
        c.disconnect();
        if (status==404) throw new IOException("仓库未公开、尚无发布，或更新尚未上传");
        if (status==403 || status==429) throw new IOException("GitHub 暂时限制请求，请稍后重试");
        throw new IOException("更新服务器返回 " + status);
      }
      return c;
    }
    throw new IOException("更新地址重定向过多");
  }
  private static byte[] read(InputStream in, int max) throws IOException {
    ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[8192]; int n;
    while ((n=in.read(b))!=-1) { if(out.size()+n>max)throw new IOException("更新描述过大");out.write(b,0,n); }
    return out.toByteArray();
  }
}
