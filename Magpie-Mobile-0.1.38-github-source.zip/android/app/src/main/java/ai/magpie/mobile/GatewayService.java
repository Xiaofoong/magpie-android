package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.channels.*;
import java.security.SecureRandom;
import java.util.*;
import org.json.*;

public final class GatewayService extends Service {
  public static final String STOP = "ai.magpie.mobile.STOP";
  public static volatile boolean running, starting;
  public static volatile String message = "网关未启动";
  public static final String START_USER = "ai.magpie.mobile.START_USER";
  private final Handler updateHandler = new Handler(Looper.getMainLooper());
  private final Runnable updateCheck = new Runnable() {
    public void run() { if (!stopping) { AppUpdates.automatic(GatewayService.this); updateHandler.postDelayed(this, AppUpdates.INTERVAL); } }
  };
  private BackendSupervisor supervisor;
  private Thread supervisorThread;
  private volatile boolean stopping;
  private PowerManager.WakeLock wake;
  private android.net.wifi.WifiManager.WifiLock wifi;
  private ConnectivityManager cm;
  private ConnectivityManager.NetworkCallback networkCallback;
  private LanNetwork wifiAddresses;
  private final ArrayDeque<String> logLines = new ArrayDeque<>();
  public static GatewayService instance;
  static final String CHANNEL = "magpie_gateway";

  public static android.content.SharedPreferences prefs(Context c) {
    return c.getSharedPreferences("mobile", MODE_PRIVATE);
  }

  static File home(Context c) {
    return new File(c.getFilesDir(), "home");
  }

  static File config(Context c) {
    return new File(home(c), ".config/magpie");
  }

  public static synchronized String webKey(Context c) {
    String key = prefs(c).getString("web_key", "");
    if (key.isEmpty()) {
      byte[] bytes = new byte[24];
      new SecureRandom().nextBytes(bytes);
      StringBuilder b = new StringBuilder();
      for (byte v : bytes) b.append(String.format(Locale.US, "%02x", v & 255));
      key = b.toString();
      prefs(c).edit().putString("web_key", key).commit();
    }
    return key;
  }

  static String managementURL(Context c) {
    return "http://127.0.0.1:3430/?k=" + webKey(c) + "&view=providers";
  }

  static void reloadFromUser(Context c) {
    GatewayService service=instance;
    if (service==null || service.stopping || service.supervisor==null || !running)
      throw new IllegalStateException("网关未运行");
    service.line("用户从悬浮窗请求重新加载网关配置");
    service.state(false,true,"正在重载配置…");
    service.supervisor.reload();
  }
  static void stopFromUser(Context c) {
    // 明确停止立即撤销恢复意图；悬浮窗仍保留，等待用户再次点击启动。
    prefs(c).edit().putBoolean("wanted",false).commit();
    RecoveryReceiver.cancel(c);
    if (running || starting) c.startService(new Intent(c,GatewayService.class).setAction(STOP));
  }
  static void startFromUser(Context c) {
    if (running || starting) return;
    c.startForegroundService(new Intent(c,GatewayService.class).setAction(START_USER));
  }

  static String apiKey(Context c) {
    try {
      JSONObject settings = new JSONObject(read(new File(config(c), "settings.json")));
      String id = settings.optString("lanKeyId");
      JSONArray keys = new JSONArray(read(new File(config(c), "caller-keys.json")));
      for (int i = 0; i < keys.length(); i++) {
        JSONObject k = keys.getJSONObject(i);
        if ((k.optString("id").equals(id) || k.optBoolean("lan")) && !k.optBoolean("off"))
          return k.optString("secret");
      }
    } catch (Exception ignored) {
    }
    return "";
  }

  static boolean lanEnabled(Context c) {
    if (!prefs(c).getBoolean("lan", true)) return false;
    try {
      return new JSONObject(read(new File(config(c), "settings.json"))).optBoolean("lan", false);
    } catch (Exception ignored) { return false; }
  }

  static String read(File f) throws IOException {
    return new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
  }

  private static String safe(String raw) {
    return raw.replaceAll("(?i)([?&](?:k|key|api_key|apikey|access_token|token)=)[^&\\s]+", "$1[hidden]").replaceAll("sk-[A-Za-z0-9_.~-]+", "sk-[hidden]").replaceAll("(?i)(authorization[:=]\\s*(?:bearer\\s+)?)[^\\s,;]+", "$1[hidden]")
      .replaceAll("(?i)(magpie_web_[0-9]+=)[^;\\s]+", "$1[hidden]");
  }

  private void line(String raw) {
    raw = safe(raw);
    String safe =
        raw.replaceAll("(?i)([?&]k=)[^&\\s]+", "$1[hidden]")
            .replaceAll("sk-[A-Za-z0-9_.~-]+", "sk-[hidden]")
            .replaceAll("\\x1b\\[[0-9;]*[A-Za-z]", "");
    synchronized (logLines) {
      logLines.addLast(safe);
      while (logLines.size() > 100) logLines.removeFirst();
      try {
        File log = new File(getFilesDir(), "gateway.log");
        if (log.length() > 256 * 1024) Files.move(log.toPath(), new File(getFilesDir(), "gateway-previous.log").toPath(), StandardCopyOption.REPLACE_EXISTING);
        try (FileOutputStream out = new FileOutputStream(log, true)) {
          out.write((System.currentTimeMillis() + " " + safe + "\n").getBytes(StandardCharsets.UTF_8));
        }
      } catch (IOException ignored) {}
    }
  }

  static String logs(Context context) {
    try {
      String text = read(new File(context.getFilesDir(), "gateway.log"));
      return text.substring(Math.max(0, text.length() - 24000));
    } catch (IOException e) { return message; }
  }

  @Override
  public void onCreate() {
    super.onCreate();
    instance = this;
    NotificationChannel channel =
        new NotificationChannel(CHANNEL, "Magpie 网关", NotificationManager.IMPORTANCE_LOW);
    getSystemService(NotificationManager.class).createNotificationChannel(channel);
    cm = getSystemService(ConnectivityManager.class);
    networkCallback =
        new ConnectivityManager.NetworkCallback() {
          @Override
          public void onLinkPropertiesChanged(Network n, LinkProperties p) {
            networkChanged();
          }

          @Override
          public void onAvailable(Network n) {
            networkChanged();
          }

          @Override
          public void onLost(Network n) {
            networkChanged();
          }
        };
    try {
      cm.registerDefaultNetworkCallback(networkCallback);
    } catch (Exception ignored) {
    }
    wifiAddresses = new LanNetwork(this, this::writeWifiAddresses);
    writeWifiAddresses();
    wifiAddresses.start();
  }

  // Go may be unable to enumerate interfaces inside an Android app.
  // Publish an atomic snapshot of the addresses the system reports for Wi-Fi.
  private synchronized void writeWifiAddresses() {
    if (stopping) return;
    File snapshot = new File(getFilesDir(), "wifi-addresses.txt");
    File next = new File(getFilesDir(), "wifi-addresses.next");
    try {
      Files.write(next.toPath(), wifiAddresses.hosts(), StandardCharsets.UTF_8);
      Files.move(next.toPath(), snapshot.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    } catch (IOException e) {
      snapshot.delete();
      next.delete();
      line("Wi-Fi 地址更新失败：" + e.getMessage());
    }
  }

  private synchronized void writeDNS() {
    try {
      LinkProperties lp = cm.getLinkProperties(cm.getActiveNetwork());
      StringBuilder text = new StringBuilder();
      if (lp != null)
        for (InetAddress dns : lp.getDnsServers()) text.append(dns.getHostAddress()).append('\n');
      File next = new File(getFilesDir(), "dns.next");
      Files.write(next.toPath(), text.toString().getBytes(StandardCharsets.UTF_8));
      Files.move(
          next.toPath(),
          new File(getFilesDir(), "dns.txt").toPath(),
          StandardCopyOption.REPLACE_EXISTING);
    } catch (Exception e) {
      line("网络 DNS 更新：" + e.getMessage());
    }
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int id) {
    String action = intent == null ? "" : intent.getAction();
    if (STOP.equals(action)) {
      prefs(this).edit().putBoolean("wanted", false).commit();
      RecoveryReceiver.cancel(this);
      stopping = true;
      if (supervisor != null) supervisor.stop();
      stopSelf();
      return START_NOT_STICKY;
    }
    boolean userStart = START_USER.equals(action);
    if (userStart) prefs(this).edit().putBoolean("wanted", true).putLong("last_user_start", System.currentTimeMillis()).commit();
    if (!prefs(this).getBoolean("wanted", false)) {
      stopSelf(); return START_NOT_STICKY;
    }
    startForeground(7, notification(running ? "网关运行中 · 127.0.0.1:3425" : "正在自动连接本地网关…"));
    RecoveryReceiver.cancel(this);
    if (!stopping && supervisorThread != null && supervisorThread.isAlive()) return START_STICKY;
    stopping = false; starting = true;
    acquireLocks();
    supervisor = new BackendSupervisor(new BackendSupervisor.Host() {
      @Override public java.lang.Process start() throws Exception { return startBackend(); }
      @Override public boolean healthy() { return nativeReady() && portOpen(3430) && portOpen(3425); }
      @Override public void starting() { state(false, true, "正在自动连接本地网关…"); }
      @Override public void ready() {
        state(true, false, "网关运行中 · 127.0.0.1:3425");
        prefs(GatewayService.this).edit().putLong("last_healthy", System.currentTimeMillis()).apply();
      }
      @Override public void retry(String reason, long delay) {
        line(reason + "；" + (delay / 1000) + " 秒后自动恢复");
        prefs(GatewayService.this).edit()
          .putInt("recovery_count", prefs(GatewayService.this).getInt("recovery_count", 0) + 1)
          .putLong("last_recovery", System.currentTimeMillis()).putString("last_gateway_error", safe(reason)).apply();
        state(false, true, "正在自动恢复网关（" + (delay / 1000) + " 秒）");
      }
    });
    final BackendSupervisor runner = supervisor;
    supervisorThread = new Thread(() -> supervise(runner), "magpie-supervisor");
    supervisorThread.start();
    updateHandler.removeCallbacks(updateCheck);
    updateHandler.postDelayed(updateCheck, 10000);
    return START_STICKY;
  }

  private void state(boolean ready, boolean connecting, String text) {
    if (instance != this || stopping) return;
    running = ready; starting = connecting; message = text;
    prefs(this).edit().putString("gateway_status", text).apply();
    getSystemService(NotificationManager.class).notify(7, notification(text));
  }

  private void acquireLocks() {
    try {
      if (wake == null) {
        wake = getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "magpie:gateway");
        wake.setReferenceCounted(false);
      }
      if (!wake.isHeld()) wake.acquire();
    } catch (Exception e) { line("CPU 后台唤醒：" + e.getMessage()); }
    networkChanged();
  }

  private synchronized void networkChanged() {
    writeDNS();
    // Android 14 maps this old lock to a screen-on/foreground low-latency lock.
    // Do not claim it can keep modern phones' Wi-Fi alive while locked.
    if (Build.VERSION.SDK_INT >= 34 || stopping || wake == null) return;
    try {
      boolean connected = false;
      for (Network network : cm.getAllNetworks()) {
        NetworkCapabilities caps = cm.getNetworkCapabilities(network);
        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) connected = true;
      }
      if (connected && wifi == null) {
        android.net.wifi.WifiManager wm = (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        wifi = wm.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF, "magpie:wifi");
        wifi.setReferenceCounted(false);
      }
      if (wifi != null) {
        if (connected && !wifi.isHeld()) wifi.acquire();
        else if (!connected && wifi.isHeld()) wifi.release();
      }
    } catch (Exception e) { line("Wi-Fi 后台保护：" + e.getMessage()); }
  }

  private void supervise(BackendSupervisor runner) {
    try (RandomAccessFile file = new RandomAccessFile(new File(getFilesDir(), "supervisor.lock"), "rw");
        FileChannel channel = file.getChannel()) {
      FileLock lock = null;
      while (!stopping && !runner.isStopped() && lock == null) {
        try { lock = channel.tryLock(); } catch (OverlappingFileLockException ignored) {}
        if (lock == null) Thread.sleep(200);
      }
      if (lock == null) return;
      try { if (!stopping && !runner.isStopped()) runner.run(); }
      finally { lock.release(); }
    } catch (Exception e) {
      if (!stopping) { line("网关监护异常：" + e.getMessage()); stopSelf(); }
    }
  }

  private Notification notification(String text) {
    PendingIntent open =
        PendingIntent.getActivity(
            this,
            0,
            new Intent(this, MainActivity.class),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    PendingIntent stop =
        PendingIntent.getService(
            this,
            1,
            new Intent(this, GatewayService.class).setAction(STOP),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    PendingIntent protect = PendingIntent.getActivity(this, 2,
      new Intent(this, BackgroundProtectionActivity.class), PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    Notification.Builder builder = new Notification.Builder(this, CHANNEL)
        .setContentTitle("Magpie Mobile")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.stat_notify_sync)
        .setContentIntent(open)
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setCategory(Notification.CATEGORY_SERVICE)
        .setShowWhen(false)
        .addAction(new Notification.Action.Builder(null, "后台保护", protect).build())
        .addAction(new Notification.Action.Builder(null, "停止网关", stop).build());
    if (Build.VERSION.SDK_INT >= 31) builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
    return builder.build();
  }

  private java.lang.Process startBackend() throws Exception {
      File h = home(this);
      h.mkdirs();
      config(this).mkdirs();
      writeDNS();
      File executable = new File(getApplicationInfo().nativeLibraryDir, "libmagpie.so");
      if (!executable.canExecute()) throw new IOException("此设备无法执行内置 ARM64 网关");
      cleanOrphan(executable);
      File pid = new File(getFilesDir(), "backend.pid");
      ProcessBuilder builder = new ProcessBuilder("/system/bin/sh", "-c",
        "echo $$ > " + quote(pid.getAbsolutePath()) + "; exec " + quote(executable.getAbsolutePath()) + " web --no-open --gateway");
      builder.directory(h).redirectErrorStream(true);
      Map<String, String> env = builder.environment();
      env.put("HOME", h.getAbsolutePath());
      env.put("XDG_CONFIG_HOME", new File(h, ".config").getAbsolutePath());
      env.put("XDG_CACHE_HOME", getCacheDir().getAbsolutePath());
      env.put("XDG_DATA_HOME", new File(h, ".local/share").getAbsolutePath());
      env.put("TMPDIR", getCacheDir().getAbsolutePath());
      env.put("MAGPIE_WEB_KEY", webKey(this));
      env.put("MAGPIE_NATIVE_ADDR", "127.0.0.1:3431");
      env.put("MAGPIE_ANDROID_DNS_FILE", new File(getFilesDir(), "dns.txt").getAbsolutePath());
      env.put("DO_NOT_TRACK", "1");
      env.put("NO_COLOR", "1");
      env.put("SSL_CERT_DIR", "/apex/com.android.conscrypt/cacerts:/system/etc/security/cacerts");
      env.put(
          "MAGPIE_BUN",
          new File(getApplicationInfo().nativeLibraryDir, "libbun.so").getAbsolutePath());
      env.put("BUN_INSTALL", new File(h, ".bun").getAbsolutePath());
      boolean lan = prefs(this).getBoolean("lan", true);
      env.put("MAGPIE_ANDROID_LAN", lan ? "1" : "0");
      env.put("MAGPIE_ADDR", "127.0.0.1:3425");
      env.put("MAGPIE_ANDROID_WIFI_FILE", new File(getFilesDir(), "wifi-addresses.txt").getAbsolutePath());
      // Publish the actual bind port for observers; overlay never guesses or edits it.
      String bind=env.get("MAGPIE_ADDR");
      prefs(this).edit().putString("gateway_base","http://127.0.0.1:"+bind.substring(bind.lastIndexOf(':')+1)).apply();
      if (stopping) throw new InterruptedIOException("网关已停止");
      java.lang.Process process = builder.start();
      new Thread(() -> {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
          String text; while ((text = reader.readLine()) != null) line(text);
        } catch (IOException ignored) {}
      }, "magpie-log").start();
      return process;
  }

  private static String quote(String text) {
    if (text.indexOf(39) >= 0) throw new IllegalArgumentException("Unsupported executable path");
    return "'" + text + "'";
  }

  private boolean ownsBackend(int pid, File executable) {
    if (pid <= 1) return false;
    try {
      String cmd = read(new File("/proc/" + pid + "/cmdline"));
      if (!cmd.split("\\x00", 2)[0].equals(executable.getAbsolutePath())) return false;
      for (String line : read(new File("/proc/" + pid + "/status")).split("\n")) {
        if (line.startsWith("Uid:")) return Integer.parseInt(line.trim().split("\\s+")[1]) == android.os.Process.myUid();
      }
    } catch (Exception ignored) {}
    return false;
  }

  private void cleanOrphan(File executable) throws Exception {
    File file = new File(getFilesDir(), "backend.pid");
    if (!file.exists()) return;
    int pid;
    try { pid = Integer.parseInt(read(file).trim()); } catch (Exception e) { file.delete(); return; }
    if (ownsBackend(pid, executable)) {
      line("清理上次服务留下的网关进程");
      android.os.Process.sendSignal(pid, 15);
      long until = SystemClock.elapsedRealtime() + 2000;
      while (!stopping && ownsBackend(pid, executable) && SystemClock.elapsedRealtime() < until) Thread.sleep(100);
      if (ownsBackend(pid, executable)) android.os.Process.killProcess(pid);
    }
    file.delete();
  }

  private boolean nativeReady() {
    HttpURLConnection connection = null;
    try {
      connection = (HttpURLConnection) new URL("http://127.0.0.1:3431/mobile/health").openConnection();
      connection.setConnectTimeout(1000); connection.setReadTimeout(1500);
      connection.setRequestProperty("Authorization", "Bearer " + webKey(this));
      if (connection.getResponseCode() != 200) return false;
      try (InputStream in = connection.getInputStream()) {
        ByteArrayOutputStream body = new ByteArrayOutputStream();
        byte[] bytes = new byte[1024]; int n;
        while ((n = in.read(bytes)) != -1) {
          if (body.size() + n > 4096) return false;
          body.write(bytes, 0, n);
        }
        return new JSONObject(new String(body.toByteArray(), StandardCharsets.UTF_8)).optBoolean("native");
      }
    } catch (Exception e) { return false; }
    finally { if (connection != null) connection.disconnect(); }
  }

  static boolean portOpen(int port) {
    try (Socket s = new Socket()) {
      s.connect(new InetSocketAddress("127.0.0.1", port), 400);
      return true;
    } catch (IOException e) {
      return false;
    }
  }

  @Override public void onTaskRemoved(Intent rootIntent) {
    // The foreground gateway is independent of the recent-app card.
    prefs(this).edit().putLong("last_task_removed", System.currentTimeMillis()).apply();
    super.onTaskRemoved(rootIntent);
  }

  @Override
  public void onDestroy() {
    stopping = true;
    updateHandler.removeCallbacksAndMessages(null);
    if (supervisor != null) supervisor.stop();
    if (instance == this) {
      running = false; starting = false; message = "网关已停止"; instance = null;
      prefs(this).edit().putString("gateway_status", message).apply();
    }
    if (wake != null && wake.isHeld()) wake.release();
    synchronized (this) { if (wifi != null && wifi.isHeld()) wifi.release(); }
    if (wifiAddresses != null) wifiAddresses.stop();
    try { cm.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) {}
    stopForeground(STOP_FOREGROUND_REMOVE);
    if (prefs(this).getBoolean("wanted", false)) RecoveryReceiver.schedule(this);
    super.onDestroy();
  }

  @Override
  public IBinder onBind(Intent i) {
    return null;
  }
}
