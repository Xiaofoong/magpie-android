(() => {
  if (location.origin !== 'http://127.0.0.1:3430' || window.top !== window || window.__magpieAndroidUpdates) return;
  window.__magpieAndroidUpdates = true;
  const open = () => location.assign('magpie-mobile://updates');
  document.addEventListener('click', event => {
    const target = event.target.closest?.('button,a');
    if (!target || !(target.id === 'update' || target.hasAttribute('data-magpie-apk-update')
        || target.closest('#about > .row.pref:first-child .val'))) return;
    event.preventDefault(); event.stopImmediatePropagation(); open();
  }, true);
  const addButton = (row, label) => {
    const val = row?.querySelector('.val');
    if (!val) return;
    for (const button of val.querySelectorAll('button:not([data-magpie-apk-update])')) button.remove();
    if (!val.querySelector('[data-magpie-apk-update]')) {
      const button = document.createElement('button'); button.className = 'text';
      button.setAttribute('data-magpie-apk-update',''); button.textContent = label; val.append(button);
    }
  };
  const explain = (row, message) => {
    if (!row) return;
    const who = row.querySelector('.who');
    if (!who) return;
    let sub = who.querySelector('.sub');
    if (!sub) { sub = document.createElement('div'); sub.className = 'sub'; who.append(sub); }
    if (sub.textContent !== message) sub.textContent = message;
    if (sub.title) sub.title = '';
  };
  const reconcile = () => {
    const version = document.querySelector('#about > .row.pref:first-child');
    explain(version,'安卓通过 APK 更新，请点“检查 APK 更新”查看官方版本和可安装版本。');
    addButton(version,'检查 APK 更新');
    const auto = document.querySelector('#about .update-auto-row');
    explain(auto,'安卓版每 5 分钟检查更新，下载后由系统确认覆盖安装。');
    addButton(auto,'APK 更新设置');
    for (const row of document.querySelectorAll('#about .update-every-row,#about .update-channel-row,#about .update-download-row,#about .update-restart-row'))
      if (!row.hidden) row.hidden = true;
    const header = document.getElementById('update');
    if (header && header.title !== '检查安卓 APK 更新') header.title = '检查安卓 APK 更新';
  };
  let scheduled = 0, active = true;
  const observer = new MutationObserver(() => {
    if (!active || scheduled) return;
    scheduled = requestAnimationFrame(() => { scheduled = 0; if (active) reconcile(); });
  });
  const observe = () => observer.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
  window.addEventListener('pagehide',() => { active = false; observer.disconnect(); if (scheduled) cancelAnimationFrame(scheduled); scheduled = 0; });
  window.addEventListener('pageshow',() => { active = true; observe(); reconcile(); });
  observe();
  reconcile();
})();
