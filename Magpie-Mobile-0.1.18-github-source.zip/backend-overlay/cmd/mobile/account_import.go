package main

// Account files stay in the phone's private import request. Only safe previews
// and per-row outcomes are returned; errors never include parser input/tokens.
import (
	"context"
	"encoding/json"
	"errors"
	"io/fs"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/yetone/magpie/internal/lastgood"
	"github.com/yetone/magpie/internal/plugin"
	"github.com/yetone/magpie/internal/provider"
	"github.com/yetone/magpie/internal/settings"
)

const wbPackage = "@magpie-community/opencode-workbuddy-auth"

type importSecret struct {
	Access         string `json:"accessToken"`
	Refresh        string `json:"refreshToken"`
	Expires        int64  `json:"expiresAt"`
	RefreshExpires int64  `json:"refreshExpiresAt"`
	Domain         string `json:"domain"`
	UID            string `json:"uid"`
	Name           string `json:"nickname"`
	Enterprise     string `json:"enterpriseId"`
	TokenType      string `json:"tokenType"`
}
type importFileRow struct {
	Provider string       `json:"provider"`
	Region   string       `json:"region"`
	Edition  string       `json:"edition"`
	Label    string       `json:"label"`
	UID      string       `json:"uid"`
	Name     string       `json:"nickname"`
	Secret   importSecret `json:"secret"`
	Auth     importSecret `json:"auth"`
	Flat     importSecret `json:"-"`
	Account  struct {
		UID        string `json:"uid"`
		Name       string `json:"nickname"`
		Enterprise string `json:"enterpriseId"`
	} `json:"account"`
}

// A flat export and a nested export carry the same credential fields. Decode
// explicitly into both shapes without making unrelated provider types valid.
func (row *importFileRow) UnmarshalJSON(b []byte) error {
	type plain importFileRow
	var value plain
	if err := json.Unmarshal(b, &value); err != nil {
		return err
	}
	if err := json.Unmarshal(b, &value.Flat); err != nil {
		return err
	}
	*row = importFileRow(value)
	return nil
}

type importedAccount struct {
	site, uid, name, enterprise string
	auth                        map[string]any
}
type importPreview struct {
	Index  int    `json:"index"`
	Name   string `json:"name"`
	Site   string `json:"site"`
	Status string `json:"status"`
	Detail string `json:"detail"`
}

func firstImport(values ...string) string {
	for _, v := range values {
		if strings.TrimSpace(v) != "" {
			return strings.TrimSpace(v)
		}
	}
	return ""
}
func importMillis(n int64) int64 {
	if n > 0 && n < 100000000000 {
		return n * 1000
	}
	return n
}
func importSite(providerID, region, domain string) (string, error) {
	p := strings.ToLower(strings.TrimSpace(providerID))
	r := strings.ToLower(strings.TrimSpace(region))
	site := ""
	switch p {
	case "codebuddy", "workbuddy", "workbuddy-cn", "codebuddy-cn":
		site = "workbuddy"
	case "workbuddy-ai", "workbuddy-intl", "codebuddy-intl", "codebuddy-ai":
		site = "workbuddy-ai"
	case "":
	default:
		return "", errors.New("不是支持的 WorkBuddy / CodeBuddy 账号格式")
	}
	regional := ""
	switch r {
	case "cn", "china", "domestic":
		regional = "workbuddy"
	case "international", "intl", "global", "ai", "overseas":
		regional = "workbuddy-ai"
	case "":
	default:
		return "", errors.New("无法识别账号地区")
	}
	if p != "codebuddy" && site != "" && regional != "" && site != regional {
		return "", errors.New("账号类型与地区不一致")
	}
	if regional != "" {
		site = regional
	}
	host := strings.ToLower(strings.TrimSpace(domain))
	if strings.Contains(host, "://") {
		u, e := url.Parse(host)
		if e != nil || u.Scheme != "https" || u.User != nil || (u.Path != "" && u.Path != "/") || u.RawQuery != "" || u.Fragment != "" {
			return "", errors.New("账号域名无效")
		}
		host = u.Host
	}
	ds := ""
	switch host {
	case "copilot.tencent.com", "www.codebuddy.cn", "codebuddy.cn":
		ds = "workbuddy"
	case "www.workbuddy.ai", "workbuddy.ai", "www.codebuddy.ai", "codebuddy.ai":
		ds = "workbuddy-ai"
	case "":
	default:
		return "", errors.New("账号域名不在支持范围内")
	}
	// codebuddy is an export's generic label; the official domain is decisive.
	if ds != "" {
		if regional != "" && regional != ds {
			return "", errors.New("账号地区与域名不一致")
		}
		if p != "" && p != "codebuddy" && site != "" && site != ds {
			return "", errors.New("账号类型与域名不一致")
		}
		site = ds
	}
	if site == "" {
		return "", errors.New("缺少可识别的账号地区或域名")
	}
	return site, nil
}
func parseImport(data string) ([]importFileRow, error) {
	if len(data) > 1<<20 {
		return nil, errors.New("文件超过 1 MB")
	}
	data = strings.TrimPrefix(strings.TrimSpace(data), "\ufeff")
	var raw json.RawMessage
	if json.Unmarshal([]byte(data), &raw) != nil {
		return nil, errors.New("JSON 格式错误，请选择原始导出文件")
	}
	var rows []importFileRow
	if len(raw) > 0 && raw[0] == '[' {
		if json.Unmarshal(raw, &rows) != nil {
			return nil, errors.New("账号字段类型不正确")
		}
	} else {
		var envelope map[string]json.RawMessage
		if json.Unmarshal(raw, &envelope) != nil || envelope == nil {
			return nil, errors.New("文件必须是账号对象或账号数组")
		}
		if accounts, ok := envelope["accounts"]; ok {
			if json.Unmarshal(accounts, &rows) != nil {
				return nil, errors.New("accounts 必须是账号数组")
			}
		} else {
			var row importFileRow
			if json.Unmarshal(raw, &row) != nil {
				return nil, errors.New("账号字段类型不正确")
			}
			rows = []importFileRow{row}
		}
	}
	if len(rows) == 0 || len(rows) > 200 {
		return nil, errors.New("请选择含 1 至 200 个账号的文件")
	}
	return rows, nil
}
func normalizeImport(row importFileRow) (importedAccount, error) {
	s := row.Secret
	if s.Access == "" && s.Refresh == "" {
		s = row.Auth
	}
	if s.Access == "" && s.Refresh == "" {
		s = row.Flat
	}
	uid := firstImport(row.UID, s.UID, row.Account.UID)
	for _, v := range []string{row.UID, s.UID, row.Account.UID} {
		if v != "" && strings.TrimSpace(v) != uid {
			return importedAccount{}, errors.New("账号 UID 不一致")
		}
	}
	if uid == "" || len(uid) > 256 || strings.ContainsAny(uid, "\r\n\x00") {
		return importedAccount{}, errors.New("缺少有效的账号 UID")
	}
	if s.Access == "" || s.Refresh == "" || len(s.Access) > 32768 || len(s.Refresh) > 32768 || strings.ContainsAny(s.Access+s.Refresh, "\r\n\x00") {
		return importedAccount{}, errors.New("缺少有效的访问或刷新令牌")
	}
	if row.Region != "" && row.Edition != "" {
		a, e1 := importSite("", row.Region, "")
		b, e2 := importSite("", row.Edition, "")
		if e1 != nil || e2 != nil || a != b {
			return importedAccount{}, errors.New("region 与 edition 地区标记不一致")
		}
	}
	site, err := importSite(row.Provider, firstImport(row.Region, row.Edition), s.Domain)
	if err != nil {
		return importedAccount{}, err
	}
	name := firstImport(row.Name, s.Name, row.Account.Name, row.Label, uid)
	if len(name) > 300 {
		name = uid
	}
	enterprise := firstImport(s.Enterprise, row.Account.Enterprise)
	if len(enterprise) > 256 || strings.ContainsAny(enterprise, "\r\n\x00") {
		return importedAccount{}, errors.New("企业标识无效")
	}
	domain := strings.TrimSpace(s.Domain)
	if strings.Contains(domain, "://") {
		u, _ := url.Parse(domain)
		domain = u.Host
	}
	expires := importMillis(s.Expires)
	if expires < 0 || expires > 32503680000000 {
		return importedAccount{}, errors.New("有效期字段无效")
	}
	// Relative expiresIn carries no export time. Refresh on first use rather
	// than incorrectly extending an old token's lifetime from import time.
	if expires == 0 {
		expires = 1
	}
	accountID := name + " · " + uid
	if enterprise != "" {
		accountID += " · " + enterprise
	}
	auth := map[string]any{"type": "oauth", "access": s.Access, "refresh": s.Refresh, "expires": expires, "uid": uid, "accountId": accountID, "domain": domain}
	auth["nickname"] = name
	if enterprise != "" {
		auth["enterpriseId"] = enterprise
	}
	if n := importMillis(s.RefreshExpires); n > 0 {
		auth["refreshExpiresAt"] = n
	}
	if s.TokenType != "" && len(s.TokenType) < 100 {
		auth["tokenType"] = s.TokenType
	}
	return importedAccount{site, uid, name, enterprise, auth}, nil
}
func existingImports() (map[string]map[string]any, error) {
	b, err := lastgood.Read(plugin.AuthPath(), lastgood.JSON)
	if errors.Is(err, fs.ErrNotExist) {
		return map[string]map[string]any{}, nil
	}
	if err != nil {
		return nil, errors.New("已有账号文件无法读取，已停止导入以保护原账号")
	}
	var auths map[string]map[string]any
	if json.Unmarshal(b, &auths) != nil || auths == nil {
		return nil, errors.New("已有账号文件损坏，已停止导入以保护原账号")
	}
	return auths, nil
}
func importDuplicate(a importedAccount, all map[string]map[string]any) bool {
	for key, v := range all {
		if plugin.ProviderOf(key) != a.site {
			continue
		}
		if v["uid"] == a.uid {
			return true
		}
	}
	// Keep any existing seat for the UID: never overwrite it with exported
	// credentials, even when an export omitted the original enterprise ID.
	return false
}
func previewImports(rows []importFileRow, all map[string]map[string]any) ([]importPreview, []importedAccount) {
	previews := make([]importPreview, len(rows))
	normalized := make([]importedAccount, len(rows))
	seen := map[string]bool{}
	for i, row := range rows {
		p := importPreview{Index: i, Name: "账号 " + strconv.Itoa(i+1), Status: "invalid"}
		a, err := normalizeImport(row)
		if err != nil {
			p.Detail = err.Error()
		} else {
			normalized[i] = a
			p.Name = a.name
			p.Site = map[string]string{"workbuddy": "WorkBuddy（国内）", "workbuddy-ai": "WorkBuddy AI（国际）"}[a.site]
			id := a.site + "|" + a.uid
			if seen[id] || importDuplicate(a, all) {
				p.Status = "duplicate"
				p.Detail = "重复账号，将跳过并保留已有登录"
			} else {
				p.Status = "ready"
				p.Detail = "格式通过，导入后验证登录状态"
				seen[id] = true
			}
		}
		previews[i] = p
	}
	return previews, normalized
}

var importMu sync.Mutex
var adoptImport = provider.Adopt
var listImport = plugin.Providers
var saveImport = plugin.Import
var readImport = existingImports
var discoveryOffImport = settings.AccountDiscoveryOff

func importAccounts(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	fail := func(message string) {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(map[string]string{"error": message})
	}
	var in struct {
		Data   string `json:"data"`
		Commit bool   `json:"commit"`
	}
	if json.NewDecoder(http.MaxBytesReader(w, r.Body, 2<<20)).Decode(&in) != nil {
		fail("无法读取导入请求")
		return
	}
	rows, err := parseImport(in.Data)
	if err != nil {
		fail(err.Error())
		return
	}
	importMu.Lock()
	defer importMu.Unlock()
	all, err := readImport()
	if err != nil {
		fail(err.Error())
		return
	}
	previews, accounts := previewImports(rows, all)
	if in.Commit {
		if discoveryOffImport() {
			fail("请先在 Magpie 隐私设置开启订阅账号功能")
			return
		}
		ctx, cancel := context.WithTimeout(r.Context(), 4*time.Minute)
		defer cancel()
		prepared := map[string]bool{}
		for i, a := range accounts {
			if previews[i].Status != "ready" {
				continue
			}
			if !prepared[a.site] {
				if err := adoptImport(ctx, a.site); err != nil {
					previews[i].Status = "failed"
					previews[i].Detail = "无法准备 WorkBuddy 插件，请检查网络或插件状态后重试"
					continue
				}
				pps, err := listImport(ctx)
				ok := false
				for _, p := range pps {
					if p.ID == a.site && plugin.PackageName(p.Spec) == wbPackage {
						ok = true
					}
				}
				if err != nil || !ok {
					previews[i].Status = "failed"
					previews[i].Detail = "WorkBuddy 官方社区插件尚未就绪"
					continue
				}
				prepared[a.site] = true
			}
			// Recheck after migration and immediately before each write. The plugin
			// host owns atomic persistence and refreshes; no raw credential file edits.
			fresh, err := readImport()
			if err != nil {
				previews[i].Status = "failed"
				previews[i].Detail = "无法读取已有账号，已停止此项导入"
				continue
			}
			if importDuplicate(a, fresh) {
				previews[i].Status = "duplicate"
				previews[i].Detail = "重复账号，已保留已有登录"
				continue
			}
			if _, err := saveImport(ctx, a.site, a.auth); err != nil {
				previews[i].Status = "failed"
				previews[i].Detail = "此账号未能保存，请检查插件运行状态后重试"
				continue
			}
			previews[i].Status = "imported"
			previews[i].Detail = "已导入；首次使用时由插件验证并续期"
		}
	}
	json.NewEncoder(w).Encode(map[string]any{"accounts": previews, "committed": in.Commit})
}
