package main

import (
	"encoding/json"
	"errors"
	"net/http"
	"sort"
	"strconv"
	"strings"

	"github.com/yetone/magpie/internal/plugin"
)

type exportPreview struct {
	Key        string `json:"key"`
	Name       string `json:"name"`
	Site       string `json:"site"`
	Exportable bool   `json:"exportable"`
	Detail     string `json:"detail"`
}

func exportString(v any) string { s, _ := v.(string); return s }
func exportMillis(v any) int64 {
	switch n := v.(type) {
	case float64:
		if n > 0 && n <= 32503680000000 {
			return int64(n)
		}
	case int64:
		return n
	case int:
		return int64(n)
	case json.Number:
		x, _ := n.Int64()
		return x
	case string:
		x, _ := strconv.ParseInt(n, 10, 64)
		return x
	}
	return 0
}
func exportName(a map[string]any) string {
	if name := exportString(a["nickname"]); name != "" {
		return name
	}
	name := exportString(a["accountId"])
	uid := exportString(a["uid"])
	enterprise := exportString(a["enterpriseId"])
	suffix := " · " + uid
	if enterprise != "" {
		suffix += " · " + enterprise
	}
	if uid != "" {
		name = strings.TrimSuffix(name, suffix)
	}
	return firstImport(name, uid, "WorkBuddy 账号")
}
func workbuddyExports(all map[string]map[string]any) []exportPreview {
	rows := []exportPreview{}
	keys := make([]string, 0, len(all))
	for key := range all {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, key := range keys {
		site := plugin.ProviderOf(key)
		if site != "workbuddy" && site != "workbuddy-ai" {
			continue
		}
		a := all[key]
		ok := a["type"] == "oauth" && exportString(a["source"]) == "" && exportString(a["uid"]) != "" && exportString(a["access"]) != "" && exportString(a["refresh"]) != ""
		detail := "导出当前保存在本机的登录凭证"
		if !ok {
			detail = "此项是 API Key 或桌面登录引用，无法导出为账号登录文件"
		}
		rows = append(rows, exportPreview{key, exportName(a), map[string]string{"workbuddy": "WorkBuddy（国内）", "workbuddy-ai": "WorkBuddy AI（国际）"}[site], ok, detail})
	}
	return rows
}

// Selection is a fresh, read-only snapshot; unlike plugin.Take it never signs
// out accounts or rotates tokens. The explicit export response alone has secrets.
func workbuddyExportData(all map[string]map[string]any, keys []string) (string, error) {
	if len(keys) == 0 || len(keys) > 200 {
		return "", errors.New("请选择 1 至 200 个可导出的账号")
	}
	available := map[string]bool{}
	for _, row := range workbuddyExports(all) {
		available[row.Key] = row.Exportable
	}
	selected := map[string]bool{}
	rows := make([]map[string]any, 0, len(keys))
	for _, key := range keys {
		if selected[key] {
			continue
		}
		selected[key] = true
		if !available[key] {
			return "", errors.New("所选账号已变化或不支持导出，请刷新账号列表")
		}
		a := all[key]
		site := plugin.ProviderOf(key)
		edition := "cn"
		if site == "workbuddy-ai" {
			edition = "intl"
		}
		row := map[string]any{"provider": site, "edition": edition, "uid": exportString(a["uid"]), "nickname": exportName(a), "accessToken": exportString(a["access"]), "refreshToken": exportString(a["refresh"]), "expiresAt": exportMillis(a["expires"]), "domain": exportString(a["domain"])}
		if e := exportString(a["enterpriseId"]); e != "" {
			row["enterpriseId"] = e
		}
		if n := exportMillis(a["refreshExpiresAt"]); n > 0 {
			row["refreshExpiresAt"] = n
		}
		if t := exportString(a["tokenType"]); t != "" {
			row["tokenType"] = t
		}
		// Validate the file we offer against our importer before exposing it.
		b, _ := json.Marshal(row)
		var check importFileRow
		if json.Unmarshal(b, &check) != nil {
			return "", errors.New("账号凭证格式不完整，无法导出")
		}
		if _, err := normalizeImport(check); err != nil {
			return "", errors.New("账号凭证格式不完整，无法导出")
		}
		rows = append(rows, row)
	}
	b, err := json.MarshalIndent(rows, "", "  ")
	if err != nil || len(b)+1 > 1<<20 {
		return "", errors.New("导出内容过大，请减少选择的账号后分批导出")
	}
	return string(b) + "\n", nil
}
func exportAccounts(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	fail := func(message string) {
		w.WriteHeader(400)
		json.NewEncoder(w).Encode(map[string]string{"error": message})
	}
	var keys []string
	if r.Method == http.MethodPost {
		var in struct {
			Keys []string `json:"keys"`
		}
		if json.NewDecoder(http.MaxBytesReader(w, r.Body, 65536)).Decode(&in) != nil {
			fail("无法读取导出选择")
			return
		}
		keys = in.Keys
	}
	importMu.Lock()
	defer importMu.Unlock()
	all, err := readImport()
	if err != nil {
		fail(err.Error())
		return
	}
	if r.Method == http.MethodGet {
		json.NewEncoder(w).Encode(map[string]any{"accounts": workbuddyExports(all)})
		return
	}
	data, err := workbuddyExportData(all, keys)
	if err != nil {
		fail(err.Error())
		return
	}
	json.NewEncoder(w).Encode(map[string]any{"data": data, "filename": "workbuddy-accounts.json"})
}
