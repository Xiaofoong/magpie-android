"""Pinned Kotlin compilation for the existing Java/ECJ Android build."""
import hashlib,json,os,pathlib,subprocess,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]

def ensure():
    lock=json.loads((ROOT/'ci/kotlin-lock.json').read_text())
    paths=[]
    for row in lock['files']:
        p=ROOT/'toolchain/kotlin'/row['name'];p.parent.mkdir(parents=True,exist_ok=True)
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
            with urllib.request.urlopen(row['url'],timeout=120) as response:p.write_bytes(response.read())
        if hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('Kotlin tool checksum mismatch: '+row['name'])
        paths.append(p)
    return paths

def compile_android(platform,classes,sources,java_sources,extra=()):
    tools=ensure();runtime=next(p for p in tools if p.name.startswith('kotlin-stdlib-'))
    if sources:
        args=['java','-cp',os.pathsep.join(map(str,tools)),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler',
              '-jvm-target','1.8','-no-stdlib','-no-reflect','-classpath',os.pathsep.join(map(str,[platform,runtime,*extra])),
              '-d',str(classes),*map(str,sources),*map(str,java_sources)]
        subprocess.run(args,check=True)
    return runtime
