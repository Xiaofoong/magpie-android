package ai.magpie.mobile;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.*;

/** Fault injection against real child processes; no Android stubs or user data. */
public final class BackendSupervisorTest {
  static class Host implements BackendSupervisor.Host {
    final AtomicInteger attempts = new AtomicInteger(), ready = new AtomicInteger();
    final List<Process> children = Collections.synchronizedList(new ArrayList<Process>());
    final List<Long> delays = Collections.synchronizedList(new ArrayList<Long>());
    volatile boolean healthy = true;
    volatile int failures;
    @Override public Process start() throws Exception {
      int attempt = attempts.incrementAndGet();
      if (attempt <= failures) throw new IOException("injected launch failure");
      Process process = new ProcessBuilder("/bin/sh", "-c", "exec sleep 60").start();
      children.add(process); return process;
    }
    @Override public boolean healthy() { return healthy; }
    @Override public void starting() {}
    @Override public void ready() { ready.incrementAndGet(); }
    @Override public void retry(String reason, long delay) { delays.add(delay); }
  }
  interface Check { boolean ok(); }
  static void await(Check check) throws Exception {
    long until = System.nanoTime() + 5000000000L;
    while (!check.ok()) { if (System.nanoTime() > until) throw new AssertionError("condition timed out"); Thread.sleep(5); }
  }
  static BackendSupervisor runner(Host host) {
    return new BackendSupervisor(host, new BackendSupervisor.Policy(150, 10, 35, 3, 15, 60, 500));
  }
  static void finish(BackendSupervisor supervisor, Thread thread, Host host) throws Exception {
    supervisor.stop(); thread.join(3000);
    if (thread.isAlive()) throw new AssertionError("stop did not cancel supervisor");
    for (Process child : host.children) if (child.isAlive()) throw new AssertionError("child survived stop");
    int attempts = host.attempts.get(); Thread.sleep(120);
    if (host.attempts.get() != attempts) throw new AssertionError("restart after explicit stop");
  }
  public static void main(String[] args) throws Exception {
    Host host = new Host(); host.failures = 3;
    BackendSupervisor supervisor = runner(host); Thread thread = new Thread(supervisor); thread.start();
    try {
      await(() -> host.ready.get() == 1);
      if (!host.delays.subList(0, 3).equals(Arrays.asList(15L, 30L, 60L))) throw new AssertionError("retry backoff");
      host.children.get(0).destroyForcibly();
      await(() -> host.ready.get() >= 2);
      System.out.println("PASS failed launches back off; a killed backend is recreated");
      int old = host.ready.get(); host.healthy = false;
      await(() -> !host.children.get(host.children.size() - 1).isAlive());
      host.healthy = true; await(() -> host.ready.get() > old);
      System.out.println("PASS consecutive local health failures restart the backend");
      Process beforeReload=host.children.get(host.children.size()-1);
      int readyBeforeReload=host.ready.get();supervisor.reload();
      await(() -> host.ready.get()>readyBeforeReload);
      if(beforeReload.isAlive())throw new AssertionError("reload left old backend alive");
      int live=0;for(Process child:host.children)if(child.isAlive())live++;
      if(live!=1)throw new AssertionError("reload must keep exactly one backend");
      System.out.println("PASS user reload uses the existing supervisor and leaves one live backend");
    } finally { finish(supervisor, thread, host); }
    System.out.println("PASS explicit stop terminates the child and cancels future retries");

    Host sleeping = new Host(); sleeping.failures = 100;
    BackendSupervisor pending = runner(sleeping); Thread pendingThread = new Thread(pending); pendingThread.start();
    await(() -> !sleeping.delays.isEmpty()); finish(pending, pendingThread, sleeping);
    System.out.println("PASS stopping during launch backoff does not resurrect the process");

    Host startup = new Host(); startup.healthy = false;
    BackendSupervisor waiting = runner(startup); Thread waitingThread = new Thread(waiting); waitingThread.start();
    try { await(() -> startup.attempts.get() >= 2); startup.healthy = true; await(() -> startup.ready.get() >= 1); }
    finally { finish(waiting, waitingThread, startup); }
    System.out.println("PASS an unready startup is terminated and retried");
  }
}
