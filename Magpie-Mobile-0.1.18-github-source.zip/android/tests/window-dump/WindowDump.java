package ai.magpie.testdriver;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Instrumentation;
import android.app.UiAutomation;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Xml;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import java.io.File;
import java.io.FileOutputStream;
import org.xmlpull.v1.XmlSerializer;

/** Separate test-only package: inspecting all windows must never restart Magpie. */
public final class WindowDump extends Instrumentation {
    @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }
    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            UiAutomation automation = getUiAutomation();
            AccessibilityServiceInfo info = automation.getServiceInfo();
            info.flags |= AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            automation.setServiceInfo(info);
            automation.waitForIdle(100, 2000);
            File output = new File(getTargetContext().getFilesDir(), "windows.xml");
            try (FileOutputStream stream = new FileOutputStream(output)) {
                XmlSerializer xml = Xml.newSerializer();
                xml.setOutput(stream, "UTF-8"); xml.startDocument("UTF-8", true);
                xml.startTag(null, "hierarchy");
                for (AccessibilityWindowInfo window : automation.getWindows()) {
                    AccessibilityNodeInfo root = window.getRoot();
                    if (root != null) node(xml, root);
                }
                xml.endTag(null, "hierarchy"); xml.endDocument();
            }
            result.putString("dump", output.toString()); finish(-1, result);
        } catch (Exception error) {
            result.putString("error", error.toString()); finish(0, result);
        }
    }
    private static String text(CharSequence value) { return value == null ? "" : value.toString(); }
    private static void node(XmlSerializer xml, AccessibilityNodeInfo node) throws Exception {
        if (!node.isVisibleToUser()) return;
        xml.startTag(null, "node");
        xml.attribute(null, "text", text(node.getText()));
        xml.attribute(null, "content-desc", text(node.getContentDescription()));
        xml.attribute(null, "class", text(node.getClassName()));
        xml.attribute(null, "package", text(node.getPackageName()));
        xml.attribute(null, "checked", String.valueOf(node.isChecked()));
        xml.attribute(null, "enabled", String.valueOf(node.isEnabled()));
        Rect bounds = new Rect(); node.getBoundsInScreen(bounds);
        xml.attribute(null, "bounds", bounds.toShortString());
        for (int index = 0; index < node.getChildCount(); index++) {
            AccessibilityNodeInfo child = node.getChild(index);
            if (child != null) node(xml, child);
        }
        xml.endTag(null, "node");
    }
}
