package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.text.DateFormat;
import java.util.Date;
import static ai.magpie.mobile.NativeUi.*;

/** Native protection controls, with live status and explicit system permission actions. */
public final class BackgroundProtectionActivity extends Activity {
  private NativeUi ui;
  private TextView gatewayTitle,gatewayDetail,gatewayBadge,permissions,batteryState,notificationState,recoveryCount,recoveryTime;
  private TextView lanState,lanAddress;
  private Button copyLan;
  private LanNetwork lanNetwork;
  private String lanUrl="";
  private final Handler timer=new Handler(Looper.getMainLooper());
  private final Runnable refresh=new Runnable(){public void run(){refreshStatus();timer.postDelayed(this,3000);}};
  static boolean exempt(Context c) {
    PowerManager power = c.getSystemService(PowerManager.class);
    return power != null && power.isIgnoringBatteryOptimizations(c.getPackageName());
  }

  static void request(Activity activity) {
    try {
      activity.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + activity.getPackageName())));
    } catch (RuntimeException e) {
      try { activity.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
      catch (RuntimeException ignored) { Toast.makeText(activity, "请在系统电池设置中允许 Magpie 后台运行", Toast.LENGTH_LONG).show(); }
    }
  }

  static void offerOnce(Activity activity) {
    if (activity.isFinishing() || exempt(activity) || GatewayService.prefs(activity).getBoolean("background_asked", false)) return;
    GatewayService.prefs(activity).edit().putBoolean("background_asked", true).apply();
    new AlertDialog.Builder(activity).setTitle("允许锁屏后继续运行")
      .setMessage("Magpie 需要在后台持续接收请求。请允许它不受电池优化限制；持续运行会增加耗电。手机的后台活动和自启动限制也需要在系统设置中允许。")
      .setPositiveButton("允许后台运行", (d, n) -> request(activity))
      .setNeutralButton("查看后台保护", (d, n) -> activity.startActivity(new Intent(activity, BackgroundProtectionActivity.class)))
      .setNegativeButton("稍后", null).show();
  }

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);ui=new NativeUi(this);LinearLayout body=ui.screen();
    ui.header(body,"后台保护","为本机网关保持连接。","运行",()->returnHome());
    LinearLayout hero=ui.card();
    LinearLayout heading=ui.row();heading.setGravity(Gravity.CENTER_VERTICAL);
    TextView emblem=ui.label("",20,ACCENT,true);emblem.setCompoundDrawablesWithIntrinsicBounds(ui.icon("shield",ACCENT,24),null,null,null);
    emblem.setGravity(Gravity.CENTER);emblem.setPadding(ui.dp(13),0,0,0);emblem.setBackground(ui.surface(0xff2c2936,16,0));
    heading.addView(emblem,new LinearLayout.LayoutParams(ui.dp(50),ui.dp(50)));
    gatewayBadge=ui.label("",12,GREEN,true);gatewayBadge.setPadding(ui.dp(12),ui.dp(5),ui.dp(12),ui.dp(5));gatewayBadge.setBackground(ui.surface(0xff2b2933,12,0));
    LinearLayout.LayoutParams chip=new LinearLayout.LayoutParams(-2,-2);chip.leftMargin=ui.dp(12);heading.addView(gatewayBadge,chip);
    ui.add(hero,heading);ui.gap(hero,18);gatewayTitle=ui.label("",23,INK,true);ui.add(hero,gatewayTitle);ui.gap(hero,8);
    gatewayDetail=ui.label("",14,MUTED,false);ui.add(hero,gatewayDetail);ui.gap(hero,16);
    ui.add(hero,ui.label("本机 API",12,MUTED,false));ui.gap(hero,6);
    TextView address=ui.label("http://127.0.0.1:3425/v1",15,ACCENT,true);address.setTypeface(android.graphics.Typeface.MONOSPACE);address.setTextIsSelectable(true);ui.add(hero,address);
    ui.divider(hero);permissions=ui.label("",12,MUTED,false);ui.add(hero,permissions);ui.add(body,hero);ui.gap(body,22);

    ui.section(body,"同一 Wi-Fi 访问");LinearLayout lan=ui.card();
    TextView lanTitle=ui.label("局域网 API",16,INK,true);lanTitle.setCompoundDrawablesWithIntrinsicBounds(ui.icon("wifi",ACCENT,20),null,null,null);lanTitle.setCompoundDrawablePadding(ui.dp(10));ui.add(lan,lanTitle);ui.gap(lan,10);
    lanState=ui.label("正在读取 Wi-Fi 地址…",13,MUTED,false);ui.add(lan,lanState);ui.gap(lan,12);
    lanAddress=ui.label("",15,ACCENT,true);lanAddress.setTypeface(android.graphics.Typeface.MONOSPACE);lanAddress.setTextIsSelectable(true);ui.add(lan,lanAddress);ui.gap(lan,14);
    copyLan=ui.button("复制 API 地址",false,()->copyLanAddress());copyLan.setTextColor(ACCENT);copyLan.setBackground(ui.surface(0,15,LINE));ui.add(lan,copyLan);
    ui.divider(lan);ui.add(lan,ui.label("其他设备连接同一 Wi-Fi 后，填写此 Base URL，并使用网关密钥认证。可在 Magpie 中管理调用密钥。",12,MUTED,false));
    ui.add(body,lan);ui.gap(body,22);
    lanNetwork=new LanNetwork(this,()->runOnUiThread(()->{if(!isDestroyed()&&!isFinishing())refreshLan();}));

    ui.section(body,"系统权限");LinearLayout access=ui.card();
    batteryState=permission(access,"电池优化","减少锁屏后的系统限制","battery",()->{
      if(exempt(this))open(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));else request(this);
    });
    ui.divider(access);notificationState=permission(access,"前台通知","查看运行状态与停止入口","bell",()->open(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName())));
    ui.divider(access);ui.action(access,"后台活动与自启动","前往系统设置，按手机机型开启","build",true,()->open(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))));
    ui.add(body,access);ui.gap(body,22);

    ui.section(body,"悬浮工具");LinearLayout floating=ui.card();
    ui.action(floating,"悬浮小球","48dp 小球 · 状态、请求与快捷操作","window",true,()->startActivity(new Intent(this,FloatSettingsActivity.class)));
    ui.add(body,floating);ui.gap(body,22);
    ui.section(body,"恢复设置");LinearLayout boot=ui.card();LinearLayout row=ui.row();row.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout copy=ui.column();ui.add(copy,ui.label("重启后恢复网关",15,INK,true));ui.gap(copy,5);ui.add(copy,ui.label("恢复关机前正在运行的网关",12,MUTED,false));
    LinearLayout.LayoutParams words=new LinearLayout.LayoutParams(0,-2,1);words.rightMargin=ui.dp(12);row.addView(copy,words);
    Switch reboot=new Switch(this);ui.tint(reboot);reboot.setContentDescription("重启手机后恢复上次运行的网关");reboot.setChecked(GatewayService.prefs(this).getBoolean("restore_on_boot",true));
    reboot.setOnCheckedChangeListener((v,on)->GatewayService.prefs(this).edit().putBoolean("restore_on_boot",on).apply());row.addView(reboot,new LinearLayout.LayoutParams(-2,ui.dp(48)));ui.add(boot,row);
    ui.divider(boot);ui.add(boot,ui.label("手动停止后保持停止。建议在最近任务中锁定 Magpie；系统强行停止、厂商清理或断网仍可能影响在线。",12,MUTED,false));
    ui.add(body,boot);ui.gap(body,22);

    ui.section(body,"运行记录");LinearLayout history=ui.card();ui.add(history,ui.label("自动重试次数",12,MUTED,false));ui.gap(history,6);
    recoveryCount=ui.label("0",27,INK,true);ui.add(history,recoveryCount);ui.divider(history);ui.add(history,ui.label("上次自动重试",12,MUTED,false));ui.gap(history,6);
    recoveryTime=ui.label("暂无",14,INK,false);ui.add(history,recoveryTime);ui.gap(history,12);ui.add(history,ui.label("异常退出或本机服务无响应时自动重试。",12,MUTED,false));
    ui.divider(history);ui.action(history,"恢复记录与运行日志","查看最近的运行情况","clock",true,()->showLogs());ui.add(body,history);ui.gap(body,18);
    LinearLayout updates=ui.card();org.json.JSONObject build=AppUpdates.build(this);
    ui.action(updates,"应用更新","安卓版 "+build.optString("wrapperVersion","未知")+" · 查看新版与安装进度","download",true,()->startActivity(new Intent(this,UpdateActivity.class)));
    ui.add(body,updates);ui.gap(body,20);ui.secondary(body,"返回 Magpie",true,()->returnHome());
    refreshStatus();
  }
  @Override public void onResume(){super.onResume();if(ui!=null){lanNetwork.start();timer.removeCallbacks(refresh);refresh.run();}}
  @Override public void onPause(){timer.removeCallbacks(refresh);if(lanNetwork!=null)lanNetwork.stop();super.onPause();}
  private void refreshStatus(){
    if(ui==null||isDestroyed())return;
    boolean running=GatewayService.running,starting=GatewayService.starting,battery=exempt(this),notifications=getSystemService(NotificationManager.class).areNotificationsEnabled();
    put(gatewayBadge,running?"网关在线":starting?"正在连接":"未运行");gatewayBadge.setTextColor(running?GREEN:AMBER);
    put(gatewayTitle,running?"网关正在运行":starting?"正在连接网关":"网关尚未运行");
    put(gatewayDetail,running?"本机 API 已就绪，可返回 Magpie 使用。":GatewayService.message);
    put(permissions,"电池优化与通知  "+((battery?1:0)+(notifications?1:0))+" / 2 项已允许");
    put(batteryState,battery?"已允许":"待设置");batteryState.setTextColor(battery?GREEN:AMBER);
    put(notificationState,notifications?"已允许":"待设置");notificationState.setTextColor(notifications?GREEN:AMBER);
    put(recoveryCount,String.valueOf(GatewayService.prefs(this).getInt("recovery_count",0)));
    long recovered=GatewayService.prefs(this).getLong("last_recovery",0);
    put(recoveryTime,recovered==0?"暂无自动重试":DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(recovered)));
    refreshLan();
  }
  private void refreshLan(){
    if(lanNetwork==null)return;
    java.util.List<String> urls=lanNetwork.apiUrls();lanUrl=urls.isEmpty()?"":urls.get(0);
    boolean shared=GatewayService.lanEnabled(this),ready=GatewayService.running&&shared&&!lanUrl.isEmpty();
    String state=lanNetwork.unavailable()?"暂时无法读取网络，请重新打开此页":!lanNetwork.connected()?"未连接 Wi-Fi，请先连接无线网络":lanUrl.isEmpty()?"Wi-Fi 已连接，等待分配可用地址":!GatewayService.running?"网关未运行，启动后可访问":!shared?"局域网共享已关闭，请在 Magpie 的网络与共享设置中开启":"同一 Wi-Fi 的设备可使用此地址";
    put(lanState,state);lanState.setTextColor(ready?GREEN:MUTED);
    put(lanAddress,lanUrl.isEmpty()?"连接 Wi-Fi 后显示地址":lanUrl);
    copyLan.setEnabled(ready);copyLan.setAlpha(ready?1f:.45f);
  }
  private void copyLanAddress(){
    refreshLan();if(!copyLan.isEnabled())return;
    getSystemService(android.content.ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("Magpie 局域网 API",lanUrl));
    Toast.makeText(this,"已复制 API 地址",Toast.LENGTH_SHORT).show();
  }
  private static void put(TextView view,String text){if(!text.contentEquals(view.getText()))view.setText(text);}
  private TextView permission(LinearLayout box,String title,String subtitle,String glyph,Runnable action){
    LinearLayout line=ui.row();line.setGravity(Gravity.CENTER_VERTICAL);line.setMinimumHeight(ui.dp(64));line.setPadding(ui.dp(2),ui.dp(4),ui.dp(2),ui.dp(4));line.setBackground(ui.surface(0,12,0));
    TextView icon=ui.label("",18,ACCENT,false);icon.setCompoundDrawablesWithIntrinsicBounds(ui.icon(glyph,ACCENT,20),null,null,null);line.addView(icon,new LinearLayout.LayoutParams(ui.dp(32),ui.dp(28)));
    LinearLayout words=ui.column();ui.add(words,ui.label(title,14,INK,true));ui.gap(words,5);ui.add(words,ui.label(subtitle,12,MUTED,false));line.addView(words,new LinearLayout.LayoutParams(0,-2,1));
    TextView state=ui.label("",12,GREEN,true);state.setPadding(ui.dp(10),ui.dp(5),ui.dp(10),ui.dp(5));state.setBackground(ui.surface(0xff2b2933,10,0));
    LinearLayout.LayoutParams chip=new LinearLayout.LayoutParams(-2,-2);chip.leftMargin=ui.dp(8);line.addView(state,chip);
    TextView arrow=ui.label("",18,MUTED,false);arrow.setCompoundDrawablesWithIntrinsicBounds(ui.icon("chevron",MUTED,18),null,null,null);
    LinearLayout.LayoutParams arrowLp=new LinearLayout.LayoutParams(ui.dp(18),ui.dp(24));arrowLp.leftMargin=ui.dp(4);line.addView(arrow,arrowLp);line.setOnClickListener(v->action.run());ui.add(box,line);return state;
  }
  private void showLogs(){
    String logs=GatewayService.logs(this);if(logs.length()>16000)logs="…\n"+logs.substring(logs.length()-16000);
    TextView text=ui.label(logs,12,INK,false);text.setTypeface(android.graphics.Typeface.MONOSPACE);text.setTextIsSelectable(true);text.setPadding(ui.dp(24),ui.dp(12),ui.dp(24),ui.dp(12));
    ScrollView view=new ScrollView(this);view.addView(text);LinearLayout frame=ui.column();frame.addView(view,new LinearLayout.LayoutParams(-1,ui.dp(280)));
    AlertDialog dialog=new AlertDialog.Builder(this).setTitle("运行日志").setView(frame).setPositiveButton("关闭",null).create();
    dialog.setOnShowListener(d->{dialog.getWindow().setBackgroundDrawable(ui.surface(CARD,24,LINE));dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ACCENT);});dialog.show();
  }
  private void returnHome(){startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP));finish();}
  private void open(Intent intent){try{startActivity(intent);}catch(RuntimeException e){Toast.makeText(this,"请从系统设置打开 Magpie 的应用设置",Toast.LENGTH_LONG).show();}}
}
