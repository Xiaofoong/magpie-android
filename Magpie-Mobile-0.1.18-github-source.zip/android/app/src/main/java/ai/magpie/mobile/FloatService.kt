package ai.magpie.mobile

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

/** 仅负责悬浮 UI。网关依然由原有 GatewayService / BackendSupervisor 运行。 */
class FloatService : Service() {
    companion object {
        @JvmField var active = false
        const val HIDE = "ai.magpie.mobile.FLOAT_HIDE"
        private const val CHANNEL = "magpie_float"
    }
    private lateinit var wm: WindowManager
    private lateinit var ball: FrameLayout
    private lateinit var position: WindowManager.LayoutParams
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var alive = true
    private var attached = false
    private var reading = false
    private var lastState = ""
    private var lastCount: Long? = null
    private var logsMode = false
    private var screenOn = true
    private var screenRegistered = false
    private val screen = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            screenOn = i.action != Intent.ACTION_SCREEN_OFF
            if (!screenOn) collapse()
            main.removeCallbacks(tick)
            if (screenOn) main.post(tick)
        }
    }
    private val tick = object : Runnable {
        override fun run() {
            if (!alive || !attached) return
            if (!Settings.canDrawOverlays(this@FloatService)) { stopSelf(); return }
            refresh()
            if (screenOn) main.postDelayed(this, if (panel == null) 4000 else 6000)
        }
    }

    override fun onBind(intent: Intent?) = null
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        screenOn = getSystemService(PowerManager::class.java).isInteractive
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        try {
            addBall()
            // 只在权限已允许且小球已添加后进入前台；入口由可见 Activity 用户点击触发。
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Magpie 悬浮窗", NotificationManager.IMPORTANCE_LOW))
            val home = PendingIntent.getActivity(this, 40, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val hide = PendingIntent.getService(this, 41, Intent(this, FloatService::class.java).setAction(HIDE), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val note = Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_bird)
                .setContentTitle("Magpie 悬浮小球").setContentText("单击展开 / 收起 · 双击首页")
                .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(home)
                .addAction(Notification.Action.Builder(null, "关闭悬浮窗", hide).build()).build()
            if (Build.VERSION.SDK_INT >= 34) startForeground(17, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(17, note)
            active = true
            registerReceiver(screen, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF) }, if(Build.VERSION.SDK_INT>=33) RECEIVER_NOT_EXPORTED else 0)
            screenRegistered = true
            main.post(tick)
        } catch (error: RuntimeException) {
            android.util.Log.e("MagpieFloat", "Unable to attach floating controls", error)
            Toast.makeText(this, "悬浮窗未开启，请检查悬浮窗权限并从 App 内重试", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, id: Int): Int {
        if (intent?.action == HIDE) stopSelf()
        // 不接收开机广播、不后台循环自启，也不改变网关恢复策略。
        return START_NOT_STICKY
    }
    private fun dp(v: Int) = FloatChrome.dp(this, v)
    private fun bounds(): android.graphics.Rect {
        if(Build.VERSION.SDK_INT<30) {
            val metrics=resources.displayMetrics
            return android.graphics.Rect(0,dp(28),metrics.widthPixels,(metrics.heightPixels-dp(32)).coerceAtLeast(dp(76)))
        }
        val m = wm.currentWindowMetrics
        val inset = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        return android.graphics.Rect(inset.left, inset.top, m.bounds.width() - inset.right, m.bounds.height() - inset.bottom)
    }
    private fun params(width: Int, height: Int) = WindowManager.LayoutParams(width, height,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
        PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            // 位置使用屏幕物理坐标，自己扣除刘海和导航栏，再加窗口无布局插入偏移。
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER
            flags = flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
    private fun addBall() {
        val b = bounds()
        position = params(dp(48), dp(48))
        val prefs = GatewayService.prefs(this)
        position.x = if (prefs.getBoolean("float_right", true)) b.right - dp(48) else b.left
        val fraction = prefs.getFloat("float_y", .35f).coerceIn(0f, 1f)
        position.y = b.top + ((b.height() - dp(48)).coerceAtLeast(0) * fraction).toInt()
        ball = FrameLayout(this)
        ball.contentDescription = "Magpie 悬浮小球：单击展开或收起，双击首页，拖动贴边"
        ball.background = FloatChrome.ball(this, "加载中")
        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_bird); icon.setColorFilter(FloatChrome.CYAN)
        ball.addView(icon, FrameLayout.LayoutParams(dp(27), dp(27), Gravity.CENTER))
        val gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: android.view.MotionEvent) = true
            override fun onSingleTapConfirmed(e: android.view.MotionEvent): Boolean { if(panel==null)expand() else collapse(); return true }
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                collapse()
                try { startActivity(Intent(this@FloatService, MainActivity::class.java).putExtra("from_float",true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)) }
                catch (_: RuntimeException) { Toast.makeText(this@FloatService,"请从通知打开 Magpie",Toast.LENGTH_SHORT).show() }
                return true
            }
        })
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var oldX = 0; var oldY = 0; var dragging = false
        ball.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX=e.rawX; downY=e.rawY; oldX=position.x; oldY=position.y; dragging=false; gesture.onTouchEvent(e) }
                MotionEvent.ACTION_MOVE -> {
                    if (!dragging && (abs(e.rawX-downX)>slop || abs(e.rawY-downY)>slop)) {
                        dragging=true; collapse()
                        val cancel=MotionEvent.obtain(e); cancel.action=MotionEvent.ACTION_CANCEL; gesture.onTouchEvent(cancel); cancel.recycle()
                    }
                    if (dragging) {
                        val area=bounds()
                        position.x=(oldX+(e.rawX-downX).toInt()).coerceIn(area.left,(area.right-dp(48)).coerceAtLeast(area.left))
                        position.y=(oldY+(e.rawY-downY).toInt()).coerceIn(area.top,(area.bottom-dp(48)).coerceAtLeast(area.top))
                        updateBall()
                    } else gesture.onTouchEvent(e)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) snap() else gesture.onTouchEvent(e)
                    dragging=false
                }
                else -> gesture.onTouchEvent(e)
            }
            true
        }
        wm.addView(ball, position); attached=true
    }
    private fun updateBall() { try { wm.updateViewLayout(ball, position) } catch (_: RuntimeException) { stopSelf() } }
    private fun snap() {
        val b=bounds(); val right=position.x+dp(24)>b.centerX()
        position.x=if(right) b.right-dp(48) else b.left
        updateBall()
        GatewayService.prefs(this).edit().putBoolean("float_right",right)
            .putFloat("float_y",((position.y-b.top).toFloat()/(b.height()-dp(48)).coerceAtLeast(1)).coerceIn(0f,1f)).apply()
    }
    private fun expand() {
        if (panel != null) return
        logsMode=false
        val view=LayoutInflater.from(this).inflate(R.layout.float_panel,null)
        view.background=FloatChrome.glass(this)
        view.findViewById<Button>(R.id.float_minimize).setOnClickListener { collapse() }
        view.findViewById<Button>(R.id.float_reload).setOnClickListener {
            try { MagpieManager.reload(this); refresh() } catch (_: RuntimeException) { Toast.makeText(this,"网关已停止，请返回 App 启动",Toast.LENGTH_SHORT).show() }
        }
        view.findViewById<Button>(R.id.float_stop).setOnClickListener { MagpieManager.stop(this); refresh() }
        view.findViewById<Button>(R.id.float_logs).setOnClickListener { showLogs() }
        addPanel(view); refresh()
    }
    private fun addPanel(view: View) {
        val b=bounds()
        val width=min(dp(260),b.width().coerceAtLeast(1))
        val maxHeight=min(dp(260),b.height().coerceAtLeast(1))
        view.measure(View.MeasureSpec.makeMeasureSpec(width,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(maxHeight,View.MeasureSpec.AT_MOST))
        val p=params(width,view.measuredHeight.coerceAtMost(maxHeight))
        // 小球边上摆得下就横向展开；窄屏放在小球上下，绝不超出安全区域。
        p.x=(if(position.x+dp(48)+width<=b.right) position.x+dp(48) else position.x-width).coerceIn(b.left,(b.right-width).coerceAtLeast(b.left))
        p.y=position.y.coerceIn(b.top,(b.bottom-p.height).coerceAtLeast(b.top))
        if (p.x<position.x+dp(48) && p.x+width>position.x) {
            p.y=if(position.y+dp(48)+p.height<=b.bottom) position.y+dp(48) else (position.y-p.height).coerceAtLeast(b.top)
        }
        view.setOnTouchListener { _, e ->
            if(e.actionMasked==MotionEvent.ACTION_OUTSIDE) {
                // 小球是独立窗口。点击小球也会让面板收到 OUTSIDE，必须交给
                // 小球的单击/双击判定，否则先收起后会被单击回调再次展开。
                val onBall=e.rawX>=position.x && e.rawX<position.x+dp(48) &&
                    e.rawY>=position.y && e.rawY<position.y+dp(48)
                if(!onBall)collapse()
                true
            } else false
        }
        try { wm.addView(view,p); panel=view; panelParams=p } catch (_: RuntimeException) { collapse() }
    }
    private fun showLogs() {
        collapse(); logsMode=true
        val column=LinearLayout(this);column.orientation=LinearLayout.VERTICAL;column.setPadding(dp(14),dp(12),dp(14),dp(10));column.background=FloatChrome.glass(this)
        val label=TextView(this);label.text="Magpie · 运行日志";label.textSize=15f;label.setTextColor(FloatChrome.TEXT);column.addView(label)
        val scroller=ScrollView(this);val text=TextView(this);text.text=MagpieManager.logs(this);text.textSize=11f;text.setTextColor(FloatChrome.TEXT);text.typeface=android.graphics.Typeface.MONOSPACE;scroller.addView(text)
        column.addView(scroller,LinearLayout.LayoutParams(-1,dp(130)))
        val back=Button(this);back.text="返回面板";back.setTextColor(FloatChrome.CYAN);back.setBackgroundColor(android.graphics.Color.TRANSPARENT);back.setOnClickListener { collapse();expand() };column.addView(back,LinearLayout.LayoutParams(-1,dp(48)))
        addPanel(column)
    }
    private fun collapse() {
        panel?.let { try { wm.removeView(it) } catch (_: RuntimeException) {} }
        panel=null; panelParams=null; logsMode=false
    }
    private fun refresh() {
        if (reading || !alive) return
        reading=true
        val readUsage=panel!=null && !logsMode
        worker.execute {
            val snapshot=MagpieManager.snapshot(this,readUsage)
            main.post {
                reading=false
                if (!alive) return@post
                if (lastState!=snapshot.state) { lastState=snapshot.state;ball.background=FloatChrome.ball(this,snapshot.state) }
                if(readUsage)lastCount=snapshot.requests
                if(!logsMode) panel?.let { p ->
                    p.findViewById<TextView>(R.id.float_status)?.apply { text=snapshot.state;setTextColor(FloatChrome.ringColor(snapshot.state)) }
                    p.findViewById<TextView>(R.id.float_address)?.text=snapshot.address
                    p.findViewById<TextView>(R.id.float_requests)?.text="今日请求  ${lastCount?.toString() ?: "—"}"
                    p.findViewById<Button>(R.id.float_reload)?.isEnabled=GatewayService.running
                    p.findViewById<Button>(R.id.float_stop)?.isEnabled=GatewayService.running || GatewayService.starting
                }
            }
        }
    }
    override fun onConfigurationChanged(config: android.content.res.Configuration) {
        super.onConfigurationChanged(config);collapse()
        if(attached) { val b=bounds(); position.y=position.y.coerceIn(b.top,(b.bottom-dp(48)).coerceAtLeast(b.top));snap() }
    }
    override fun onDestroy() {
        alive=false;active=false;main.removeCallbacksAndMessages(null)
        if(screenRegistered)unregisterReceiver(screen)
        collapse()
        if(attached) { try { wm.removeView(ball) } catch (_: RuntimeException) {};attached=false }
        worker.shutdownNow();stopForeground(STOP_FOREGROUND_REMOVE)
        // 不触碰 GatewayService，关闭悬浮窗不会影响已有请求。
        super.onDestroy()
    }
}
