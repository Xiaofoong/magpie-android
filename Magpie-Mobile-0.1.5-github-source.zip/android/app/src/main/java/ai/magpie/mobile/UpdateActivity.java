package ai.magpie.mobile;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;

/** Native update screen. The original Magpie Web page remains the app's home. */
public final class UpdateActivity extends Activity {
  private static final int BG=0xff151519, CARD=0xff202026, LINE=0xff32323c,
      INK=0xfff1f0f7, MUTED=0xffa4a2b4, ACCENT=0xffc4b5fd,
      GREEN=0xff9cdbbc, AMBER=0xffedc793, RED=0xffffb4b4;
  private LinearLayout body;
  private ScrollView scroll;
  private boolean detailsOpen, notesOpen;
  boolean waitingForPermission;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    if(state!=null) { detailsOpen=state.getBoolean("update_details"); notesOpen=state.getBoolean("update_notes"); }
    getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
    getWindow().getDecorView().setSystemUiVisibility(0);
    body=column(); body.setPadding(dp(20),dp(12),dp(20),dp(28));
    FrameLayout canvas=new FrameLayout(this); canvas.setBackgroundColor(BG);
    FrameLayout.LayoutParams width=new FrameLayout.LayoutParams(
        Math.min(getResources().getDisplayMetrics().widthPixels,dp(600)),-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
    canvas.addView(body,width);
    scroll=new ScrollView(this); scroll.setBackgroundColor(BG); scroll.setFillViewport(true);
    scroll.setClipToPadding(false); scroll.addView(canvas); setContentView(scroll);
    AppUpdates.attach(this); render(); AppUpdates.check(this,true);
  }
  @Override public void onResume() {
    super.onResume(); AppUpdates.attach(this); render();
    if(waitingForPermission) {
      waitingForPermission=false;
      if(getPackageManager().canRequestPackageInstalls()) AppUpdates.install(this);
    }
  }
  @Override public void onSaveInstanceState(Bundle state) {
    state.putBoolean("update_details",detailsOpen); state.putBoolean("update_notes",notesOpen); super.onSaveInstanceState(state);
  }
  @Override public void onDestroy() { AppUpdates.detach(this); super.onDestroy(); }

  void render() {
    if(body==null || isDestroyed()) return;
    int oldY=scroll.getScrollY(); body.removeAllViews();
    JSONObject build=AppUpdates.build(this);
    String installed=build.optString("upstreamVersion","未知"), repo=AppUpdates.repository(this);
    AppUpdates.Info next=AppUpdates.available;
    boolean working=AppUpdates.working(), newer=AppUpdates.newer(this), downloaded=AppUpdates.downloaded(this);
    boolean waiting=UpdatePolicy.versionNewer(AppUpdates.officialVersion,next==null?installed:next.upstream);
    String message=AppUpdates.message;
    boolean error=message.startsWith("检查未完成") || message.startsWith("下载或验证失败")
        || message.startsWith("已拒绝安装") || message.startsWith("无法打开") || message.startsWith("请在系统设置");

    LinearLayout top=row(); top.setGravity(Gravity.CENTER_VERTICAL);
    TextView back=label("",18,INK,true); back.setCompoundDrawablesWithIntrinsicBounds(icon("back",INK,20),null,null,null);
    back.setGravity(Gravity.CENTER); back.setPadding(dp(14),0,0,0); back.setContentDescription("返回 Magpie");
    back.setBackground(surface(CARD,24,LINE)); back.setOnClickListener(v->returnHome());
    top.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
    TextView brand=label("MAGPIE  /  更新",11,MUTED,true); brand.setLetterSpacing(.12f);
    LinearLayout.LayoutParams brandLp=new LinearLayout.LayoutParams(-2,-2); brandLp.leftMargin=dp(14); top.addView(brand,brandLp);
    body.addView(top); gap(body,24);
    add(body,label("应用更新",30,INK,true));
    TextView subtitle=label("官方核心，随时跟进。",14,MUTED,false); subtitle.setPadding(0,dp(6),0,0); add(body,subtitle); gap(body,22);

    int tone=error?RED:working?ACCENT:newer?GREEN:waiting?AMBER:GREEN;
    String symbol=error?"alert":working?"refresh":newer?"download":waiting?"clock":"check";
    String badge=error?"需要重试":working?"正在处理":newer?(downloaded?"验证通过":"发现新版"):waiting?"等待发布":"版本状态";
    String title=error?"更新暂未完成":working?(AppUpdates.progress>=100?"正在验证安装包":AppUpdates.progress>=0?"正在下载更新":"正在检查更新"):
        newer?(downloaded?"更新已准备好":"有新版本可用"):waiting?"等待安卓构建":next!=null?"当前已是最新":"检查你的版本";
    String summary=error?message:working?message:newer?(downloaded?"安装包已校验，可前往系统界面确认安装。":"新版 APK 已发布，下载后即可覆盖更新。"):
        waiting?"官方 "+AppUpdates.officialVersion+" 已发布，正在等待可安装的安卓 APK。":
        next!=null?"已安装发布渠道的最新 APK。":"点击检查，获取可安装的安卓版本。";
    if(!error && message.contains("官方版本暂未核实")) summary+=" 官方版本暂未核实，可稍后重试。";
    LinearLayout hero=card();
    LinearLayout status=row(); status.setGravity(Gravity.CENTER_VERTICAL);
    TextView emblem=label("",20,tone,true); emblem.setGravity(Gravity.CENTER);
    emblem.setCompoundDrawablesWithIntrinsicBounds(icon(symbol,tone,24),null,null,null);
    emblem.setPadding(dp(13),0,0,0); emblem.setBackground(surface(0xff2c2936,16,Color.TRANSPARENT));
    status.addView(emblem,new LinearLayout.LayoutParams(dp(50),dp(50)));
    TextView state=label(badge,12,tone,true); state.setPadding(dp(12),dp(5),dp(12),dp(5));
    state.setBackground(surface(0xff2b2933,12,Color.TRANSPARENT));
    LinearLayout.LayoutParams chip=new LinearLayout.LayoutParams(-2,-2); chip.leftMargin=dp(12); status.addView(state,chip);
    add(hero,status); gap(hero,18); add(hero,label(title,23,INK,true)); gap(hero,8);
    add(hero,label(summary,14,MUTED,false));
    if(working) {
      gap(hero,18);
      ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
      bar.setProgressTintList(ColorStateList.valueOf(ACCENT)); bar.setProgressBackgroundTintList(ColorStateList.valueOf(LINE));
      bar.setIndeterminateTintList(ColorStateList.valueOf(ACCENT));
      bar.setIndeterminate(AppUpdates.progress<0); bar.setMax(100); bar.setProgress(Math.max(0,AppUpdates.progress));
      hero.addView(bar,new LinearLayout.LayoutParams(-1,dp(6)));
      if(AppUpdates.progress>=0) { gap(hero,8); add(hero,label(AppUpdates.progress+"% · 下载与校验",12,ACCENT,true)); }
    }
    gap(hero,20);
    if(newer && !error) {
      primary(hero,downloaded?"安装更新":"下载更新 · "+String.format(java.util.Locale.ROOT,"%.1f MB",next.size/1048576.0),
          !working,"download",()->{if(downloaded) AppUpdates.install(this); else AppUpdates.download(this);});
      gap(hero,8); secondary(hero,"重新检查",!working,()->AppUpdates.check(this,true));
    } else primary(hero,working?"请稍候…":error?"重新检查":"检查更新",!working,"refresh",()->AppUpdates.check(this,true));
    if(waiting && !working && !newer) {
      gap(hero,12); add(hero,label("云端每 15 分钟检查，调度与构建可能延迟。",12,MUTED,false));
    }
    add(body,hero); gap(body,22);

    section("版本信息");
    LinearLayout versions=card();
    String official=AppUpdates.officialVersion.isEmpty()?"待检查":AppUpdates.officialVersion;
    if(getResources().getConfiguration().fontScale<=1.25f && getResources().getConfiguration().screenWidthDp>=360) {
      LinearLayout compare=row(), current=column(), upstream=column();
      versionLine(current,"当前核心",installed,INK); versionLine(upstream,"官方稳定版",official,ACCENT);
      compare.addView(current,new LinearLayout.LayoutParams(0,-2,1));
      LinearLayout.LayoutParams right=new LinearLayout.LayoutParams(0,-2,1); right.leftMargin=dp(12); compare.addView(upstream,right);
      add(versions,compare);
    } else {
      versionLine(versions,"当前核心",installed,INK); divider(versions);
      versionLine(versions,"官方稳定版",official,ACCENT);
    }
    if(newer) { divider(versions); versionLine(versions,"可安装核心",next.upstream,GREEN); }
    divider(versions);
    add(versions,label("安卓版  "+build.optString("wrapperVersion",build.optString("versionName","未知")),12,MUTED,false));
    add(body,versions); gap(body,22);
    if(newer && !next.notes.isEmpty()) {
      LinearLayout notes=card(); action(notes,"本次更新",notesOpen?"点击收起":"查看新版说明","external",true,()->{notesOpen=!notesOpen;render();});
      if(notesOpen) { gap(notes,12); add(notes,label(next.notes,13,MUTED,false)); } add(body,notes); gap(body,22);
    }

    section("更新设置");
    LinearLayout settings=card();
    LinearLayout autoRow=row(); autoRow.setGravity(Gravity.CENTER_VERTICAL);
    LinearLayout autoCopy=column(); add(autoCopy,label("自动检查更新",15,INK,true)); gap(autoCopy,4);
    add(autoCopy,label("网关运行时，每 15 分钟检查",12,MUTED,false));
    LinearLayout.LayoutParams autoText=new LinearLayout.LayoutParams(0,-2,1); autoText.rightMargin=dp(12); autoRow.addView(autoCopy,autoText);
    Switch auto=new Switch(this); auto.setShowText(false); auto.setContentDescription("自动检查更新，每15分钟");
    auto.setThumbTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{ACCENT,0xffb0adbd}));
    auto.setTrackTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{0xff76669d,0xff484650}));
    auto.setChecked(GatewayService.prefs(this).getBoolean("update_auto_check",true));
    auto.setOnCheckedChangeListener((v,on)->GatewayService.prefs(this).edit().putBoolean("update_auto_check",on).apply());
    autoRow.addView(auto,new LinearLayout.LayoutParams(-2,dp(48))); add(settings,autoRow);
    divider(settings);
    action(settings,"发布仓库",repo.isEmpty()?"尚未配置":repo,"repository",!working,()->editRepository(repo));
    if(!repo.isEmpty()) { divider(settings); action(settings,"APK 构建进度","查看排队、构建与发布状态","build",true,
        ()->open("https://github.com/"+repo+"/actions")); }
    divider(settings); action(settings,"官方更新日志","了解核心版本的新功能与修复","external",true,
        ()->open("https://github.com/yetone/magpie-releases/releases"));
    add(body,settings); gap(body,18);
    LinearLayout help=card();
    action(help,"安装与数据",detailsOpen?"点击收起":"系统确认安装 · 覆盖更新保留数据","shield",true,()->{detailsOpen=!detailsOpen;render();});
    if(detailsOpen) {
      gap(help,12); add(help,label("官方发布后，需要通过安卓构建验证才能成为可安装更新。安装前校验 SHA-256、大小、包名、版本与当前 App 签名。\n\n请在系统安装界面确认更新，不必先卸载。覆盖安装保留应用数据，更新期间网关会短暂中断。",13,MUTED,false));
    }
    add(body,help); gap(body,20);
    secondary(body,"返回 Magpie",true,()->returnHome());
    body.post(()->{if(!isDestroyed()) scroll.scrollTo(0,oldY);});
  }

  private void editRepository(String repo) {
    EditText field=new EditText(this); field.setSingleLine(true); field.setText(repo); field.setHint("用户名/仓库名");
    field.setTextColor(INK); field.setHintTextColor(MUTED); field.setTextSize(15);
    field.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_URI);
    LinearLayout content=column(); content.setPadding(dp(24),dp(8),dp(24),0); add(content,field);
    AlertDialog dialog=new AlertDialog.Builder(this).setTitle("设置发布仓库")
        .setMessage("填写发布 Magpie 安卓 APK 的公开仓库。不要填写密码或令牌。")
        .setView(content).setNegativeButton("取消",null).setPositiveButton("保存",null).create();
    dialog.setOnShowListener(d->{
      dialog.getWindow().setBackgroundDrawable(surface(CARD,24,LINE));
      dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ACCENT);
      dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(MUTED);
      dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
        try { AppUpdates.setRepository(this,field.getText().toString()); dialog.dismiss(); render(); }
        catch(RuntimeException e) { field.setError(e.getMessage()); }
      });
    }); dialog.show();
  }
  private void returnHome() { startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP)); finish(); }
  private void open(String url) { try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url))); }
    catch(ActivityNotFoundException e) { Toast.makeText(this,"请安装浏览器后再打开",Toast.LENGTH_SHORT).show(); } }
  private int dp(float value) { return Math.round(value*getResources().getDisplayMetrics().density); }
  private LinearLayout column() { LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); return box; }
  private LinearLayout row() { LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); return box; }
  private TextView label(String value,int size,int color,boolean bold) {
    TextView view=new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(color);
    view.setTypeface(Typeface.create(bold?"sans-serif-medium":"sans-serif",Typeface.NORMAL));
    view.setIncludeFontPadding(false); view.setLineSpacing(dp(3),1f); return view;
  }
  private void add(LinearLayout box,View view) { box.addView(view,new LinearLayout.LayoutParams(-1,-2)); }
  private void gap(LinearLayout box,int height) { box.addView(new View(this),new LinearLayout.LayoutParams(1,dp(height))); }
  private void section(String title) { TextView view=label(title,12,MUTED,true); view.setPadding(dp(3),0,0,dp(10)); add(body,view); }
  private LinearLayout card() { LinearLayout box=column(); box.setPadding(dp(18),dp(18),dp(18),dp(18)); box.setBackground(surface(CARD,22,LINE)); return box; }
  private void divider(LinearLayout box) {
    View line=new View(this); line.setBackgroundColor(LINE); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(1));
    p.topMargin=dp(14); p.bottomMargin=dp(14); box.addView(line,p);
  }
  private void versionLine(LinearLayout box,String key,String value,int color) {
    LinearLayout line=column(); add(line,label(key,12,MUTED,false)); gap(line,6); add(line,label(value,21,color,true)); add(box,line);
  }
  private void action(LinearLayout box,String title,String subtitle,String glyph,boolean enabled,Runnable run) {
    LinearLayout line=row(); line.setGravity(Gravity.CENTER_VERTICAL); line.setMinimumHeight(dp(56));
    line.setBackground(surface(Color.TRANSPARENT,12,Color.TRANSPARENT)); line.setPadding(dp(2),dp(4),dp(2),dp(4));
    TextView image=label("",18,ACCENT,false); image.setCompoundDrawablesWithIntrinsicBounds(icon(glyph,ACCENT,20),null,null,null);
    line.addView(image,new LinearLayout.LayoutParams(dp(32),dp(28)));
    LinearLayout words=column(); add(words,label(title,14,INK,true)); gap(words,5); add(words,label(subtitle,12,MUTED,false));
    line.addView(words,new LinearLayout.LayoutParams(0,-2,1));
    TextView arrow=label("",18,MUTED,false); arrow.setCompoundDrawablesWithIntrinsicBounds(icon("chevron",MUTED,18),null,null,null);
    LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(dp(20),dp(24)); a.leftMargin=dp(8); line.addView(arrow,a);
    line.setEnabled(enabled); line.setAlpha(enabled?1f:.45f); line.setOnClickListener(v->run.run()); add(box,line);
  }
  private void primary(LinearLayout box,String title,boolean enabled,String glyph,Runnable run) {
    Button button=button(title,enabled,run); button.setTextColor(BG); button.setBackground(surface(ACCENT,15,Color.TRANSPARENT));
    button.setCompoundDrawablesWithIntrinsicBounds(icon(glyph,BG,18),null,null,null); button.setCompoundDrawablePadding(dp(8)); add(box,button);
  }
  private void secondary(LinearLayout box,String title,boolean enabled,Runnable run) {
    Button button=button(title,enabled,run); button.setTextColor(ACCENT); button.setBackground(surface(Color.TRANSPARENT,15,LINE)); add(box,button);
  }
  private Button button(String title,boolean enabled,Runnable run) {
    Button button=new Button(this); button.setText(title); button.setTextSize(15); button.setAllCaps(false);
    button.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL)); button.setMinHeight(dp(52)); button.setMinimumHeight(dp(52));
    button.setMinWidth(0); button.setMinimumWidth(0); button.setPadding(dp(20),dp(14),dp(20),dp(14)); button.setStateListAnimator(null);
    button.setEnabled(enabled); button.setAlpha(enabled?1f:.45f); button.setOnClickListener(v->run.run()); return button;
  }
  private Drawable surface(int color,int radius,int stroke) {
    GradientDrawable shape=new GradientDrawable(); shape.setColor(color); shape.setCornerRadius(dp(radius));
    if(stroke!=Color.TRANSPARENT) shape.setStroke(dp(1),stroke);
    return new RippleDrawable(ColorStateList.valueOf(0x25c4b5fd),shape,null);
  }
  private Drawable icon(String name,int color,int size) { return new UpdateIcon(name,color,dp(size)); }

  /** Native vector line icons; no image font or Web dependency. */
  private static final class UpdateIcon extends Drawable {
    private final String name; private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); private final int size;
    UpdateIcon(String value,int color,int pixels) { name=value; size=pixels; paint.setColor(color); paint.setStrokeWidth(1.8f); paint.setStyle(Paint.Style.STROKE); paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND); }
    private void path(Canvas c,float... points) { Path p=new Path(); p.moveTo(points[0],points[1]); for(int i=2;i<points.length;i+=2)p.lineTo(points[i],points[i+1]); c.drawPath(p,paint); }
    @Override public void draw(Canvas canvas) {
      int save=canvas.save(); Rect bounds=getBounds(); canvas.translate(bounds.left,bounds.top); canvas.scale(bounds.width()/24f,bounds.height()/24f);
      switch(name) {
        case "back": path(canvas,14,6,8,12,14,18); break;
        case "chevron": path(canvas,9,6,15,12,9,18); break;
        case "download": path(canvas,12,3,12,15); path(canvas,7,10,12,15,17,10); path(canvas,4,16,4,20,20,20,20,16); break;
        case "refresh": canvas.drawArc(4,4,20,20,35,285,false,paint); path(canvas,20,4,20,10,14,10); break;
        case "clock": canvas.drawCircle(12,12,9,paint); path(canvas,12,7,12,12,15,14); break;
        case "check": canvas.drawCircle(12,12,9,paint); path(canvas,7,12,10.5f,15.5f,17,9); break;
        case "alert": canvas.drawCircle(12,12,9,paint); path(canvas,12,7,12,12); canvas.drawPoint(12,16,paint); break;
        case "repository": canvas.drawRoundRect(4,3,20,21,3,3,paint); path(canvas,8,3,8,21); path(canvas,12,8,16,8); path(canvas,12,12,16,12); break;
        case "build": canvas.drawRoundRect(3,4,21,17,3,3,paint); path(canvas,8,21,16,21); path(canvas,12,17,12,21); path(canvas,7,9,9,11,7,13); path(canvas,12,13,16,13); break;
        case "shield": path(canvas,12,2,20,5,20,12,18,17,12,22,6,17,4,12,4,5,12,2); path(canvas,8,11,11,14,16,9); break;
        default: path(canvas,14,3,21,3,21,10); path(canvas,21,3,11,13); path(canvas,10,4,4,4,4,20,20,20,20,14);
      }
      canvas.restoreToCount(save);
    }
    @Override public int getIntrinsicWidth() { return size; }
    @Override public int getIntrinsicHeight() { return size; }
    @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
  }
}
