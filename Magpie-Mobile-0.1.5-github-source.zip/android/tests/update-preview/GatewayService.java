package ai.magpie.mobile;
import android.content.*;
final class GatewayService {static SharedPreferences prefs(Context c){return c.getSharedPreferences("ui-preview",Context.MODE_PRIVATE);}}
