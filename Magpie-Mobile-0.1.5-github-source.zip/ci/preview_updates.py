#!/usr/bin/env python3
"""Build the exact production UpdateActivity against offline test data, then capture Android UI.
No upstream native code, release signing key, network, or production preview hooks are used.
"""
import os,pathlib,subprocess,shutil,zipfile,time,xml.etree.ElementTree as ET,re
ROOT=pathlib.Path(__file__).resolve().parents[1]
SDK=pathlib.Path(os.environ['ANDROID_HOME']);BT=SDK/'build-tools/35.0.1';PLATFORM=SDK/'platforms/android-35/android.jar'
OUT=ROOT/'ui-preview';OUT.mkdir(exist_ok=True)
def run(*args,**kw):return subprocess.run([str(x) for x in args],check=True,**kw)
def adb(*args):return subprocess.check_output([str(SDK/'platform-tools/adb'),*map(str,args)],timeout=30)
for folder in ('gen','classes','dex'):(OUT/folder).mkdir(exist_ok=True)
(OUT/'AndroidManifest.xml').write_text('''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="ai.magpie.mobile" android:versionCode="1" android:versionName="ui-test"><uses-sdk android:minSdkVersion="28" android:targetSdkVersion="34"/><application android:label="Magpie UI preview" android:theme="@style/AppTheme" android:debuggable="true"><activity android:name=".UpdateActivity" android:exported="true"/><activity android:name=".MainActivity" android:exported="true"/></application></manifest>''')
run(BT/'aapt2','compile','--dir',ROOT/'android/app/src/main/res','-o',OUT/'res.zip')
run(BT/'aapt2','link','-I',PLATFORM,'--manifest',OUT/'AndroidManifest.xml','--java',OUT/'gen','-o',OUT/'unsigned.apk',OUT/'res.zip')
src=ROOT/'android/app/src/main/java/ai/magpie/mobile'
run('java','-jar',ROOT/'toolchain/ecj.jar','-1.8','-proc:none','-bootclasspath',str(PLATFORM)+os.pathsep+str(BT/'core-lambda-stubs.jar'),'-d',OUT/'classes',src/'UpdateActivity.java',src/'UpdatePolicy.java',*list((ROOT/'android/tests/update-preview').glob('*.java')),*list((OUT/'gen').rglob('*.java')))
run(BT/'d8','--lib',PLATFORM,'--min-api','28','--output',OUT/'dex',*list((OUT/'classes').rglob('*.class')))
with zipfile.ZipFile(OUT/'unsigned.apk','a') as z:z.write(OUT/'dex/classes.dex','classes.dex')
run('keytool','-genkeypair','-keystore',OUT/'test.p12','-storepass','android','-keypass','android','-alias','uitest','-dname','CN=UI Test Only','-keyalg','RSA','-validity','2',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
run(BT/'apksigner','sign','--ks',OUT/'test.p12','--ks-pass','pass:android','--out',OUT/'preview.apk',OUT/'unsigned.apk')
# Keep emulator and test in the same step; report startup failures promptly.
listing=subprocess.check_output([str(SDK/'cmdline-tools/latest/bin/avdmanager'),'list','avd'],text=True)
print(listing,flush=True)
match=re.search(r'^\s*Path:\s*([^\n]+magpie-ui\.avd)\s*$',listing,re.M)
if not match:raise RuntimeError('avdmanager did not report the prepared test device')
config=pathlib.Path(match.group(1).strip())/'config.ini'
config.write_text(re.sub(r'^disk\.dataPartition\.size=.*$', 'disk.dataPartition.size=2048M', config.read_text(),flags=re.M))
avd_home=OUT/'avds';avd_home.mkdir(exist_ok=True)
(avd_home/'magpie-ui.ini').write_text('avd.ini.encoding=UTF-8\npath='+str(config.parent)+'\ntarget=android-35\n')
log=open(ROOT/'emulator.log','wb')
emulator=subprocess.Popen([str(SDK/'emulator/emulator'),'-avd','magpie-ui','-no-window','-no-audio','-no-boot-anim','-no-snapshot','-gpu','swiftshader','-no-metrics','-memory','2048'],env=dict(os.environ,ANDROID_AVD_HOME=str(avd_home)),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
try:
 for attempt in range(120):
  if emulator.poll() is not None:
   log.flush();raise RuntimeError('emulator exited: '+(ROOT/'emulator.log').read_text(errors='replace')[-6000:])
  devices=adb('devices').decode()
  if re.search(r'emulator-\d+\s+device\b',devices) and adb('shell','getprop','sys.boot_completed').strip()==b'1':break
  if attempt%10==0:print('Waiting for Android boot:',attempt*2,'seconds; devices:',devices.strip(),flush=True)
  time.sleep(2)
 else:
  log.flush();raise RuntimeError('emulator did not boot: '+(ROOT/'emulator.log').read_text(errors='replace')[-6000:])
 adb('shell','settings','put','global','window_animation_scale','0');adb('shell','settings','put','global','transition_animation_scale','0');adb('shell','settings','put','global','animator_duration_scale','0')
 adb('shell','input','keyevent','82');adb('install','-r',OUT/'preview.apk')
 def tree():
  adb('shell','uiautomator','dump','/sdcard/window.xml')
  return ET.fromstring(adb('shell','cat','/sdcard/window.xml'))
 def capture(name):
  (OUT/(name+'.png')).write_bytes(adb('exec-out','screencap','-p'))
  (OUT/(name+'.xml')).write_bytes(ET.tostring(tree(),encoding='utf-8'))
 def launch(scenario):
  adb('shell','am','force-stop','ai.magpie.mobile');adb('shell','am','start','-W','-n','ai.magpie.mobile/.UpdateActivity','--es','scenario',scenario)
  # Wait on a visible hierarchy rather than assuming the launch splash has gone.
  for _ in range(10):
   if any(n.attrib.get('text')=='应用更新' for n in tree().iter('node')):return
   time.sleep(.5)
  raise AssertionError('update activity did not render')
 def assert_text(value):
  assert any(value in n.attrib.get('text','') for n in tree().iter('node')),value
 for scenario,title in [('waiting','等待安卓构建'),('latest','当前已是最新'),('available','有新版本可用'),('ready','更新已准备好'),('downloading','正在下载更新'),('error','更新暂未完成')]:
  launch(scenario);assert_text(title);capture(scenario)
 # Verify large fonts wrap naturally and the waiting action is still on screen.
 adb('shell','settings','put','system','font_scale','1.5');launch('waiting');assert_text('检查更新');capture('large-font')
 adb('shell','settings','put','system','font_scale','1.0');launch('waiting')
 adb('shell','input','swipe','500','1700','500','500','400');capture('settings')
 # Toggling and the repository dialog exercise actual native controls.
 def click_node(predicate):
  nodes=[n for n in tree().iter('node') if predicate(n.attrib)]
  assert len(nodes)==1,len(nodes)
  p=list(map(int,re.findall(r'\d+',nodes[0].attrib['bounds'])));adb('shell','input','tap',(p[0]+p[2])//2,(p[1]+p[3])//2)
 click_node(lambda a:a.get('class')=='android.widget.Switch')
 assert b'false' in adb('shell','run-as','ai.magpie.mobile','cat','shared_prefs/ui-preview.xml')
 click_node(lambda a:a.get('text')=='发布仓库');assert_text('设置发布仓库');capture('repository-dialog')
 adb('shell','input','keyevent','4')
 adb('shell','input','swipe','500','1700','500','500','400');assert_text('安装与数据');capture('footer')
 logs=adb('logcat','-d','-s','AndroidRuntime:E')
 assert b'FATAL EXCEPTION' not in logs,logs.decode(errors='replace')
 print('Native update UI: six states, large text, settings, repository dialog and crash checks passed')
finally:
 emulator.terminate()
 try:emulator.wait(timeout=15)
 except subprocess.TimeoutExpired:emulator.kill()
 log.close()
