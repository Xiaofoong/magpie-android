import copy,importlib.util,json,pathlib,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'ci'))
import follow_official,package_plan,sign_release
class ReleaseContracts(unittest.TestCase):
 def setUp(self):
  self.local=json.loads((ROOT/'android/release.json').read_text())
  self.latest={'tag_name':'v0.1.1234','draft':False,'prerelease':False,'body':'fixture release'}
 def test_channel_and_version_plan(self):
  p=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local)
  self.assertEqual(p['releaseTag'],'android-v0.1.1234-r'+str(self.local['mobileRevision']))
  self.assertGreater(p['versionCode'],self.local['versionCode'])
  self.assertEqual(p['signerSha256'],self.local['signerSha256'])
 def test_reject_draft_prerelease_and_malicious_tags(self):
  for edit in [{'draft':True},{'prerelease':True},{'tag_name':'v1; echo bad'},{'tag_name':'../../elsewhere'}]:
   with self.assertRaises(ValueError):follow_official.plan('Xiaofoong/magpie-android',{**self.latest,**edit},self.local)
 def test_isolated_package_job_rejects_modified_plan(self):
  p=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local);core={**p,'upstreamCommit':'a'*40}
  self.assertEqual(package_plan.merge(p,core,self.local)['upstreamCommit'],'a'*40)
  for field,value in [('signerSha256','b'*64),('versionCode',1),('updateRepository','other/repo')]:
   with self.assertRaises(ValueError):package_plan.merge(p,{**core,field:value},self.local)
 def test_feed_hash_size_and_release_url_are_derived(self):
  p=follow_official.plan('Xiaofoong/magpie-android',self.latest,self.local)
  with tempfile.TemporaryDirectory() as d:
   apk=pathlib.Path(d)/'test.apk';apk.write_bytes(b'fixture package')
   feed=sign_release.descriptor(p,apk)
   self.assertEqual(feed['size'],len(b'fixture package'));self.assertEqual(len(feed['sha256']),64)
   self.assertTrue(feed['apkUrl'].startswith('https://github.com/Xiaofoong/magpie-android/releases/download/android-v0.1.1234-r'+str(self.local['mobileRevision'])+'/'))
 def test_workflow_has_no_signing_secrets_in_core_job(self):
  import yaml
  workflow=yaml.load((ROOT/'.github/workflows/follow-official.yml').read_text(),Loader=yaml.BaseLoader)
  self.assertNotIn('ANDROID_KEYSTORE',json.dumps(workflow['jobs']['core']))
  self.assertIn('ANDROID_KEYSTORE',json.dumps(workflow['jobs']['package']))
  for job in workflow['jobs'].values():
   for step in job['steps']:
    if 'uses' in step:self.assertRegex(step['uses'],r'^actions/[a-z-]+@[a-f0-9]{40}$')
if __name__=='__main__':unittest.main()
