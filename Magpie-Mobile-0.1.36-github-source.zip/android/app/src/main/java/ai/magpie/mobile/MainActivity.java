package ai.magpie.mobile;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import android.widget.Toast;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** The original Magpie Web page is the app's only main screen. */
public final class MainActivity extends Activity {
  private WebView web;
  private final Handler main = new Handler(Looper.getMainLooper());
  private ValueCallback<Uri[]> upload;
  private byte[] pendingDownload;
  private boolean opened, destroyed, errorShown;
  private long deadline;
  private static final int PICK_FILE = 71, SAVE_FILE = 72, MAX_DOWNLOAD = 16 * 1024 * 1024;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(26, 26, 30));
    getWindow().setNavigationBarColor(Color.rgb(26, 26, 30));
    web = new WebView(this);
    web.setBackgroundColor(Color.rgb(26, 26, 30));
    WebSettings settings = web.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setDatabaseEnabled(true);
    settings.setAllowFileAccess(false);
    settings.setAllowContentAccess(true);
    settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    settings.setSupportMultipleWindows(true);
    settings.setJavaScriptCanOpenWindowsAutomatically(true);
    settings.setBuiltInZoomControls(false);
    settings.setDisplayZoomControls(false);
    settings.setUseWideViewPort(true);
    CookieManager.getInstance().setAcceptCookie(true);
    CookieManager.getInstance().setAcceptThirdPartyCookies(web, false);
    web.addJavascriptInterface(new Downloads(), "MagpieAndroidDownloads");
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        Uri uri = request.getUrl();
        if (local(uri)) return false;
        if ("magpie-mobile".equals(uri.getScheme()) && !request.isForMainFrame()) return true;
        openExternal(uri); return true;
      }
      @Override public void onPageFinished(WebView view, String url) {
        if (destroyed || errorShown || !local(Uri.parse(url))) return;
        CookieManager.getInstance().flush();
        AppUpdates.automatic(MainActivity.this);
        try {
          view.evaluateJavascript(asset("direct-downloads.js"), null);
          view.evaluateJavascript(asset("android-updates.js"), null);
          view.evaluateJavascript(asset("account-import.js"), null);
        }
        catch (IOException ignored) {}
        if (Build.VERSION.SDK_INT >= 33 && !GatewayService.prefs(MainActivity.this).getBoolean("notification_asked", false)) {
          GatewayService.prefs(MainActivity.this).edit().putBoolean("notification_asked", true).apply();
          if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 12);
          else BackgroundProtectionActivity.offerOnce(MainActivity.this);
        } else BackgroundProtectionActivity.offerOnce(MainActivity.this);
      }
      @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        if (request.isForMainFrame()) showFailure("无法连接本机 Magpie：" + error.getDescription());
      }
      @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, android.net.http.SslError error) { handler.cancel(); }
    });
    web.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> result, FileChooserParams params) {
        if (upload != null) upload.onReceiveValue(null);
        upload = result;
        try { startActivityForResult(params.createIntent(), PICK_FILE); }
        catch (ActivityNotFoundException e) { upload.onReceiveValue(null); upload = null; }
        return true;
      }
      @Override public boolean onCreateWindow(WebView view, boolean dialog, boolean gesture, Message result) {
        WebView popup = new WebView(MainActivity.this);
        popup.setWebViewClient(new WebViewClient() {
          @Override public boolean shouldOverrideUrlLoading(WebView child, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (uri.toString().equals("about:blank")) return false;
            if (local(uri)) web.loadUrl(uri.toString()); else openExternal(uri);
            child.destroy(); return true;
          }
        });
        ((WebView.WebViewTransport) result.obj).setWebView(popup); result.sendToTarget(); return true;
      }
    });
    web.setDownloadListener((url, agent, disposition, mime, length) -> {
      if (!local(Uri.parse(url))) return;
      String name = URLUtil.guessFileName(url, disposition, mime);
      new Thread(() -> {
        HttpURLConnection connection = null;
        try {
          connection = (HttpURLConnection) new URL(url).openConnection();
          connection.setInstanceFollowRedirects(false);
          connection.setConnectTimeout(5000); connection.setReadTimeout(30000);
          String cookie = CookieManager.getInstance().getCookie(url);
          if (cookie != null) connection.setRequestProperty("Cookie", cookie);
          if (connection.getResponseCode() != 200) throw new IOException("下载失败");
          byte[] bytes;
          try (InputStream in = connection.getInputStream()) { bytes = readLimited(in, MAX_DOWNLOAD); }
          main.post(() -> save(bytes, name, mime));
        } catch (Exception e) { main.post(() -> toast("文件下载未完成：" + e.getMessage())); }
        finally { if (connection != null) connection.disconnect(); }
      }, "magpie-download").start();
    });
    setContentView(web);
    GatewayService.prefs(this).edit().putBoolean("wanted", true).putLong("last_user_start", System.currentTimeMillis()).commit();
    begin();
  }

  private void begin() {
    errorShown = false; opened = false;
    deadline = System.currentTimeMillis() + 65000;
    if (!GatewayService.running && !GatewayService.starting) {
      try { startForegroundService(new Intent(this, GatewayService.class).setAction(GatewayService.START_USER)); }
      catch (Exception e) { showFailure(e.getMessage()); return; }
    }
    main.removeCallbacks(ready); main.post(ready);
  }

  private final Runnable ready = new Runnable() {
    @Override public void run() {
      if (destroyed || opened || errorShown) return;
      if (GatewayService.running) {
        opened = true; web.loadUrl(GatewayService.managementURL(MainActivity.this));
      } else if (System.currentTimeMillis() > deadline) showFailure(GatewayService.message);
      else main.postDelayed(this, 200);
    }
  };

  private boolean local(Uri uri) {
    return "http".equals(uri.getScheme()) && "127.0.0.1".equals(uri.getHost()) && uri.getPort() == 3430;
  }

  private void openExternal(Uri uri) {
    String scheme = uri.getScheme();
    if ("magpie-mobile".equals(scheme)) {
      if ("magpie-mobile://import-workbuddy".equals(uri.toString()) && web != null && local(Uri.parse(web.getUrl() == null ? "" : web.getUrl()))) {
        startActivityForResult(new Intent(this, AccountImportActivity.class), 73);
        return;
      }
      if (UpdatePolicy.appUpdateLink(uri.toString()) && web != null && local(Uri.parse(web.getUrl() == null ? "" : web.getUrl())))
        startActivity(new Intent(this, UpdateActivity.class));
      return;
    }
    if (scheme == null || scheme.equals("javascript") || scheme.equals("file") || scheme.equals("content") || scheme.equals("data") || scheme.equals("intent")) return;
    try { startActivity(new Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)); }
    catch (ActivityNotFoundException e) { toast("没有可打开此链接的应用"); }
  }

  private void showFailure(String message) {
    if (destroyed || isFinishing() || errorShown) return;
    errorShown = true;
    new AlertDialog.Builder(this).setTitle("Magpie 暂时无法载入")
      .setMessage(message == null ? "请稍后重试" : message)
      .setPositiveButton("重试", (d, n) -> begin())
      .setNeutralButton("查看日志", (d, n) -> new AlertDialog.Builder(this).setTitle("运行日志").setMessage(GatewayService.logs(this)).setPositiveButton("关闭", null).show())
      .setNegativeButton("关闭", null).show();
  }

  private final class Downloads {
    @JavascriptInterface public void saveBase64(String name, String mime, String encoded) {
      if (encoded == null || encoded.length() > MAX_DOWNLOAD * 4 / 3 + 8) { main.post(() -> toast("文件超过 16 MB，请从浏览器下载")); return; }
      try {
        byte[] bytes = android.util.Base64.decode(encoded, android.util.Base64.DEFAULT);
        main.post(() -> { if (!destroyed && local(Uri.parse(web.getUrl() == null ? "" : web.getUrl()))) save(bytes, name, mime); });
      } catch (IllegalArgumentException e) { main.post(() -> toast("无法保存该文件")); }
    }
  }

  private void save(byte[] bytes, String name, String mime) {
    if (destroyed) return;
    if (pendingDownload != null) { toast("请先完成上一个文件的保存"); return; }
    pendingDownload = bytes;
    String safe = name == null ? "magpie-download" : name.replaceAll("[/\\\\\\x00-\\x1f]", "_");
    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
      .setType(mime == null || mime.isEmpty() ? "application/octet-stream" : mime).putExtra(Intent.EXTRA_TITLE, safe);
    try { startActivityForResult(intent, SAVE_FILE); }
    catch (ActivityNotFoundException e) { pendingDownload = null; toast("设备没有文件保存器"); }
  }

  @Override protected void onActivityResult(int request, int result, Intent data) {
    super.onActivityResult(request, result, data);
    if (request == 73 && result == RESULT_OK && web != null) { web.reload(); return; }
    if (request == PICK_FILE && upload != null) {
      upload.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data)); upload = null;
    } else if (request == SAVE_FILE) {
      byte[] bytes = pendingDownload; pendingDownload = null;
      if (result != RESULT_OK || data == null || data.getData() == null || bytes == null) return;
      Uri uri = data.getData();
      new Thread(() -> {
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
          if (out == null) throw new IOException("无法写入文件"); out.write(bytes); main.post(() -> toast("已保存"));
        } catch (Exception e) { main.post(() -> toast("保存失败：" + e.getMessage())); }
      }, "magpie-save").start();
    }
  }

  private String asset(String name) throws IOException {
    try (InputStream in = getAssets().open(name)) { return new String(readLimited(in, 256 * 1024), StandardCharsets.UTF_8); }
  }
  private static byte[] readLimited(InputStream in, int limit) throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream(); byte[] buffer = new byte[8192]; int n;
    while ((n = in.read(buffer)) != -1) { if (out.size() + n > limit) throw new IOException("文件过大"); out.write(buffer, 0, n); }
    return out.toByteArray();
  }
  private void toast(String text) { if (!destroyed) Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
  @Override protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent); setIntent(intent);
    GatewayService.prefs(this).edit().putBoolean("wanted", true).putLong("last_user_start", System.currentTimeMillis()).commit();
    if(intent.getBooleanExtra("from_float",false) && web!=null) {
      if(GatewayService.running && opened && !errorShown)web.loadUrl(GatewayService.managementURL(this));else begin();
      return;
    }
    if (!opened || errorShown) begin();
    else if (!GatewayService.running && !GatewayService.starting) {
      try { startForegroundService(new Intent(this, GatewayService.class).setAction(GatewayService.START_USER)); }
      catch (RuntimeException e) { showFailure(e.getMessage()); }
    }
  }
  @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
    super.onRequestPermissionsResult(request, permissions, grants);
    if (request == 12) BackgroundProtectionActivity.offerOnce(this);
  }
  @Override protected void onResume() {
    super.onResume();
    FloatService.restoreIfEnabled(this);
    if (web != null) web.onResume();
    if (GatewayService.prefs(this).getBoolean("wanted", false) && !GatewayService.running && !GatewayService.starting) {
      try { startForegroundService(new Intent(this, GatewayService.class).setAction(GatewayService.START_USER)); }
      catch (RuntimeException ignored) {}
    }
  }
  @Override protected void onPause() { if (web != null) web.onPause(); super.onPause(); }
  @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else moveTaskToBack(true); }
  @Override protected void onDestroy() {
    destroyed = true; main.removeCallbacksAndMessages(null);
    if (upload != null) upload.onReceiveValue(null);
    web.removeJavascriptInterface("MagpieAndroidDownloads"); web.destroy(); super.onDestroy();
  }
}
