package ai.magpie.mobile;
/** Test-only activity: use Android's task-removal API, independent of launcher UI. */
public final class MainActivity extends android.app.Activity {
 @Override public void onCreate(android.os.Bundle state){
  super.onCreate(state);
  android.widget.Button remove=new android.widget.Button(this);
  remove.setText("移除最近任务");
  remove.setOnClickListener(v->{
   getSharedPreferences("ui-preview",MODE_PRIVATE).edit().putInt("fixture_removed_task",getTaskId()).commit();
   finishAndRemoveTask();
  });
  setContentView(remove);
 }
}
